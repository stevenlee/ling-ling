# 🎀 Knowledge Dashboard (v0.2.1)
---

## ✍️ Notes

## 🤖 Entities
> [!abstract]- 📂 BERT (language model) (10 items)
> - [[BERT (language model)]]  `clippings`
> - [[BERT (language model) (Part 1)]]  `Transformer` `自然語言處理` `語言模型` | 📅 2026-04-25
> - [[BERT (language model) (Part 2)]]  `language-model` `natural-language-processing` `transformer` | 📅 2026-04-25
> - [[BERT (language model) (Part 3)]]  `language-model` `natural-language-processing` `transformer` | 📅 2026-04-25
> - [[BERT (language model) (Part 4)]]  `language-model` `natural-language-processing` `transformer` | 📅 2026-04-25
> - [[BERT (language model) (Part 5)]]  `Transformer` `自然語言處理` `語言模型` | 📅 2026-04-25
> - [[BERT (language model) (Part 6)]]  `Transformer` `自然語言處理` `語言模型` | 📅 2026-04-25
> - [[BERT (language model) (Part 7)]]  `language-model` `natural-language-processing` `transformer` | 📅 2026-04-25
> - [[BERT (language model) (Part 8)]]  `language-model` `natural-language-processing` `transformer` | 📅 2026-04-25
> - [[BERT (language model) (Synthesis)]]  `completed` `language-model` `natural-language-processing`

> [!abstract]- 📂 Statistical classification (6 items)
> - [[Statistical classification (Part 1)]]  `data-analysis` `machine-learning` `statistics` | 📅 2026-04-25
> - [[Statistical classification (Part 2)]]  `data-analysis` `machine-learning` `statistics` | 📅 2026-04-25
> - [[Statistical classification (Part 3)]]  `data-analysis` `machine-learning` `statistics` | 📅 2026-04-25
> - [[Statistical classification (Part 4)]]  `data-analysis` `machine-learning` `statistics` | 📅 2026-04-25
> - [[Statistical classification (Part 5)]]  `data-analysis` `machine-learning` `statistics` | 📅 2026-04-25
> - [[Statistical classification (Synthesis)]]  `completed` `data-analysis` `machine-learning`

> [!abstract]- 📂 Supervised learning (7 items)
> - [[Supervised learning (Part 1)]]  `data-science` `machine-learning` `model-training` | 📅 2026-04-25
> - [[Supervised learning (Part 2)]]  `data-science` `machine-learning` `model-training` | 📅 2026-04-25
> - [[Supervised learning (Part 3)]]  `data-science` `machine-learning` `model-training` | 📅 2026-04-25
> - [[Supervised learning (Part 4)]]  `data-science` `machine-learning` `model-training` | 📅 2026-04-25
> - [[Supervised learning (Part 5)]]  `data-science` `machine-learning` `model-training` | 📅 2026-04-25
> - [[Supervised learning (Part 6)]]  `data-science` `machine-learning` `model-training` | 📅 2026-04-25
> - [[Supervised learning (Synthesis)]]  `completed` `data-science` `machine-learning`

> [!abstract]- 📂 Vitruvian Man (8 items)
> - [[Vitruvian Man]]  `clippings`
> - [[Vitruvian Man (Part 1)]]  `art-history` `da-vinci` `human-anatomy` | 📅 2026-04-25
> - [[Vitruvian Man (Part 2)]]  `art-history` `da-vinci` `human-anatomy` | 📅 2026-04-25
> - [[Vitruvian Man (Part 3)]]  `art-history` `da-vinci` `human-anatomy` | 📅 2026-04-25
> - [[Vitruvian Man (Part 4)]]  `art-history` `da-vinci` `human-anatomy` | 📅 2026-04-25
> - [[Vitruvian Man (Part 5)]]  `art-history` `da-vinci` `human-anatomy` | 📅 2026-04-25
> - [[Vitruvian Man (Part 6)]]  `art-history` `da-vinci` `human-anatomy` | 📅 2026-04-25
> - [[Vitruvian Man (Synthesis)]]  `art-history` `completed` `da-vinci`

> [!abstract]- 📂 孫子兵法 (3 items)
> - [[孫子兵法 (Part 1)]]  | 📅 2026-04-25
> - [[孫子兵法 (Part 2)]]  `Project Gutenberg` `數位典藏` `版權` | 📅 2026-04-25
> - [[孫子兵法 (Synthesis)]]  `Project Gutenberg` `completed` `synthesis`

