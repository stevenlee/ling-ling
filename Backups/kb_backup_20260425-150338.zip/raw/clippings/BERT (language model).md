---
title: "BERT (language model)"
source: "https://en.wikipedia.org/wiki/BERT_(language_model)"
author:
  - "[[Wikipedia]]"
published: 2019-10-11
created: 2026-04-25
description:
tags:
  - "clippings"
---
**Bidirectional encoder representations from transformers** (**BERT**) is a [language model](https://en.wikipedia.org/wiki/Language_model "Language model") introduced in October 2018 by researchers at [Google](https://en.wikipedia.org/wiki/Google "Google").[^2] [^3] It learns to represent text as a sequence of vectors using [self-supervised learning](https://en.wikipedia.org/wiki/Self-supervised_learning "Self-supervised learning"). It uses the [encoder-only transformer](https://en.wikipedia.org/wiki/Transformer_\(machine_learning_model\) "Transformer (machine learning model)") architecture. BERT dramatically improved the state of the art for [large language models](https://en.wikipedia.org/wiki/Large_language_model "Large language model"). As of 2020, BERT is a ubiquitous baseline in [natural language processing](https://en.wikipedia.org/wiki/Natural_language_processing "Natural language processing") (NLP) experiments.[^4]

BERT is trained by masked token prediction and next sentence prediction. With this training, BERT learns contextual, [latent representations](https://en.wikipedia.org/wiki/Latent_space "Latent space") of tokens in their context, similar to [ELMo](https://en.wikipedia.org/wiki/ELMo "ELMo") and [GPT-2](https://en.wikipedia.org/wiki/GPT-2 "GPT-2").[^5] It found applications for many natural language processing tasks, such as [coreference resolution](https://en.wikipedia.org/wiki/Coreference_resolution "Coreference resolution") and [polysemy](https://en.wikipedia.org/wiki/Polysemy "Polysemy") resolution.[^6] It improved on [ELMo](https://en.wikipedia.org/wiki/ELMo "ELMo") and spawned the study of "BERTology", which attempts to interpret what is learned by BERT.[^4]

BERT was originally implemented in the English language at two model sizes, BERT <sub>BASE</sub> (110 million parameters) and BERT <sub>LARGE</sub> (340 million parameters). Both were trained on the Toronto [BookCorpus](https://en.wikipedia.org/wiki/BookCorpus "BookCorpus") [^7] (800M words) and [English Wikipedia](https://en.wikipedia.org/wiki/English_Wikipedia "English Wikipedia") (2,500M words).[^2]<sup><span title="Page: 5">: 5</span> </sup> The weights were released on [GitHub](https://en.wikipedia.org/wiki/GitHub "GitHub").[^8] On March 11, 2020, 24 smaller models were released, the smallest being BERT <sub>TINY</sub> with just 4 million parameters.[^8]

## Architecture

![](https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/BERT_embeddings_01.png/330px-BERT_embeddings_01.png)

High-level schematic diagram of BERT. It takes in a text, tokenizes it into a sequence of tokens, add in optional special tokens, and apply a Transformer encoder. The hidden states of the last layer can then be used as contextual word embeddings.

BERT is an "encoder-only" [transformer](https://en.wikipedia.org/wiki/Transformer_\(machine_learning_model\) "Transformer (machine learning model)") architecture. At a high level, BERT consists of 4 modules:

- Tokenizer: This module converts a piece of English text into a sequence of integers ("tokens").
- [Embedding](https://en.wikipedia.org/wiki/Word_embedding "Word embedding"): This module converts the sequence of tokens into an array of real-valued vectors representing the tokens. It represents the conversion of discrete token types into a lower-dimensional [Euclidean space](https://en.wikipedia.org/wiki/Euclidean_space "Euclidean space").
- Encoder: a stack of Transformer blocks with [self-attention](https://en.wikipedia.org/wiki/Attention_\(machine_learning\) "Attention (machine learning)"), but without causal masking.
- Task head: This module converts the final representation vectors into one-hot encoded tokens again by producing a predicted probability distribution over the token types. It can be viewed as a simple decoder, decoding the latent representation into token types, or as an "un-embedding layer".

The task head is necessary for pre-training, but it is often unnecessary for so-called "downstream tasks," such as [question answering](https://en.wikipedia.org/wiki/Question_answering "Question answering") or [sentiment classification](https://en.wikipedia.org/wiki/Sentiment_analysis "Sentiment analysis"). Instead, one removes the task head and replaces it with a newly initialized module suited for the task, and finetune the new module. The latent vector representation of the model is directly fed into this new module, allowing for sample-efficient [transfer learning](https://en.wikipedia.org/wiki/Transfer_learning "Transfer learning").[^2] [^9]

![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/BERT_encoder-only_attention.svg/250px-BERT_encoder-only_attention.svg.png)

Encoder-only attention is all-to-all.

### Embedding

This section describes the embedding used by BERT <sub>BASE</sub>. The other one, BERT <sub>LARGE</sub>, is similar, just larger.

The tokenizer of BERT is WordPiece, which is a sub-word strategy like [byte-pair encoding](https://en.wikipedia.org/wiki/Byte-pair_encoding "Byte-pair encoding"). Its vocabulary size is 30,000, and any token not appearing in its vocabulary is replaced by `[UNK]` ("unknown").

![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/BERT_input_embeddings.png/330px-BERT_input_embeddings.png)

The three kinds of embedding used by BERT: token type, position, and segment type.

The first layer is the embedding layer, which contains three components: token type embeddings, position embeddings, and segment type embeddings.

- Token type: The token type is a standard embedding layer, translating a one-hot vector into a dense vector based on its token type.
- Position: The position embeddings are based on a token's position in the sequence. BERT uses absolute position embeddings, where each position in a sequence is mapped to a real-valued vector. Each dimension of the vector consists of a [sinusoidal function](https://en.wikipedia.org/wiki/Sine_wave "Sine wave") that takes the position in the sequence as input.
- Segment type: Using a vocabulary of just 0 or 1, this embedding layer produces a dense vector based on whether the token belongs to the first or second text segment in that input. In other words, type-1 tokens are all tokens that appear after the `[SEP]` special token. All prior tokens are type-0.

The three embedding vectors are added together representing the initial token representation as a function of these three pieces of information. After embedding, the vector representation is normalized using a [LayerNorm](https://en.wikipedia.org/wiki/LayerNorm "LayerNorm") operation, outputting a 768-dimensional vector for each input token. After this, the representation vectors are passed forward through 12 Transformer encoder blocks, and are decoded back to 30,000-dimensional vocabulary space using a basic affine transformation layer.

### Architectural family

The encoder stack of BERT has 2 free parameters: ${\displaystyle L}$, the number of layers, and ${\displaystyle H}$, the *hidden size*. There are always ${\displaystyle H/64}$ self-attention heads, and the feed-forward/filter size is always ${\displaystyle 4H}$. By varying these two numbers, one obtains an entire family of BERT models.[^10]

For BERT:

- the *feed-forward size* and *filter size* are synonymous. Both of them denote the number of dimensions in the middle layer of the feed-forward network.
- the *hidden size* and *embedding size* are synonymous. Both of them denote the number of real numbers used to represent a token.

The notation for encoder stack is written as L/H. For example, BERT <sub>BASE</sub> is written as 12L/768H, BERT <sub>LARGE</sub> as 24L/1024H, and BERT <sub>TINY</sub> as 2L/128H.

## Training

### Pre-training

BERT was pre-trained simultaneously on two tasks:[^11]

- *Masked language modeling* (MLM): In this task, BERT ingests a sequence of words, where one word may be randomly changed ("masked"), and BERT tries to predict the original words that had been changed. For example, in the sentence "The cat sat on the `[MASK]`," BERT would need to predict "mat." This helps BERT learn bidirectional context, meaning it understands the relationships between words not just from left to right or right to left but from both directions at the same time.
- *Next sentence prediction* (NSP): In this task, BERT is trained to predict whether one sentence logically follows another. For example, given two sentences, "The cat sat on the mat" and "It was a sunny day", BERT has to decide if the second sentence is a valid continuation of the first one. This helps BERT understand relationships between sentences, which is important for tasks like question answering or document classification.

#### Masked language modeling

![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/BERT_masked_language_modelling_task.png/250px-BERT_masked_language_modelling_task.png)

The masked language modeling task

In masked language modeling, 15% of tokens would be randomly selected for masked-prediction task, and the training objective was to predict the masked token given its context. In more detail, the selected token is:

- replaced with a `[MASK]` token with probability 80%,
- replaced with a random word token with probability 10%,
- not replaced with probability 10%.

The reason not all selected tokens are masked is to avoid the dataset shift problem. The dataset shift problem arises when the distribution of inputs seen during training differs significantly from the distribution encountered during inference. A trained BERT model might be applied to word representation (like [Word2Vec](https://en.wikipedia.org/wiki/Word2Vec "Word2Vec")), where it would be run over sentences not containing any `[MASK]` tokens. It is later found that more diverse training objectives are generally better.[^12]

As an illustrative example, consider the sentence "my dog is cute". It would first be divided into tokens like "my <sub>1</sub> dog <sub>2</sub> is <sub>3</sub> cute <sub>4</sub> ". Then a random token in the sentence would be picked. Let it be the 4th one "cute <sub>4</sub> ". Next, there would be three possibilities:

- with probability 80%, the chosen token is masked, resulting in "my <sub>1</sub> dog <sub>2</sub> is <sub>3</sub> `[MASK]` <sub>4</sub> ";
- with probability 10%, the chosen token is replaced by a uniformly sampled random token, such as "happy", resulting in "my <sub>1</sub> dog <sub>2</sub> is <sub>3</sub> happy <sub>4</sub> ";
- with probability 10%, nothing is done, resulting in "my <sub>1</sub> dog <sub>2</sub> is <sub>3</sub> cute <sub>4</sub> ".

After processing the input text, the model's 4th output vector is passed to its decoder layer, which outputs a probability distribution over its 30,000-dimensional vocabulary space.

#### Next sentence prediction

![](https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/BERT_next_sequence_prediction_task.png/250px-BERT_next_sequence_prediction_task.png)

The next sentence prediction task

Given two sentences, the model predicts if they appear sequentially in the training corpus, outputting either `[IsNext]` or `[NotNext]`. During training, the algorithm sometimes samples two sentences from a single continuous span in the training corpus, while at other times, it samples two sentences from two discontinuous spans.

The first sentence starts with a special token, `[CLS]` (for "classify"). The two sentences are separated by another special token, `[SEP]` (for "separate"). After processing the two sentences, the final vector for the `[CLS]` token is passed to a linear layer for binary classification into `[IsNext]` and `[NotNext]`.

For example:

- Given " `[CLS]` my dog is cute `[SEP]` he likes playing `[SEP]` ", the model should predict `[IsNext]`.
- Given " `[CLS]` my dog is cute `[SEP]` how do magnets work `[SEP]` ", the model should predict `[NotNext]`.

### Fine-tuning

Fine-tuned tasks for BERT [^13]

- ![Sentiment classification](https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/BERT_on_sentiment_classification.svg/250px-BERT_on_sentiment_classification.svg.png)
	Sentiment classification
	Sentiment classification
- ![Sentence classification](https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/BERT_on_sentence_classification.svg/250px-BERT_on_sentence_classification.svg.png)
	Sentence classification
	Sentence classification
- ![Answering multiple-choice questions](https://upload.wikimedia.org/wikipedia/commons/thumb/0/05/BERT_on_multiple-choice_question-answering.svg/250px-BERT_on_multiple-choice_question-answering.svg.png)
	Answering multiple-choice questions
	Answering multiple-choice questions
- ![Part-of-speech tagging](https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/BERT_on_tagging.svg/250px-BERT_on_tagging.svg.png)
	Part-of-speech tagging
	[Part-of-speech tagging](https://en.wikipedia.org/wiki/Part-of-speech_tagging "Part-of-speech tagging")

BERT is meant as a general pretrained model for various applications in natural language processing. That is, after pre-training, BERT can be [fine-tuned](https://en.wikipedia.org/wiki/Fine-tuning_\(machine_learning\) "Fine-tuning (machine learning)") with fewer resources on smaller datasets to optimize its performance on specific tasks such as [natural language inference](https://en.wikipedia.org/wiki/Textual_entailment "Textual entailment") and [text classification](https://en.wikipedia.org/wiki/Document_classification "Document classification"), and sequence-to-sequence-based language generation tasks such as [question answering](https://en.wikipedia.org/wiki/Question_answering "Question answering") and conversational response generation.[^13]

The original BERT paper published results demonstrating that a small amount of finetuning (for BERT <sub>LARGE</sub>, 1 hour on 1 Cloud TPU) allowed it to achieved [state-of-the-art](https://en.wikipedia.org/wiki/State_of_the_art "State of the art") performance on a number of [natural language understanding](https://en.wikipedia.org/wiki/Natural-language_understanding "Natural-language understanding") tasks:[^2]

- GLUE ([General Language Understanding Evaluation](https://en.wikipedia.org/wiki/General_Language_Understanding_Evaluation "General Language Understanding Evaluation")) task set (consisting of 9 tasks);
- SQuAD (Stanford Question Answering Dataset [^14]) v1.1 and v2.0;
- SWAG (Situations With Adversarial Generations [^15]).

In the original paper, all parameters of BERT are fine-tuned, and recommended that, for downstream applications that are text classifications, the output token at the `[CLS]` input token is fed into a linear-softmax layer to produce the label outputs.[^2]

The original code base defined the final linear layer as a "pooler layer", in analogy with [global pooling](https://en.wikipedia.org/wiki/Pooling_layer "Pooling layer") in computer vision, even though it simply discards all output tokens except the one corresponding to `[CLS]`.[^16]

### Cost

BERT was trained on the [BookCorpus](https://en.wikipedia.org/wiki/BookCorpus "BookCorpus") (800M words) and a filtered version of English Wikipedia (2,500M words) without lists, tables, and headers.

Training BERT <sub>BASE</sub> on 4 cloud [TPU](https://en.wikipedia.org/wiki/Tensor_Processing_Unit "Tensor Processing Unit") (16 TPU chips total) took 4 days, at an estimated cost of 500 USD.[^8] Training BERT <sub>LARGE</sub> on 16 cloud TPU (64 TPU chips total) took 4 days.[^2]

## Interpretation

Language models like ELMo, GPT-2, and BERT, spawned the study of "BERTology", which attempts to interpret what is learned by these models. Their performance on these [natural language understanding](https://en.wikipedia.org/wiki/Natural-language_understanding "Natural-language understanding") tasks are not yet well understood.[^4] [^17] [^18] Several research publications in 2018 and 2019 focused on investigating the relationship behind BERT's output as a result of carefully chosen input sequences,[^19] [^20] analysis of internal [vector representations](https://en.wikipedia.org/wiki/Vector_space_model "Vector space model") through probing classifiers,[^21] [^22] and the relationships represented by [attention](https://en.wikipedia.org/wiki/Transformer_\(machine_learning_model\)#Architecture "Transformer (machine learning model)") weights.[^17] [^18]

The high performance of the BERT model could also be attributed to the fact that it is bidirectionally trained.[^23] This means that BERT, based on the Transformer model architecture, applies its self-attention mechanism to learn information from a text from the left and right side during training, and consequently gains a deep understanding of the context. For example, the word *fine* can have two different meanings depending on the context (**I feel** fine **today**, **She has** fine **blond hair**). BERT considers the words surrounding the target word *fine* from the left and right side.

However it comes at a cost: due to [encoder-only](https://en.wikipedia.org/wiki/Transformer_\(deep_learning_architecture\)#encoder-only "Transformer (deep learning architecture)") architecture lacking a decoder, BERT can't [be prompted](https://en.wikipedia.org/wiki/Prompt_engineering "Prompt engineering") and can't [generate text](https://en.wikipedia.org/wiki/Natural_language_generation "Natural language generation"), while bidirectional models in general do not work effectively without the right side, thus being difficult to prompt. As an illustrative example, if one wishes to use BERT to continue a sentence fragment "Today, I went to", then naively one would mask out all the tokens as "Today, I went to `[MASK]` `[MASK]` `[MASK]`... `[MASK]`." where the number of `[MASK]` is the length of the sentence one wishes to extend to. However, this constitutes a dataset shift, as during training, BERT has never seen sentences with that many tokens masked out. Consequently, its performance degrades. More sophisticated techniques allow text generation, but at a high computational cost.[^24]

## History

BERT was originally published by Google researchers Jacob Devlin, Ming-Wei Chang, Kenton Lee, and Kristina Toutanova. The design has its origins from pre-training contextual representations, including [semi-supervised sequence learning](https://en.wikipedia.org/wiki/Semi-supervised_learning "Semi-supervised learning"),[^25] generative pre-training, [ELMo](https://en.wikipedia.org/wiki/ELMo "ELMo"),[^26] and ULMFit.[^27] Unlike previous models, BERT is a deeply bidirectional, [unsupervised](https://en.wikipedia.org/wiki/Unsupervised_learning "Unsupervised learning") language representation, pre-trained using only a plain [text corpus](https://en.wikipedia.org/wiki/Text_corpus "Text corpus"). Context-free models such as [word2vec](https://en.wikipedia.org/wiki/Word2vec "Word2vec") or [GloVe](https://en.wikipedia.org/wiki/GloVe_\(machine_learning\) "GloVe (machine learning)") generate a single word embedding representation for each word in the vocabulary, whereas BERT takes into account the context for each occurrence of a given word. For instance, whereas the vector for "running" will have the same word2vec vector representation for both of its occurrences in the sentences "He is running a company" and "He is running a marathon", BERT will provide a contextualized embedding that will be different according to the sentence.[^5]

On October 25, 2019, [Google](https://en.wikipedia.org/wiki/Google "Google") announced that they had started applying BERT models to [English-language](https://en.wikipedia.org/wiki/English-language "English-language") search queries on [Google Search](https://en.wikipedia.org/wiki/Google_Search "Google Search") within the US.[^28] On December 9, 2019, it was reported that BERT had been adopted by Google Search for over 70 languages.[^29] [^30] In October 2020, almost every single English-based query was processed by a BERT model.[^31]

## Variants

The BERT models were influential and inspired many variants.

**RoBERTa** (2019) [^32] was an engineering improvement. It preserves BERT's architecture (slightly larger, at 355M parameters), but improves its training, changing key hyperparameters, removing the *next-sentence prediction* task, and using much larger [mini-batch](https://en.wikipedia.org/wiki/Stochastic_gradient_descent#Iterative_method "Stochastic gradient descent") sizes.

**XLM-RoBERTa** (2019) [^33] was a multilingual RoBERTa model. It was one of the first works on multilingual language modeling at scale.

**DistilBERT** (2019) [distills](https://en.wikipedia.org/wiki/Knowledge_distillation "Knowledge distillation") BERT <sub>BASE</sub> to a model with just 60% of its parameters (66M), while preserving 95% of its benchmark scores.[^34] [^35] Similarly, **TinyBERT** (2019) [^36] is a distilled model with just 28% of its parameters.

**ALBERT** (2019) [^37] used shared-parameter across layers, and experimented with independently varying the hidden size and the word-embedding layer's output size as two hyperparameters. They also replaced the *next sentence prediction* task with the *sentence-order prediction* (SOP) task, where the model must distinguish the correct order of two consecutive text segments from their reversed order.

**ELECTRA** (2020) [^38] applied the idea of [generative adversarial networks](https://en.wikipedia.org/wiki/Generative_adversarial_network "Generative adversarial network") to the MLM task. Instead of masking out tokens, a small language model generates random plausible substitutions, and a larger network identify these replaced tokens. The small model aims to fool the large model.

**DeBERTa** (2020) [^39] is a significant architectural variant, with *disentangled attention*. Its key idea is to treat the positional and token encodings separately throughout the attention mechanism. Instead of combining the positional encoding (${\displaystyle x_{\mathrm {position} }}$) and token encoding (${\displaystyle x_{\mathrm {token} }}$) into a single input vector (${\displaystyle x_{\mathrm {input} }=x_{\mathrm {position} }+x_{\mathrm {token} }}$), DeBERTa keeps them separate as a tuple: ${\displaystyle (x_{\mathrm {position} },x_{\mathrm {token} })}$. Then, at each self-attention layer, DeBERTa computes three distinct attention matrices, rather than the single attention matrix used in BERT:[^1]

| Attention type | Query type | Key type | Example |
| --- | --- | --- | --- |
| Content-to-content | Token | Token | "European"; "Union", "continent" |
| Content-to-position | Token | Position | \[adjective\]; +1, +2, +3 |
| Position-to-content | Position | Token | −1; "not", "very" |

The three attention matrices are added together element-wise, then passed through a softmax layer and multiplied by a projection matrix.

Absolute position encoding is included in the final self-attention layer as additional input.

## Notes

## References

[^1]: The position-to-position type was omitted by the authors for being useless.

[^2]: Devlin, Jacob; Chang, Ming-Wei; Lee, Kenton; Toutanova, Kristina (October 11, 2018). "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1810.04805v2](https://arxiv.org/abs/1810.04805v2) \[[cs.CL](https://arxiv.org/archive/cs.CL)\].

[^3]: ["Open Sourcing BERT: State-of-the-Art Pre-training for Natural Language Processing"](http://ai.googleblog.com/2018/11/open-sourcing-bert-state-of-art-pre.html). *Google AI Blog*. November 2, 2018. Retrieved November 27, 2019.

[^4]: Rogers, Anna; Kovaleva, Olga; Rumshisky, Anna (2020). ["A Primer in BERTology: What We Know About How BERT Works"](https://aclanthology.org/2020.tacl-1.54). *Transactions of the Association for Computational Linguistics*. **8**: 842–866. [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[2002.12327](https://arxiv.org/abs/2002.12327). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1162/tacl\_a\_00349](https://doi.org/10.1162%2Ftacl_a_00349). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [211532403](https://api.semanticscholar.org/CorpusID:211532403).

[^5]: Ethayarajh, Kawin (September 1, 2019), *How Contextual are Contextualized Word Representations? Comparing the Geometry of BERT, ELMo, and GPT-2 Embeddings*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1909.00512](https://arxiv.org/abs/1909.00512)

[^6]: Anderson, Dawn (November 5, 2019). ["A deep dive into BERT: How BERT launched a rocket into natural language understanding"](https://searchengineland.com/a-deep-dive-into-bert-how-bert-launched-a-rocket-into-natural-language-understanding-324522). *Search Engine Land*. Retrieved August 6, 2024.

[^7]: Zhu, Yukun; Kiros, Ryan; Zemel, Rich; Salakhutdinov, Ruslan; Urtasun, Raquel; Torralba, Antonio; Fidler, Sanja (2015). "Aligning Books and Movies: Towards Story-Like Visual Explanations by Watching Movies and Reading Books". pp. 19–27. [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1506.06724](https://arxiv.org/abs/1506.06724) \[[cs.CV](https://arxiv.org/archive/cs.CV)\].

[^8]: ["BERT"](https://github.com/google-research/bert). *GitHub*. Retrieved March 28, 2023.

[^9]: Zhang, Tianyi; Wu, Felix; Katiyar, Arzoo; Weinberger, Kilian Q.; Artzi, Yoav (March 11, 2021), *Revisiting Few-sample BERT Fine-tuning*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[2006.05987](https://arxiv.org/abs/2006.05987)

[^10]: Turc, Iulia; Chang, Ming-Wei; Lee, Kenton; Toutanova, Kristina (September 25, 2019), *Well-Read Students Learn Better: On the Importance of Pre-training Compact Models*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1908.08962](https://arxiv.org/abs/1908.08962)

[^11]: ["Summary of the models — transformers 3.4.0 documentation"](https://huggingface.co/transformers/v3.4.0/model_summary.html). *huggingface.co*. Retrieved February 16, 2023.

[^12]: Tay, Yi; Dehghani, Mostafa; Tran, Vinh Q.; Garcia, Xavier; Wei, Jason; Wang, Xuezhi; Chung, Hyung Won; Shakeri, Siamak; Bahri, Dara (February 28, 2023), *UL2: Unifying Language Learning Paradigms*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[2205.05131](https://arxiv.org/abs/2205.05131)

[^13]: Zhang, Aston; Lipton, Zachary; Li, Mu; Smola, Alexander J. (2024). ["11.9. Large-Scale Pretraining with Transformers"](https://d2l.ai/chapter_attention-mechanisms-and-transformers/large-pretraining-transformers.html). *Dive into deep learning*. Cambridge New York Port Melbourne New Delhi Singapore: Cambridge University Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-009-38943-3](https://en.wikipedia.org/wiki/Special:BookSources/978-1-009-38943-3 "Special:BookSources/978-1-009-38943-3").

[^14]: Rajpurkar, Pranav; Zhang, Jian; Lopyrev, Konstantin; [Liang, Percy](https://en.wikipedia.org/wiki/Percy_Liang "Percy Liang") (October 10, 2016). "SQuAD: 100,000+ Questions for Machine Comprehension of Text". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1606.05250](https://arxiv.org/abs/1606.05250) \[[cs.CL](https://arxiv.org/archive/cs.CL)\].

[^15]: Zellers, Rowan; Bisk, Yonatan; Schwartz, Roy; Choi, Yejin (August 15, 2018). "SWAG: A Large-Scale Adversarial Dataset for Grounded Commonsense Inference". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1808.05326](https://arxiv.org/abs/1808.05326) \[[cs.CL](https://arxiv.org/archive/cs.CL)\].

[^16]: ["bert/modeling.py at master · google-research/bert"](https://github.com/google-research/bert/blob/master/modeling.py). *GitHub*. Retrieved September 16, 2024.

[^17]: Kovaleva, Olga; Romanov, Alexey; Rogers, Anna; Rumshisky, Anna (November 2019). ["Revealing the Dark Secrets of BERT"](https://www.aclweb.org/anthology/D19-1445). *Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing and the 9th International Joint Conference on Natural Language Processing (EMNLP-IJCNLP)*. pp. 4364–4373. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.18653/v1/D19-1445](https://doi.org/10.18653%2Fv1%2FD19-1445). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [201645145](https://api.semanticscholar.org/CorpusID:201645145).

[^18]: Clark, Kevin; Khandelwal, Urvashi; Levy, Omer; Manning, Christopher D. (2019). ["What Does BERT Look at? An Analysis of BERT's Attention"](https://doi.org/10.18653%2Fv1%2Fw19-4828). *Proceedings of the 2019 ACL Workshop BlackboxNLP: Analyzing and Interpreting Neural Networks for NLP*. Stroudsburg, PA, USA: Association for Computational Linguistics: 276–286. [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1906.04341](https://arxiv.org/abs/1906.04341). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.18653/v1/w19-4828](https://doi.org/10.18653%2Fv1%2Fw19-4828).

[^19]: Khandelwal, Urvashi; He, He; Qi, Peng; Jurafsky, Dan (2018). "Sharp Nearby, Fuzzy Far Away: How Neural Language Models Use Context". *Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers)*. Stroudsburg, PA, USA: Association for Computational Linguistics: 284–294. [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1805.04623](https://arxiv.org/abs/1805.04623). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.18653/v1/p18-1027](https://doi.org/10.18653%2Fv1%2Fp18-1027). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [21700944](https://api.semanticscholar.org/CorpusID:21700944).

[^20]: Gulordava, Kristina; Bojanowski, Piotr; Grave, Edouard; Linzen, Tal; Baroni, Marco (2018). "Colorless Green Recurrent Networks Dream Hierarchically". *Proceedings of the 2018 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, Volume 1 (Long Papers)*. Stroudsburg, PA, USA: Association for Computational Linguistics. pp. 1195–1205. [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1803.11138](https://arxiv.org/abs/1803.11138). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.18653/v1/n18-1108](https://doi.org/10.18653%2Fv1%2Fn18-1108). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [4460159](https://api.semanticscholar.org/CorpusID:4460159).

[^21]: Giulianelli, Mario; Harding, Jack; Mohnert, Florian; Hupkes, Dieuwke; Zuidema, Willem (2018). "Under the Hood: Using Diagnostic Classifiers to Investigate and Improve how Language Models Track Agreement Information". *Proceedings of the 2018 EMNLP Workshop BlackboxNLP: Analyzing and Interpreting Neural Networks for NLP*. Stroudsburg, PA, USA: Association for Computational Linguistics: 240–248. [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1808.08079](https://arxiv.org/abs/1808.08079). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.18653/v1/w18-5426](https://doi.org/10.18653%2Fv1%2Fw18-5426). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [52090220](https://api.semanticscholar.org/CorpusID:52090220).

[^22]: Zhang, Kelly; Bowman, Samuel (2018). ["Language Modeling Teaches You More than Translation Does: Lessons Learned Through Auxiliary Syntactic Task Analysis"](https://doi.org/10.18653%2Fv1%2Fw18-5448). *Proceedings of the 2018 EMNLP Workshop BlackboxNLP: Analyzing and Interpreting Neural Networks for NLP*. Stroudsburg, PA, USA: Association for Computational Linguistics: 359–361. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.18653/v1/w18-5448](https://doi.org/10.18653%2Fv1%2Fw18-5448).

[^23]: Sur, Chiranjib (January 2020). ["RBN: enhancement in language attribute prediction using global representation of natural language transfer learning technology like Google BERT"](https://doi.org/10.1007%2Fs42452-019-1765-9). *SN Applied Sciences*. **2** (1) 22. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1007/s42452-019-1765-9](https://doi.org/10.1007%2Fs42452-019-1765-9).

[^24]: Patel, Ajay; Li, Bryan; Mohammad Sadegh Rasooli; Constant, Noah; Raffel, Colin; Callison-Burch, Chris (2022). "Bidirectional Language Models Are Also Few-shot Learners". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[2209.14500](https://arxiv.org/abs/2209.14500) \[[cs.LG](https://arxiv.org/archive/cs.LG)\].

[^25]: Dai, Andrew; Le, Quoc (November 4, 2015). "Semi-supervised Sequence Learning". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1511.01432](https://arxiv.org/abs/1511.01432) \[[cs.LG](https://arxiv.org/archive/cs.LG)\].

[^26]: Peters, Matthew; Neumann, Mark; Iyyer, Mohit; Gardner, Matt; Clark, Christopher; Lee, Kenton; Luke, Zettlemoyer (February 15, 2018). "Deep contextualized word representations". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1802.05365v2](https://arxiv.org/abs/1802.05365v2) \[[cs.CL](https://arxiv.org/archive/cs.CL)\].

[^27]: Howard, Jeremy; Ruder, Sebastian (January 18, 2018). "Universal Language Model Fine-tuning for Text Classification". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1801.06146v5](https://arxiv.org/abs/1801.06146v5) \[[cs.CL](https://arxiv.org/archive/cs.CL)\].

[^28]: Nayak, Pandu (October 25, 2019). ["Understanding searches better than ever before"](https://www.blog.google/products/search/search-language-understanding-bert/). *Google Blog*. Retrieved December 10, 2019.

[^29]: ["Understanding searches better than ever before"](https://blog.google/products/search/search-language-understanding-bert/). *Google*. October 25, 2019. Retrieved August 6, 2024.

[^30]: Montti, Roger (December 10, 2019). ["Google's BERT Rolls Out Worldwide"](https://www.searchenginejournal.com/google-bert-rolls-out-worldwide/339359/). *Search Engine Journal*. Retrieved December 10, 2019.

[^31]: ["Google: BERT now used on almost every English query"](https://searchengineland.com/google-bert-used-on-almost-every-english-query-342193). *Search Engine Land*. October 15, 2020. Retrieved November 24, 2020.

[^32]: Liu, Yinhan; Ott, Myle; Goyal, Naman; Du, Jingfei; Joshi, Mandar; Chen, Danqi; Levy, Omer; Lewis, Mike; Zettlemoyer, Luke; Stoyanov, Veselin (2019). "RoBERTa: A Robustly Optimized BERT Pretraining Approach". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1907.11692](https://arxiv.org/abs/1907.11692) \[[cs.CL](https://arxiv.org/archive/cs.CL)\].

[^33]: Conneau, Alexis; Khandelwal, Kartikay; Goyal, Naman; Chaudhary, Vishrav; Wenzek, Guillaume; Guzmán, Francisco; Grave, Edouard; Ott, Myle; Zettlemoyer, Luke; Stoyanov, Veselin (2019). "Unsupervised Cross-lingual Representation Learning at Scale". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1911.02116](https://arxiv.org/abs/1911.02116) \[[cs.CL](https://arxiv.org/archive/cs.CL)\].

[^34]: Sanh, Victor; Debut, Lysandre; Chaumond, Julien; Wolf, Thomas (February 29, 2020), *DistilBERT, a distilled version of BERT: smaller, faster, cheaper and lighter*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1910.01108](https://arxiv.org/abs/1910.01108)

[^35]: ["DistilBERT"](https://huggingface.co/docs/transformers/model_doc/distilbert). *huggingface.co*. Retrieved August 5, 2024.

[^36]: Jiao, Xiaoqi; Yin, Yichun; Shang, Lifeng; Jiang, Xin; Chen, Xiao; Li, Linlin; Wang, Fang; Liu, Qun (October 15, 2020), *TinyBERT: Distilling BERT for Natural Language Understanding*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1909.10351](https://arxiv.org/abs/1909.10351)

[^37]: Lan, Zhenzhong; Chen, Mingda; Goodman, Sebastian; Gimpel, Kevin; Sharma, Piyush; Soricut, Radu (February 8, 2020), *ALBERT: A Lite BERT for Self-supervised Learning of Language Representations*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1909.11942](https://arxiv.org/abs/1909.11942)

[^38]: Clark, Kevin; Luong, Minh-Thang; Le, Quoc V.; Manning, Christopher D. (March 23, 2020), *ELECTRA: Pre-training Text Encoders as Discriminators Rather Than Generators*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[2003.10555](https://arxiv.org/abs/2003.10555)

[^39]: He, Pengcheng; Liu, Xiaodong; Gao, Jianfeng; Chen, Weizhu (October 6, 2021), *DeBERTa: Decoding-enhanced BERT with Disentangled Attention*, [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[2006.03654](https://arxiv.org/abs/2006.03654)