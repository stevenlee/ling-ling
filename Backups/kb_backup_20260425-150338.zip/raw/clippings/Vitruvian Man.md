---
title: "Vitruvian Man"
source: "https://en.wikipedia.org/wiki/Vitruvian_Man"
author:
  - "[[Wikipedia]]"
published: 2004-01-28
created: 2026-04-25
description:
tags:
  - "clippings"
---
***Vitruvian Man*** ([Italian](https://en.wikipedia.org/wiki/Italian_language "Italian language"): *L'uomo vitruviano*) is a [drawing](https://en.wikipedia.org/wiki/Drawing "Drawing") by the [Italian Renaissance](https://en.wikipedia.org/wiki/Italian_Renaissance "Italian Renaissance") artist and scientist [Leonardo da Vinci](https://en.wikipedia.org/wiki/Leonardo_da_Vinci "Leonardo da Vinci"), dated to c. 1490. Inspired by the Roman architect [Vitruvius](https://en.wikipedia.org/wiki/Vitruvius "Vitruvius"), it depicts a nude man in two overlapping standing positions, inscribed within a circle and a square. Art historian [Carmen C. Bambach](https://en.wikipedia.org/wiki/Carmen_C._Bambach "Carmen C. Bambach") described it as "justly ranked among the all-time iconic images of [Western civilization](https://en.wikipedia.org/wiki/Western_culture "Western culture") ".[^5] While not the only drawing inspired by Vitruvius, Leonardo's work uniquely combines artistic vision with scientific inquiry and is often considered an archetypal representation of the [High Renaissance](https://en.wikipedia.org/wiki/High_Renaissance "High Renaissance").

The drawing illustrates Leonardo's study of ideal [human proportions](https://en.wikipedia.org/wiki/Body_proportions "Body proportions"), derived from Vitruvius but refined through his own observations, contemporary works, and the treatise *[De pictura](https://en.wikipedia.org/wiki/De_pictura "De pictura")* by [Leon Battista Alberti](https://en.wikipedia.org/wiki/Leon_Battista_Alberti "Leon Battista Alberti"). Created in Milan, the *Vitruvian Man* likely passed to his student [Francesco Melzi](https://en.wikipedia.org/wiki/Francesco_Melzi "Francesco Melzi"), and later to Venanzio de Pagave, who encouraged engraver Carlo Giuseppe Gerli to publish an [engraving](https://en.wikipedia.org/wiki/Engraving "Engraving") of it, spreading the image widely. It was then owned by [Giuseppe Bossi](https://en.wikipedia.org/wiki/Giuseppe_Bossi "Giuseppe Bossi"), before being acquired in 1822 by the [Gallerie dell'Accademia](https://en.wikipedia.org/wiki/Gallerie_dell%27Accademia "Gallerie dell'Accademia") in Venice, where it remains. Because of its fragility, the drawing is rarely displayed. It was loaned to the [Louvre](https://en.wikipedia.org/wiki/Louvre "Louvre") in 2019 for the 500th anniversary of Leonardo's death.

## Name

The drawing is described by Leonardo's notes as *Le proporzioni del corpo umano secondo Vitruvio*,[^6] variously translated as *The Proportions of the Human Figure after Vitruvius*,[^7] or *Proportional Study of a Man in the Manner of Vitruvius*.[^8] It is much better known as the *Vitruvian Man*.[^6] The art historian [Carlo Pedretti](https://en.wikipedia.org/wiki/Carlo_Pedretti "Carlo Pedretti") lists it as *Homo Vitruvius, study of proportions with the human figure inscribed in a circle and a square*, and later as simply *Homo Vitruvius*.[^9]

## Description

### Composition

The [drawing](https://en.wikipedia.org/wiki/Drawing "Drawing") was executed primarily with pen and light-brown ink, while there are traces of brown wash (watercolor).[^10] [^1] The paper measures 34.4 cm × 25.5 cm (13.5 in × 10.0 in), larger than most of Leonardo's *folio* manuscript sheets,[^2] while the paper itself was originally made somewhat unevenly, given its irregular edges.[^5] Close examination of the drawing reveals that it was meticulously prepared, and is devoid of "sketchy and tentative" lines.[^12] Leonardo used [metalpoint](https://en.wikipedia.org/wiki/Metalpoint "Metalpoint") with a [calipers](https://en.wikipedia.org/wiki/Calipers "Calipers") and [compass](https://en.wikipedia.org/wiki/Compass_\(drawing_tool\) "Compass (drawing tool)") to make precise lines, and small tick marks were used for measurements.[^10] [^12] These compass marks demonstrate an inner structure of "measured intervals" which is displayed in tandem with the general structure created by the geometric figures.[^13]

The *Vitruvian Man* depicts a nude man facing forward, surrounded by a square and a circle.[^6] The man is portrayed in different stances simultaneously: an "X" pose and a ["T" pose](https://en.wikipedia.org/wiki/T-pose "T-pose"). For the former, his arms are stretched diagonally above his shoulders and his legs widely parted so that his feet and hands touch the edge of the circle centred on his navel. For the latter, his arms are outstretched horizonally and his legs are together, so that his hands, head and feet all touch the perimeter of the square.[^6] The scholar [Carlo Vecce](https://en.wikipedia.org/wiki/Carlo_Vecce "Carlo Vecce") notes that this approach displays multiple phases of movement at once, akin to a photograph.[^14] The man's fingers and toes are arranged carefully as to not breach the surrounding shapes.[^13] Commentators often note that Leonardo went out of his way to create an artistic depiction of the man, rather than a simple portrayal.[^15] [^16] According to the biographer [Walter Isaacson](https://en.wikipedia.org/wiki/Walter_Isaacson "Walter Isaacson"), the use of delicate lines, an intimate stare, and intricate hair curls, "weaves together the human and the divine".[^15] Pedretti notes close similarities between the man and the angel of Leonardo's earlier *[Annunciation](https://en.wikipedia.org/wiki/Annunciation_\(Leonardo\) "Annunciation (Leonardo)")* painting.[^16]

### Text

The text above the image, written in [mirror writing](https://en.wikipedia.org/wiki/Mirror_writing#Notable_examples "Mirror writing"), reads:

> Vetruvio, architecto, mecte nella sua op(er)a d'architectura, chelle misure dell'omo sono dalla natura disstribuite inquessto modo cioè che 4 diti fa 1 palmo, et 4 palmi fa 1 pie, 6 palmi fa un chubito, 4 cubiti fa 1 homo, he 4 chubiti fa 1 passo, he 24 palmi fa 1 homo ecqueste misure son ne' sua edifiti. Settu ap(r)i ta(n)to le ga(m)be chettu chali da chapo 1/14 di tua altez(z)a e ap(r)i e alza tanto le b(r)acia che cholle lunge dita tu tochi la linia della somita del chapo, sappi che 'l cie(n)tro delle stremita delle ap(er)te me(m)bra fia il bellicho. Ello spatio chessi truova infralle ga(m)be fia tria(n)golo equilatero.[^17]

> Vitruvius, the architect, says in his architectural work that the measurements of man are in nature distributed in this manner, that is 4 fingers make a palm, 4 palms make a foot, 6 palms make a cubit, 4 cubits make a man, 4 cubits make a footstep, 24 palms make a man and these measures are in his buildings. If you open your legs enough that your head is lowered by 1/14 of your height and raise your arms enough that your extended fingers touch the line of the top of your head, let you know that the center of the ends of the open limbs will be the navel, and the space between the legs will be an [equilateral triangle](https://en.wikipedia.org/wiki/Equilateral_triangle "Equilateral triangle").[^17]

And below:

> Tanto ap(r)e l'omo nele b(r)accia, qua(n)to ella sua alteza. Dal nasscimento de chapegli al fine di sotto del mento è il decimo dell'altez(z)a del(l)'uomo. Dal di socto del mento alla som(m)ità del chapo he l'octavo dell'altez(z)a dell'omo. Dal di sop(r)a del pecto alla som(m)ità del chapo fia il sexto dell'omo. Dal di sop(r)a del pecto al nasscime(n)to de chapegli fia la sectima parte di tucto l'omo. Dalle tette al di sop(r)a del chapo fia la quarta parte dell'omo. La mag(g)iore larg(h)ez(z)a delle spalli chontiene insè \[la oct\] la quarta parte dell'omo. Dal gomito alla punta della mano fia la quarta parte dell'omo, da esso gomito al termine della isspalla fia la octava parte d'esso omo; tucta la mano fia la decima parte dell'omo. Il menb(r)o birile nasscie nel mez(z)o dell'omo. Il piè fia la sectima parte dell'omo. Dal di socto del piè al di socto del ginochio fia la quarta parte dell'omo. Dal di socto del ginochio al nasscime(n)to del memb(r)o fia la quarta parte dell'omo. Le parti chessi truovano infra il me(n)to e 'l naso e 'l nasscime(n)to de chapegli e quel de cigli ciasscuno spatio p(er)se essimile alloreche è 'l terzo del volto.[^18]

> The length of the outspread arms is equal to the height of the man. From the hairline to the bottom of the chin is one-tenth of the height of the man. From below the chin to the top of the head is one-eighth of the height of the man. From above the chest to the top of the head is one-sixth of the height of the man. From above the chest to the hairline is one-seventh of the height of a man. From the chest to the head is a quarter of the height of the man. The maximum width of the shoulders contains a quarter of the man. From the elbow to the tip of the hand is a quarter of the height of a man; the distance from the elbow to the armpit is one-eighth of the height of the man; the length of the hand is one-tenth of the man. The virile member is at the half height of the man. The foot is one-seventh of the man. From below the foot to below the knee is a quarter of the man. From below the knee to the root of the member is a quarter of the man. The distances from the chin to the nose and the hairline and the eyebrows are equal to the ears and one-third of the face.[^18]

## Background

### Historical context

The moderately successful architect and engineer [Vitruvius](https://en.wikipedia.org/wiki/Vitruvius "Vitruvius") lived from c. 80 – c. 20 BCE, primarily in the [Roman Republic](https://en.wikipedia.org/wiki/Roman_Republic "Roman Republic").[^19] He is best known for authoring *[De architectura](https://en.wikipedia.org/wiki/De_architectura "De architectura")* (*On Architecture*), later called the *Ten Books on Architecture*, which is the only substantial architecture treatise that survives from antiquity.[^20] The work's third volume includes a discussion concerning [body proportions](https://en.wikipedia.org/wiki/Body_proportions "Body proportions"),[^5] where the figures of a man in a circle and a square are respectively referred to as *homo ad circulum*, *homo ad quadratum*.[^19] Vitruvius explained that:

> In a temple there ought to be harmony in the symmetrical relations of the different parts to the whole. In the human body, the central point is the navel. If a man is placed flat on his back, with his hands and feet extended, and a compass centered at his navel, his fingers and toes will touch the circumference of a circle thereby described. And just as the human body yields a circular outline, so too a square may be found from it. For if we measure the distance from the soles of the feet to the top of the head, and then apply that measure to the outstretched arms, the breadth will be found to be the same as the height, as in the case of a perfect square.

— Vitruvius in *De architectura*, [book three, chapter one](https://en.wikisource.org/wiki/Page:Vitruvius_the_Ten_Books_on_Architecture.djvu/103 "s:Page:Vitruvius the Ten Books on Architecture.djvu/103") [^21]

19th-century historians often postulated that Leonardo had no substantial inspiration from the ancient world, propagating his stance as a "modern genius" who rejected all of classicism.[^22] This has been heavily disproven by many documented accounts from Leonardo's colleagues or records of him either owning, reading, and being influenced by writings from antiquity.[^22] The treatise of Vitruvius was long kept obscurely in monk's manuscript copies, but "rediscovered" in the 15th century by [Poggio Bracciolini](https://en.wikipedia.org/wiki/Poggio_Bracciolini "Poggio Bracciolini") among works such as *[De Rerum natura](https://en.wikipedia.org/wiki/De_rerum_natura "De rerum natura")*.[^20] Many artists then attempted to design figures which would satisfy Vitruvius' description, with the earliest being three such images by [Francesco di Giorgio Martini](https://en.wikipedia.org/wiki/Francesco_di_Giorgio_Martini "Francesco di Giorgio Martini") around the 1470s.[^23] [^6] Leonardo may have been influenced by the architect [Giacomo Andrea](https://en.wikipedia.org/wiki/Giacomo_Andrea "Giacomo Andrea"), with whom he records as having dined, in 1490.[^24] Andrea created his own Vitruvian Man drawing that year, which was unknown to scholars until the 1980s.[^24]

- ![A Vitruvian Man depiction in the edition of De Architectura by Vitruvius; illustrated edition by Cesare Cesariano, 1521](https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/De_Architectura030.jpg/330px-De_Architectura030.jpg)
	A Vitruvian Man depiction in the edition of De Architectura by Vitruvius; illustrated edition by Cesare Cesariano, 1521
	A *Vitruvian Man* depiction in the edition of *[De Architectura](https://en.wikipedia.org/wiki/De_Architectura "De Architectura")* by [Vitruvius](https://en.wikipedia.org/wiki/Vitruvius "Vitruvius"); illustrated edition by [Cesare Cesariano](https://en.wikipedia.org/wiki/Cesare_Cesariano "Cesare Cesariano"), 1521
- ![One of Francesco di Giorgio Martini's three attempts at creating the ideal "Vitruvian Man"](https://upload.wikimedia.org/wikipedia/commons/2/24/FGMartini1.jpg)
	One of Francesco di Giorgio Martini's three attempts at creating the ideal "Vitruvian Man"
	One of [Francesco di Giorgio Martini](https://en.wikipedia.org/wiki/Francesco_di_Giorgio_Martini "Francesco di Giorgio Martini") 's three attempts at creating the ideal "Vitruvian Man"
- ![A "Vitruvian Man" prototype by Giacomo Andrea, 1490](https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Vitruvian_Man_by_Giacomo_Andrea.jpg/500px-Vitruvian_Man_by_Giacomo_Andrea.jpg)
	A "Vitruvian Man" prototype by Giacomo Andrea, 1490
	A "Vitruvian Man" prototype by [Giacomo Andrea](https://en.wikipedia.org/wiki/Giacomo_Andrea "Giacomo Andrea"), 1490

### Creation

![](https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Leonardo_da_Vinci_-_RCIN_919131%2C_Recto_The_proportions_of_the_arm.jpg/330px-Leonardo_da_Vinci_-_RCIN_919131%2C_Recto_The_proportions_of_the_arm.jpg)

The proportions of the arm, a drawing by Leonardo which was probably in preparation for the Vitruvian Man

Leonardo's version of the *Vitruvian Man* corrected inaccuracies in Vitruvius's account, particularly related to the head, due to use of book two of the *[De pictura](https://en.wikipedia.org/wiki/De_pictura "De pictura")* by [Leon Battista Alberti](https://en.wikipedia.org/wiki/Leon_Battista_Alberti "Leon Battista Alberti").[^5] Earlier drawings of the same subject "assumed that the circle and square should be centered around the navel", akin to Vitruvius's account, while Leonardo made the scheme work by using the man's genitals as the center of the square, and the navel as the center of the circle.[^13] It is likely that Leonardo's drawings dated to 1487–1490, and entitled *The proportions of the arm*, were related to the *Vitruvian Man*, possibly serving as preparatory sketches.[^25]

Some commentators have speculated that Leonardo incorporated the [golden ratio](https://en.wikipedia.org/wiki/Golden_ratio "Golden ratio") in the drawing, possibly due to his illustrations of [Luca Pacioli](https://en.wikipedia.org/wiki/Luca_Pacioli "Luca Pacioli") 's *[Divina proportione](https://en.wikipedia.org/wiki/Divina_proportione "Divina proportione")*, partially plagiarized from [Piero della Francesca](https://en.wikipedia.org/wiki/Piero_della_Francesca "Piero della Francesca"),[^26] [^3] concerning the ratio.[^27] [^28] However, the *Vitruvian Man* is likely to have been drawn before Leonardo met Pacioli, and there has been doubt over the accuracy of such an observation.[^29] As architectural scholar Vitor Murtinho explains, a circle tangent to the base of a square, with the radius and square sides related by the golden ratio, would pass exactly through the top two corners of the square, unlike Leonardo's drawing. He suggests instead constructions based on a [regular octagon](https://en.wikipedia.org/wiki/Regular_octagon "Regular octagon") or on the [vesica piscis](https://en.wikipedia.org/wiki/Vesica_piscis "Vesica piscis").[^29]

Leonardo's drawing is almost always dated to around 1490 during his [first Milanese period](https://en.wikipedia.org/wiki/Leonardo_da_Vinci#First_Milanese_period_\(c._1482%E2%80%931499\) "Leonardo da Vinci").[^19] [^30] The exact dating is not completely agreed upon and earlier generations of art historians, including [Arthur E. Popham](https://en.wikipedia.org/wiki/Arthur_E._Popham "Arthur E. Popham"), frequently dated the work anywhere from 1485 to 1490.[^5] Two leading art historians differ in this respect; [Martin Kemp](https://en.wikipedia.org/wiki/Martin_Kemp_\(art_historian\) "Martin Kemp (art historian)") gives c. 1487,[^8] [^4] while [Carmen C. Bambach](https://en.wikipedia.org/wiki/Carmen_C._Bambach "Carmen C. Bambach") contends that the earliest possible date—which "one may not entirely discount"—is 1488.[^5] Bambach, in addition to Pedretti, Giovanna Nepi Scirè and Annalisa Perissa Torrini give a slightly broader range of c. 1490–1491.[^11] Bambach explains that this range fits "best with the manner of exact, engraving-like parallel hatching contained within robust pen-and-ink outlines, over traces of lead paint, stylus-ruling, and compass composition".[^5]

### Provenance

After Leonardo's death, the drawing most likely passed to his student [Francesco Melzi](https://en.wikipedia.org/wiki/Francesco_Melzi "Francesco Melzi") (1491–1570),[^5] who was [bequeathed](https://en.wikipedia.org/wiki/Bequest "Bequest") most of Leonardo's possessions.[^31] From then on, the drawing's provenance history is almost certain: it found its way to [Cesare Monti](https://en.wikipedia.org/wiki/Cesare_Monti "Cesare Monti") (1594–1650), was passed to his heir Anna Luisa Monti, then to the De Page family, first [Venanzio de Pagave](https://en.wikipedia.org/w/index.php?title=Venanzio_de_Pagave&action=edit&redlink=1 "Venanzio de Pagave (page does not exist)") (in 1777) and then his son Gaudenzio de Page.[^5] [^32] While owned by the elder De Page, he convinced the engraver Carlo Giuseppe Gerli to publish a book of Leonardo's drawings, which would be the first widespread dissemination of the *Vitruvian Man* and many other Leonardo drawings.[^33] The younger de Page sold the drawing to [Giuseppe Bossi](https://en.wikipedia.org/wiki/Giuseppe_Bossi "Giuseppe Bossi"), who described, discussed, and illustrated it in the fourth chapter of his 1810 monograph on Leonardo's *[The Last Supper](https://en.wikipedia.org/wiki/The_Last_Supper_\(Leonardo\) "The Last Supper (Leonardo)")*, *Del Cenacolo di Leonardo da Vinci* (*On The Last Supper of Leonardo da Vinci*).[^34] This chapter was published as a stand-alone study the next year *Delle opinion di Leonardo da Vinci intorno alla simmetria de' corpi umani* (*On the opinions of Leonardo da Vinci regarding the symmetry of human bodies*).[^34] After Bossi's death in 1815, the drawing was sold to the abbot Luigi Celotti in 1818, and entered into the Venetian [Gallerie dell'Accademia](https://en.wikipedia.org/wiki/Gallerie_dell%27Accademia "Gallerie dell'Accademia") 's collection in 1822, where it has since remained.[^5] Because of its high artistic quality and its well-recorded history of provenance, Leonardo's authorship of the *Vitruvian Man* has never been doubted.[^5]

The *Vitruvian Man* is rarely displayed as extended exposure to light would cause fading; it is kept on the fourth floor of the Gallerie dell'Accademia, in a locked room.[^35] In 2019, the [Louvre](https://en.wikipedia.org/wiki/Louvre "Louvre") requested to borrow the drawing for their monumental *Léonard de Vinci* exhibition, which celebrated the 500th anniversary of the artist's death.[^36] They faced substantial resistance from the heritage group [Italia Nostra](https://en.wikipedia.org/wiki/Italia_Nostra "Italia Nostra"), who contended that the drawing was too fragile to be transported, and filed a lawsuit.[^37] At a hearing on 16 October 2019, a judge ruled that the group had not proven their claim, but set a maximum amount of light for the drawing to be exposed to as well as a subsequent rest period to offset its overall exposure to light.[^38] The Louvre promised to lend paintings by [Raphael](https://en.wikipedia.org/wiki/Raphael "Raphael") to Italy for his own 500th death anniversary; Italy's Minister for Cultural Affairs [Dario Franceschini](https://en.wikipedia.org/wiki/Dario_Franceschini "Dario Franceschini") stated that "Now a great cultural operation can start between Italy and France on the two exhibitions about Leonardo in France and Raphael in Rome." [^39]

### Legal dispute

In 2022, the Gallerie dell'Accademia, which owns the drawing, sued German jigsaw puzzle manufacturer [Ravensburger](https://en.wikipedia.org/wiki/Ravensburger "Ravensburger") for reproducing the artwork in one of the company's jigsaw puzzles. Ravensburger started selling the 1,000-piece jigsaw puzzle in Italy in 2009 and in 2019 the museum sent the company a [cease-and-desist letter](https://en.wikipedia.org/wiki/Cease-and-desist_letter "Cease-and-desist letter") and demanded 10% of the revenue. Ravensburger refused to comply and subsequently was sued by the museum under Italy's 2004 [Cultural Heritage and Landscape Code](https://en.wikipedia.org/w/index.php?title=Cultural_Heritage_and_Landscape_Code&action=edit&redlink=1 "Cultural Heritage and Landscape Code (page does not exist)") which governs reproductions of works deemed to be under Italy's cultural heritage. In its objections, the German company claimed that it had the right to reproduce the artwork because it was already in the [public domain](https://en.wikipedia.org/wiki/Public_domain "Public domain") for centuries, and that the reproduction had occurred outside Italy and thus was not subject to Italy's Cultural Heritage Code. An Italian court rejected Ravensburger's arguments and decided in favor of the museum.[^40] In a ruling dated 17 November 2022, the court ordered the puzzle company to cease producing the product for commercial purposes and levied a fine of 1,500 euros for every day that the company failed to comply.[^41] [^42] [^43] In March 2024, a German court ruled in favor of the company, stating that the Cultural Heritage Code is not applicable outside Italy, and therefore a violation of the sovereignty of the individual states. In response, an Italian government official argues they will challenge this "abnormal" German ruling even before the European and international courts.[^44]

Licensing fees for famous artworks are an important source of income for Italian museums, and Italian law says that museums owning famous public domain works hold the copyright on those works forever and can control who is allowed to make copies and derivative works of them.[^40]

## Legacy

![](https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Skylab2-Patch.png/250px-Skylab2-Patch.png) ![](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Space_suit_patch.jpg/250px-Space_suit_patch.jpg)

(left) Patch of the [Skylab 3](https://en.wikipedia.org/wiki/Skylab_3 "Skylab 3") mission (erroneously written as 2), showing the *Vitruvian Man* in the center; (right) [NASA](https://en.wikipedia.org/wiki/NASA "NASA") 's [Extravehicular Mobility Unit](https://en.wikipedia.org/wiki/Extravehicular_Mobility_Unit "Extravehicular Mobility Unit") *Vitruvian Spaceman* patch ([Space Shuttle](https://en.wikipedia.org/wiki/Space_Shuttle "Space Shuttle") version, with three stars representing NASA's [human spaceflight programs](https://en.wikipedia.org/wiki/Human_spaceflight_programs "Human spaceflight programs"))

The *Vitruvian Man* is often considered an archetypal representative of the [High Renaissance](https://en.wikipedia.org/wiki/High_Renaissance "High Renaissance"), just as Leonardo himself came to represent the archetypal [Renaissance man](https://en.wikipedia.org/wiki/Renaissance_man "Renaissance man").[^45] It holds a unique distinction in aligning art, mathematics, science, classicism, and naturalism.[^46] The art historian [Ludwig Heinrich Heydenreich](https://en.wikipedia.org/wiki/Ludwig_Heinrich_Heydenreich "Ludwig Heinrich Heydenreich"), writing for *[Encyclopædia Britannica](https://en.wikipedia.org/wiki/Encyclop%C3%A6dia_Britannica "Encyclopædia Britannica")*, states, "Leonardo envisaged the great picture chart of the human body he had produced through his anatomical drawings and *Vitruvian Man* as a *cosmografia del minor mondo* (' [cosmography](https://en.wikipedia.org/wiki/Cosmography "Cosmography") of the [microcosm](https://en.wikipedia.org/wiki/Macrocosm_and_microcosm "Macrocosm and microcosm") '). He believed the workings of the human body to be an analogy, in microcosm, for the workings of the universe." [^47]

Kemp calls the drawing "the world's most famous drawing",[^13] while Bambach describes it as "justly ranked among the all-time iconic images of [Western civilization](https://en.wikipedia.org/wiki/Western_culture "Western culture") ".[^5] Reflecting on its fame, Bambach further stated in 2019 that "the endless recent fetishizing of the image by modern commerce through ubiquitous reproductions (in popular books, advertising, and the [Euro coin](https://en.wikipedia.org/wiki/Italian_euro_coins "Italian euro coins")) has kidnapped it from the realm of Renaissance drawing, making it difficult for the viewer to appreciate it as a work of nuanced, creative expression." [^5]

[^1]: Older sources such as [Kemp (1981](#CITEREFKemp1981), p. 116) and [Arasse (1998](#CITEREFArasse1998), p. 105) do not mention any watercolor, though this is clearly stated in newer studies such as [Bambach (2019a](#CITEREFBambach2019a), p. 221) and [Zöllner (2019](#CITEREFZöllner2019), p. 399).

[^2]: Most of Leonardo's *folio* manuscript sheets range anywhere from 29 cm × 22 cm (11.4 in × 8.7 in) to 31.5 cm × 22 cm (12.4 in × 8.7 in).[^11] Bambach notes that many of these smaller *folio* sheets were probably once larger, and later reduced in size for bindings.[^5]

[^3]: The third section of Pacioli's *[Divina proportione](https://en.wikipedia.org/wiki/Divina_proportione "Divina proportione")* is essentially an uncredited Italian translation of della Francesca's *[De quinque corporibus regularibus](https://en.wikipedia.org/wiki/De_quinque_corporibus_regularibus "De quinque corporibus regularibus")* [^26]

[^4]: The unexplained dating of the drawing to 1497 in [Kemp (2019](#CITEREFKemp2019), p. 85) is almost certainly a typo, which was meant to be the 1487 that [Kemp (1981](#CITEREFKemp1981), p. 116) gives.

[^5]: [Bambach (2019a)](#CITEREFBambach2019a), p. 224.

[^6]: [Palmer (2018)](#CITEREFPalmer2018), p. 153.

[^7]: [Zöllner (2015)](#CITEREFZöllner2015), p. 37.

[^8]: [Kemp (1981)](#CITEREFKemp1981), p. 116.

[^9]: [Pedretti (2006)](#CITEREFPedretti2006), pp. 80–82.

[^10]: [Bambach (2019a)](#CITEREFBambach2019a), p. 221.

[^11]: [Bambach (2019b)](#CITEREFBambach2019b), p. 237.

[^12]: [Isaacson (2017)](#CITEREFIsaacson2017), p. 155.

[^13]: [Kemp (2019)](#CITEREFKemp2019), p. 85.

[^14]: [Vecce (2003)](#CITEREFVecce2003), p. 70.

[^15]: [Isaacson (2017)](#CITEREFIsaacson2017), p. 156.

[^16]: [Pedretti (2006)](#CITEREFPedretti2006), p. 82.

[^17]: [Magazù, Coletta & Migliardo (2019)](#CITEREFMagazùColettaMigliardo2019), p. 759.

[^18]: [Magazù, Coletta & Migliardo (2019)](#CITEREFMagazùColettaMigliardo2019), p. 760.

[^19]: [Zöllner (2019)](#CITEREFZöllner2019), p. 112.

[^20]: [Isaacson (2017)](#CITEREFIsaacson2017), p. 149.

[^21]: [Isaacson (2017)](#CITEREFIsaacson2017), p. 150.

[^22]: [Marani (2003)](#CITEREFMarani2003), p. 210.

[^23]: [Isaacson (2017)](#CITEREFIsaacson2017), p. 151.

[^24]: [Isaacson (2017)](#CITEREFIsaacson2017), pp. 152–153.

[^25]: [Syson et al. (2011)](#CITEREFSysonKeithGalansinoMazzotta2011), p. 150.

[^26]: [Mackinnon (1993)](#CITEREFMackinnon1993), p. 165.

[^27]: [Bambach (2019a)](#CITEREFBambach2019a), p. 225.

[^28]: [Bambach (2019b)](#CITEREFBambach2019b), p. 238.

[^29]: [Murtinho (2015)](#CITEREFMurtinho2015).

[^30]: [Arasse (1998)](#CITEREFArasse1998), p. 105.

[^31]: [Kemp (2003)](#CITEREFKemp2003), §1 "Life and works".

[^32]: [Perissa Torrini (2009)](#CITEREFPerissa_Torrini2009), p. 17.

[^33]: [Turner (1993)](#CITEREFTurner1993), pp. 84–85.

[^34]: [Mara (2019)](#CITEREFMara2019), p. 280.

[^35]: [Isaacson (2017)](#CITEREFIsaacson2017), p. 153.

[^36]: [Giuffrida (2019)](#CITEREFGiuffrida2019), § paras. 1–3.

[^37]: [Giuffrida (2019)](#CITEREFGiuffrida2019), § para. 2.

[^38]: [Prisco (2019)](#CITEREFPrisco2019), § paras. 5–6.

[^39]: [Prisco (2019)](#CITEREFPrisco2019), § para. 7.

[^40]: Barry, Colleen (28 March 2024). ["A fight to protect the dignity of Michelangelo's David raises questions about freedom of expression"](https://apnews.com/article/michelangelo-david-statue-italy-protection-heritage-3fa1b7185fea36003e064fa6e2c309fd). *AP News*. Retrieved 29 March 2024.

[^41]: [Dafoe (2023)](#CITEREFDafoe2023).

[^42]: [Gallo (2023)](#CITEREFGallo2023).

[^43]: [Borgogni (2023)](#CITEREFBorgogni2023).

[^44]: Taylor, Derrick Bryson (10 April 2024). ["Da Vinci's Been Dead for 500 Years. Who Gets to Profit from His Work?"](https://www.nytimes.com/2024/04/10/world/europe/vitruvian-man-puzzle-leonardo-da-vinci-ravensburger.html). *The New York Times*. Retrieved 24 May 2024.

[^45]: [Holberton (2003)](#CITEREFHolberton2003), § para. 13.

[^46]: [Marani (2003)](#CITEREFMarani2003), p. 219.

[^47]: [Heydenreich (2022)](#CITEREFHeydenreich2022), § "Anatomical studies and drawings of Leonardo da Vinci".