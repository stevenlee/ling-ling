---
人體解剖學: human-anatomy
公共領域: public-domain
數位典藏: digital-collection
文藝復興: renaissance
模型訓練: model-training
機器學習: machine-learning
版權: copyright
統計學: statistics
自然語言處理: natural-language-processing
著作權: copyright
藝術史: art-history
語言模型: language-model
資料分析: data-analysis
資料科學: data-science
資訊資源: information-resource
達文西: da-vinci
電子書: ebook
電子書資源: e-book-resources
---
# 標籤對照定義 (Tag Map)
系統會自動從此處讀取標籤對照關係。您可以直接在 Obsidian 的「屬性 (Properties)」介面中新增或修改對照。
