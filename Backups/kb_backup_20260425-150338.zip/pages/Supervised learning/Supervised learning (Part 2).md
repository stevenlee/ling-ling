---
title: Supervised learning (Part 2)
type: concept
date_created: '2026-04-25'
tags:
- data-science
- machine-learning
- model-training
- 模型訓練
- 機器學習
- 資料科學
---
# 監督式學習的挑戰與模型選擇標準 (Supervised Learning Challenges and Selection Criteria)
## 摘要
本筆記深入探討了在實施監督式學習時，模型可能面臨的三大挑戰：目標變數的雜訊（Noise）、輸入特徵的異質性（Heterogeneity）、特徵的冗餘性（Redundancy）以及複雜的非線性交互作用（Non-linear Interactions）。了解這些挑戰有助於工程師選擇最合適的學習演算法，並指導數據預處理的策略，以提高模型的泛化能力。

## 核心概念

### 1. 目標變數的雜訊處理 (Noise in Target Variables)
當目標變數（Target Variable）本身包含錯誤（如人類或感測器錯誤）時，模型若試圖完美擬合這些雜訊，將導致**過擬合 (Overfitting)**。
*   **雜訊類型:**
    *   **隨機雜訊 (Stochastic Noise):** 源於測量誤差的隨機波動。
    *   **確定性雜訊 (Deterministic Noise):** 指目標函數中無法被模型捕捉的、結構性的部分，會「污染」訓練資料。
*   **應對策略:** 應傾向於使用**高偏差、低方差 (Higher Bias, Lower Variance)** 的估計器，而非追求極低的偏差。
*   **實務方法:** 實施**早期停止 (Early Stopping)**、執行**異常檢測 (Anomaly Detection)**，或在訓練前移除可疑的雜訊樣本，以減少**泛化誤差 (Generalization Error)**。

### 2. 數據特徵的結構化考量
選擇演算法前，必須評估輸入特徵的結構特性，這決定了哪些模型表現最佳。

*   **特徵異質性 (Heterogeneity):** 若特徵包含多種類型（離散、有序離散、計數、連續），某些模型（如決策樹）能輕鬆處理，而其他模型（如SVM、NN）則要求特徵必須是數值化且經過標準化（Scaling）處理。
*   **特徵冗餘性 (Redundancy):** 當輸入特徵間存在高度相關性時，某些基於距離的方法（如線性迴歸、KNN）會因數值不穩定而表現不佳。此問題通常可透過**正則化 (Regularization)** 來緩解。
*   **非線性與交互作用 (Non-linearities & Interactions):**
    *   如果特徵貢獻獨立，線性模型（如線性迴歸）表現良好。
    *   如果存在複雜的特徵間交互作用，則決策樹和神經網路等能主動發現交互作用的模型表現更佳。

## 深度分析

### 偏差-方差權衡與雜訊的影響
雜訊的存在使得模型無法區分「真實的信號」和「隨機的雜訊」。過度擬合的本質就是模型過度關注了訓練資料中的雜訊，導致模型在未見過的資料上表現極差。因此，在雜訊環境下，接受一定的模型偏差（即模型不完美擬合訓練數據）以換取更穩定的低方差，是更穩健的選擇。

### 最佳實踐：數據優先於調參
在實際工程應用中，調整學習演算法的超參數（Tuning）極為耗時。經驗法則指出，在資源有限的情況下，投入更多時間收集**更多、更具資訊量**的訓練數據和特徵，其效益往往遠大於花費時間對演算法進行精細的超參數調優。

### 演算法選擇流程圖
本流程圖概述了從專案啟動到模型選擇的決策路徑，強調了數據分析在決策中的核心地位。

```mermaid
graph TD
    A(("開始專案: 選擇學習演算法")) --> B{數據分析與特徵評估};
    B --> C{數據是否異質？};
    C -- 是 (混合類型) --> D[首選: 決策樹 (Decision Trees)];
    C -- 否 (純數值) --> E{是否存在高度相關/冗餘特徵？};
    E -- 是 (冗餘) --> F[預處理: 應用正則化 (Regularization)];
    E -- 否 (乾淨) --> G{是否存在複雜的非線性交互作用？};
    G -- 是 (複雜) --> H[考慮: 神經網路 (Neural Networks) 或 決策樹];
    G -- 否 (線性) --> I[考慮: 線性迴歸 (Linear Regression) 或 SVM];
    D --> J[Cross-Validation 驗證];
    F --> J;
    H --> J;
    I --> J;
    J --> K{模型性能評估};
    K -- 性能不佳 --> B;
    K -- 性能優異 --> L(("完成模型部署"));
```

---
[[Supervised learning (Part 1)|← 上一頁]] | 第 2 / 6 | [[Supervised learning (Part 3)|下一頁 →]]