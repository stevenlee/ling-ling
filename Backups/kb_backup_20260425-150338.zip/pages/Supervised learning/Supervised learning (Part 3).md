---
title: Supervised learning (Part 3)
type: concept
date_created: '2026-04-25'
tags:
- data-science
- machine-learning
- model-training
- 模型訓練
- 機器學習
- 資料科學
---
# Supervised Learning
## 摘要
監督學習（Supervised Learning）是機器學習中最基礎且最廣泛使用的範式。它依賴於**帶標籤的訓練資料**（Labeled Data），即每組輸入特徵向量 $x_i$ 都配對了對應的正確輸出標籤 $y_i$。學習的目標是訓練一個函數 $g: X \to Y$，該函數能夠從輸入空間 $X$ 映射到輸出空間 $Y$，從而預測未見資料的標籤。

## 核心概念
### 1. 學習目標與模型建立
監督學習的核心是尋找一個最佳的預測函數 $g$。
*   **輸入與輸出**: 訓練資料組成的形式為 $\{(x_{1}, y_{1}), \dots, (x_{N}, y_{N})\}$，其中 $x_i$ 是特徵向量（Feature vector），$y_i$ 是對應的標籤（Label）。
*   **假設空間 (Hypothesis Space, $G$)**: 這是所有可能的候選函數 $g$ 所構成的集合。學習演算法的任務就是從這個巨大的空間中，選出一個最能代表資料規律的函數。
*   **預測機制**: 函數 $g$ 通常透過一個**評分函數 (Scoring Function, $f$)** 來定義，最終預測的標籤 $g(x)$ 是使 $f(x, y)$ 達到最高分的 $y$ 值。
*   **概率模型**: 許多演算法採用概率模型來定義 $g$，例如：
    *   **條件機率模型**: $g(x) = \underset{y}{\arg \max } P(y|x)$ (如：邏輯迴歸)。
    *   **聯合機率模型**: $f(x, y) = P(x, y)$ (如：朴克分類器)。

### 2. 評估與優化方法
為了確定哪個函數 $g$ 是最好的，需要定義「損失」和「風險」。
*   **損失函數 (Loss Function, $L$)**: 用來衡量模型預測值 $\hat{y}$ 與真實標籤 $y_i$ 之間差異的指標。
*   **風險 (Risk, $R(g)$)**: 函數 $g$ 的期望損失，代表模型在整個資料分佈上的平均錯誤率。
*   **經驗風險最小化 (Empirical Risk Minimization, ERM)**: 這是最常見的優化方法，它尋找最小化**訓練資料**上的平均損失 $R_{emp}(g)$ 的函數 $g$。
*   **結構風險最小化 (Structural Risk Minimization, SRM)**: 這是對 ERM 的修正，它引入了**懲罰函數 (Penalty Function)** 來控制模型在擬合訓練資料（偏差 Bias）與泛化能力（方差 Variance）之間的權衡。

## 深度分析
### 演算法類型概述
監督學習涵蓋了多種成熟的演算法，它們在數學原理和應用場景上各有側重：
*   **線性模型**: 如線性迴歸 (Linear regression) 和邏輯迴歸 (Logistic regression)，適用於假設資料關係是線性的場景。
*   **基於距離的模型**: 如 $k$-近鄰 (k-Nearest Neighbors, k-NN)，其預測依賴於輸入點在特徵空間中的鄰近點。
*   **決策樹與集成學習**: 如決策樹 (Decision trees)，通過樹狀結構進行決策分類，常被用於構建集成模型。
*   **概率模型**: 如朴克分類器 (Naive Bayes)，基於貝葉斯定理，假設特徵間相互獨立。
*   **神經網路**: 如多層感知器 (Multilayer perceptron)，模仿人腦結構，能夠學習高度非線性的複雜模式。

### 數學等價性與過擬合風險
*   **ERM 與 MLE 的關係**: 當 $g$ 是條件機率分佈 $P(y|x)$ 且損失函數 $L(y, \hat{y}) = -\log P(y|x)$ 時，經驗風險最小化（ERM）等價於**最大概似估計 (Maximum Likelihood Estimation, MLE)**。
*   **過擬合 (Overfitting)**: 當假設空間 $G$ 過大，或訓練資料量不足時，模型可能會過度記憶訓練資料的雜訊和特徵，導致在未見的測試資料上表現極差（高方差）。

## 流程圖：監督學習的運作機制

mermaid
graph TD
    subgraph "輸入層"
        A["帶標籤訓練資料 (X, Y)"] --> B{定義特徵向量};
        B --> C["特徵空間 X"];
    end

    subgraph "學習過程"
        D["選擇演算法 (e.g., SVM, NN)"] --> E{定義假設空間 G};
        C --> D;
        E --> F["定義損失函數 L"];
        F --> G["優化目標: 最小化風險 R(g)"];
    end

    subgraph "輸出層"
        G --> H{應用優化方法 (ERM / SRM)};
        H --> I["學習到的最佳函數 g"];
        I --> J["預測未標籤資料 (X_new)"];
        J --> K["預測標籤 Y_pred"];
    end

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style K fill:#ccf,stroke:#333,stroke-width:2px
    style G fill:#ffc,stroke:#333,stroke-width:2px

```

---
[[Supervised learning (Part 2)|← 上一頁]] | 第 3 / 6 | [[Supervised learning (Part 4)|下一頁 →]]