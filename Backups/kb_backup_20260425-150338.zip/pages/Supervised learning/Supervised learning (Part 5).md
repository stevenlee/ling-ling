---
title: Supervised learning (Part 5)
type: concept
date_created: '2026-04-25'
tags:
- data-science
- machine-learning
- model-training
- 模型訓練
- 機器學習
- 資料科學
---
# 機器學習演算法與範式 (Machine Learning Algorithms and Paradigms)
## 摘要
本筆記全面概述了機器學習（ML）領域的廣泛方法論、核心演算法和實際應用場景。ML涵蓋了從基於統計學的概率模型（如朴素貝葉斯），到複雜的結構化學習方法（如支持向量機、隨機森林），再到處理複雜數據關係的先進技術（如條件隨機場）。內容涵蓋了資料預處理、模型選擇的理論基礎，並展示了在生物資訊學、自然語言處理和電腦視覺等領域的實際應用。

## 核心概念
機器學習的演算法可以根據其底層的數學原理和處理的數據結構進行分類。

### 1. 經典與統計模型 (Classical & Statistical Models)
這些模型是機器學習的基石，擅長處理分類和迴歸任務。
*   **決策樹與集成學習 (Decision Trees & Ensembles):**
    *   **決策樹學習 (Decision Tree Learning):** 通過樹狀結構進行決策分類。
    *   **隨機森林 (Random Forests):** 一種集成學習方法，通過構建多棵決策樹並取平均或投票來提高模型的穩定性和準確性。
    *   **Boosting (提升機):** 一種元演算法，依序訓練弱學習器，並讓後續模型重點修正前一個模型的錯誤。
*   **概率模型 (Probabilistic Models):**
    *   **朴素貝葉斯分類器 (Naive Bayes Classifier):** 基於貝葉斯定理，假設特徵之間相互獨立的分類器。
    *   **高斯過程迴歸 (Gaussian Process Regression):** 一種非參數的迴歸方法，用概率分佈來表示函數。
    *   **貝葉斯統計學 (Bayesian Statistics):** 採用概率分佈來更新對模型參數的信念。

### 2. 結構化與表示學習 (Structured & Representation Learning)
這些方法著重於捕捉數據中的複雜依賴關係。
*   **支持向量機 (Support Vector Machines, SVM):** 透過在高維特徵空間找到最佳超平面進行分類。
*   **條件隨機場 (Conditional Random Field, CRF):** 用於建模序列數據的聯合概率分佈，特別適合標註任務。
*   **核估計器 (Kernel Estimators):** 利用核函數在特徵空間中進行數據密度估計。
*   **人工神經網路 (Artificial Neural Network, ANN):** 模仿生物神經元結構，通過層級結構進行複雜的非線性映射。

### 3. 學習範式與理論基礎 (Learning Paradigms & Theory)
*   **PAC 學習 (Probably Approximately Correct Learning):** 一個理論框架，定義了機器學習模型在多大程度上可以被保證準確。
*   **符號 vs. 子符號學習 (Symbolic vs. Subsymbolic):** 區分了傳統基於規則和邏輯的學習（符號）與基於數值向量和統計的學習（子符號）。
*   **案例推理 (Case-based Reasoning):** 依據過去類似的案例來解決當前的問題。

## 深度分析
機器學習的實戰應用和理論深化需要關注數據預處理和應用領域的特殊性。

### 數據處理與優化
在實際應用中，數據的質量和結構至關重要。
*   **資料預處理 (Data Pre-processing):** 這是模型訓練前最關鍵的步驟，包括缺失值處理、特徵縮放等。
*   **處理不平衡數據集 (Handling Imbalanced Datasets):** 當類別間的樣本數量極度不平衡時，必須採用過採樣（Oversampling）或欠採樣（Undersampling）等技術來平衡模型訓練。
*   **信息檢索與排名 (Information Retrieval & Learning to Rank):** 在信息檢索系統中，不僅需要檢索相關文檔，還需要對這些文檔進行精確的排序。

### 主要應用領域 (Key Application Domains)
ML技術已滲透到各行各業，形成了專業的應用分支：
*   **電腦視覺 (Computer Vision):** 包含物體識別、圖像分割和光學字符識別 (OCR)。
*   **自然語言處理 (NLP):** 應用於語音識別、信息提取和語義分析。
*   **生物/化學信息學 (Bioinformatics/Cheminformatics):** 利用ML分析基因序列、蛋白質結構和藥物活性關係（如定量結構-活性關係 QSAR）。
*   **數據庫行銷 (Database Marketing):** 進行客戶分群和預測消費行為。

## 演算法流程圖
```mermaid
graph TD
    A[機器學習核心概念] --> B{學習類型};
    B --> C[監督式學習];
    B --> D[非監督式學習];
    B --> E[強化學習];

    C --> C1[分類任務];
    C --> C2[迴歸任務];
    D --> D1[聚類 (Clustering)];
    D --> D2[降維 (Dimensionality Reduction)];

    C1 --> C1a["決策樹/隨機森林"];
    C1 --> C1b["SVM"];
    C1 --> C1c["Naive Bayes"];
    C2 --> C2a["線性迴歸"];
    C2 --> C2b["高斯過程"];

    C1a & C1b & C1c & C2a & C2b --> F[模型訓練與優化];
    F --> G{應用場景};

    G --> G1["電腦視覺 (物體識別)"];
    G --> G2["自然語言處理 (信息提取)"];
    G --> G3["生物資訊學 (基因分析)"];

    subgraph "理論基礎"
        T1[PAC 學習]
        T2[資料預處理]
    end
    T1 --> F;
    T2 --> F;
```

---
[[Supervised learning (Part 4)|← 上一頁]] | 第 5 / 6 | [[Supervised learning (Part 6)|下一頁 →]]