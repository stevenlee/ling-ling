---
title: BERT (language model) (Part 6)
type: entity
date_created: '2026-04-25'
tags:
- Transformer
- 自然語言處理
- 語言模型
---

# BERT (language model)
## 摘要
BERT (Bidirectional Encoder Representations from Transformers) 是一種革命性的預訓練語言模型，它利用 Transformer 架構的編碼器部分，能夠從雙向上下文（Bidirectional Context）學習深層次的語言表徵。與傳統的單向模型不同，BERT 能夠同時考慮一個詞彙在句子前後的上下文信息，極大地提升了模型在下游自然語言理解任務（如問答、文本分類）上的性能。其核心的訓練機制包括遮罩語言建模（MLM）和下一句預測（NSP）。

## 核心概念
### 雙向上下文理解 (Bidirectionality)
BERT 的最大突破在於其雙向性。它不是像 RNN 或傳統 Transformer 那樣依賴單向（從左到右）或雙向（單獨計算前向和後向）的上下文，而是能夠同時獲取輸入序列中所有位置的上下文信息。這使得模型能更精確地理解詞彙的語義和句法角色。

### 遮罩語言建模 (Masked Language Modeling, MLM)
MLM 是 BERT 的核心預訓練任務之一。
*   **機制**: 在訓練階段，模型會隨機地將輸入序列中的部分詞彙（通常是 15%）替換為特殊的 `[MASK]` 標記。
*   **目標**: 模型必須根據周圍未被遮罩的上下文信息，預測出原始被遮罩詞彙最有可能的替換詞彙。
*   **意義**: 這種任務迫使模型學習詞彙的雙向依賴關係和語義上下文，是其強大表徵能力的主要來源。

### 下一句預測 (Next Sentence Prediction, NSP)
NSP 是 BERT 的第二個預訓練任務，用於理解句子間的邏輯關係。
*   **機制**: 模型會接收兩段文本（Sentence A 和 Sentence B），並被要求判斷 Sentence B 是否是緊接在 Sentence A 後面的下一句。
*   **目標**: 判斷的結果是二元的（IsNext 或 NotNext）。
*   **意義**: 這個任務使 BERT 不僅學會了單句的語義，還學會了理解文本的篇章結構和連貫性，這對於需要理解長文本脈絡的任務（如問答系統）至關重要。

## 深度分析
### BERTology：模型的可解釋性與局限性
隨著 BERT 的廣泛應用，學術界產生了大量研究，形成了所謂的「BERTology」。這部分研究重點在於探究模型「如何」工作，而非僅僅「表現多好」。
*   **注意力分析 (Attention Analysis)**: 研究人員深入分析了 BERT 的注意力權重，試圖繪製模型在處理特定任務時「看重」哪些輸入詞彙，從而揭示了模型決策的依據（如 [^18] 的研究）。
*   **模型行為探究**: 許多論文專注於揭示模型內部隱藏的知識、偏差或潛在的語義規則（如 [^17]）。
*   **泛化與限制**: 研究也指出，雖然 BERT 性能強大，但其在處理特定類型的語義推理、常識知識（如 SWAG [^15] 所揭示）或極端長文本時仍存在局限性，這推動了後續模型（如 UL2 [^12]）的發展。

### 訓練與應用流程
BERT 的訓練是一個分階段的過程：
1. **預訓練 (Pre-training)**: 使用海量的、未標記的文本數據，通過 MLM 和 NSP 任務，讓模型學習通用的語言結構和知識。
2. **微調 (Fine-tuning)**: 將預訓練好的 BERT 模型，在特定下游任務（如情感分析、命名實體識別）的少量標記數據上進行額外的訓練，使其適應特定應用場景。

---

## 訓練流程與機制圖表

```mermaid
graph TD
    A[原始文本輸入] --> B{分詞與標記化};
    B --> C1["[MASK] 標記化"];
    B --> C2["句子對 (A, B)"];

    subgraph "預訓練階段 (Pre-training)"
        C1 --> D1[遮罩語言建模 (MLM)];
        C2 --> D2[下一句預測 (NSP)];
        D1 --> E1(計算詞彙預測損失);
        D2 --> E2(計算句子關係損失);
    end

    E1 & E2 --> F[優化器更新權重];
    F --> G{預訓練完成: 獲得通用語義表徵};

    G --> H[下游任務微調 (Fine-tuning)];
    H --> I(特定任務輸出);

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style G fill:#ccf,stroke:#333,stroke-width:2px
    style I fill:#afa,stroke:#333,stroke-width:2px
```

---
[[BERT (language model) (Part 5)|← 上一頁]] | 第 6 / 8 | [[BERT (language model) (Part 7)|下一頁 →]]