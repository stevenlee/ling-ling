---
title: BERT (language model) (Part 7)
type: entity
date_created: '2026-04-25'
tags:
- language-model
- natural-language-processing
- transformer
- 自然語言處理
- 語言模型
---
# BERT (language model)
## 摘要
BERT (Bidirectional Encoder Representations from Transformers) 是一種革命性的預訓練語言模型，它利用 Transformer 架構的編碼器（Encoder）來深入理解文本的雙向上下文依賴關係。與早期僅能單向處理上下文的模型不同，BERT 能夠同時考慮一個詞彙在句子前後的所有資訊，極大地提升了其在下游自然語言處理（NLP）任務（如文本分類、問答系統等）上的表現。其訓練過程主要依賴兩種關鍵的自監督任務：遮蔽語言模型 (MLM) 和下一句預測 (NSP)。

## 核心概念
### 遮蔽語言模型 (Masked Language Modeling, MLM)
MLM 是 BERT 最核心的預訓練任務之一。其原理是隨機地在輸入序列的某些位置遮蔽（Mask）原始的詞彙，然後要求模型根據周圍所有未被遮蔽的上下文資訊，預測出被遮蔽詞彙最有可能的原始詞彙。
*   **目的**：強制模型學習詞彙在語義和語法層面更深層次的雙向上下文表示。
*   **機制**：模型必須同時參考左側和右側的上下文來進行預測，這使得其上下文理解能力遠超單向模型。

### 下一句預測 (Next Sentence Prediction, NSP)
NSP 任務旨在訓練模型理解句子之間的邏輯關係。在訓練時，模型會接收兩組句子 (Sentence A 和 Sentence B)，並需要判斷 Sentence B 是否確實是 Sentence A 的邏輯後續。
*   **目的**：提升模型在處理需要理解篇章結構和語篇連貫性的任務（如問答系統）上的能力。
*   **輸出**：模型會輸出一個二元分類（IsNext/NotNext）來判斷兩句話的相關性。

## 深度分析
### 模型的演進與優化
BERT 的成功引發了整個 NLP 領域的熱潮，並催生了多種優化和改進版本：
1.  **RoBERTa (Robustly Optimized BERT Pretraining Approach)**：研究人員發現，BERT 的原始訓練方式可以進行優化。RoBERTa 透過移除 NSP 任務（認為其可能限制模型能力）並使用更長的訓練時間和更大的資料集，證明了在去除或調整輔助任務後，模型表現可以更穩健。
2.  **DistilBERT**：這是一個「蒸餾」版本，旨在保留 BERT 的大部分性能，但結構更小、速度更快，使其能夠在資源受限的環境中部署，實現「更輕量、更快、更便宜」的應用。
3.  **適用性 (Fine-tuning)**：BERT 的強大之處在於其「預訓練 (Pre-training)」與「微調 (Fine-tuning)」的流程。模型首先在海量通用文本上進行預訓練，學會語言的通用規則；然後，只需在特定下游任務（如情感分析、命名實體識別）的少量標註數據上進行微調，即可達到極高的準確度。

### 總結流程
BERT 的訓練流程可以概括為：**輸入文本 $\xrightarrow{\text{MLM}}$ 預測遮蔽詞 $\xrightarrow{\text{NSP}}$ 判斷句子關係 $\rightarrow$ 輸出高度上下文化的詞向量**。

```mermaid
graph TD
    subgraph "BERT 訓練流程"
        A["原始文本序列"] --> B{MLM 任務};
        B --> C["遮蔽的詞彙 (Masked Tokens)"];
        C --> D["雙向上下文資訊"];
        D --> E(("預測被遮蔽的詞彙"));

        A --> F{NSP 任務};
        F --> G["句子 A 與 句子 B"];
        G --> H(("判斷 B 是否為 A 的後續"));
    end

    E --> I["上下文語義表示 (Contextual Embeddings)"];
    H --> I;
    I --> J["下游任務微調 (Fine-tuning)"];
```

---
[[BERT (language model) (Part 6)|← 上一頁]] | 第 7 / 8 | [[BERT (language model) (Part 8)|下一頁 →]]