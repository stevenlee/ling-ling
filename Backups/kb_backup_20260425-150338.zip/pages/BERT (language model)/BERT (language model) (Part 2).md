---
title: BERT (language model) (Part 2)
type: entity
date_created: '2026-04-25'
tags:
- language-model
- natural-language-processing
- transformer
- 自然語言處理
- 語言模型
---
# BERT (Bidirectional Encoder Representations from Transformers)
## 摘要
BERT 是一種由 Google 開發的、基於 Transformer 架構的預訓練語言模型。它最大的突破在於能夠同時利用輸入序列的雙向上下文資訊（Bidirectional Context），使其能夠深入理解單詞在句子中的語義關係。BERT 的預訓練階段透過「遮罩語言建模 (MLM)」和「下一句預測 (NSP)」兩個任務進行訓練，從而學會了豐富的語言結構知識，並能應用於下游的各種自然語言理解任務。

## 核心概念
### 1. 輸入表示層 (Input Embedding Layer)
BERT 的初始輸入表示不是單純的詞彙嵌入，而是由三個獨立的嵌入向量相加而成，以構建一個完整的初始標記表示：
*   **Token Type Embeddings (詞元類型嵌入):** 根據詞元本身（Token）的類型生成嵌入向量。
*   **Position Embeddings (位置嵌入):** 捕捉詞元在序列中的絕對位置資訊。BERT 使用基於正弦波函數（Sinusoidal Function）的絕對位置嵌入。
*   **Segment Type Embeddings (片段類型嵌入):** 用於區分輸入序列是否由兩個獨立的文本片段組成（例如，問答對的問句和答句）。

這三個嵌入向量相加後，會經過 LayerNorm 正規化，輸出一個固定維度（如 768 維）的初始表示向量。

### 2. 預訓練任務 (Pre-training Tasks)
BERT 的強大能力來自其在兩個核心任務上的預訓練：
*   **遮罩語言建模 (Masked Language Modeling, MLM):** 這是 BERT 最具代表性的任務。模型會隨機遮蔽輸入序列中的部分詞元（通常為 15%），然後學習根據周圍的上下文（雙向）來預測這些被遮蔽的原始詞元。這強制模型必須理解單詞的雙向依賴關係。
*   **下一句預測 (Next Sentence Prediction, NSP):** 模型被訓練來判斷兩個給定的句子之間是否存在邏輯上的連續關係。這使 BERT 不僅理解單詞，還能理解句子層級的語義關係，這對於問答系統等任務至關重要。

## 深度分析
### 1. 架構與維度 (Architecture and Dimensions)
BERT 的核心是 Transformer 的編碼器堆疊 (Encoder Stack)。其架構的參數化非常清晰，主要由兩個可變參數決定：
*   $L$ (Layers): 編碼器層的數量。
*   $H$ (Hidden Size): 隱藏層的維度大小，代表每個詞元表示的維度。

不同的模型版本（如 BERT-BASE, BERT-LARGE）僅是調整 $L$ 和 $H$ 的組合，例如 BERT-BASE 為 $12L/768H$，BERT-LARGE 為 $24L/1024H$。

### 2. MLM 的魯棒性機制
在 MLM 任務中，為了避免訓練數據與實際推理數據分佈不一致（Dataset Shift Problem），BERT 並不會總是將選定的詞元替換為 `[MASK]` 標記。它採用了三種機率分佈，以增加模型的魯棒性：
1.  **80% 機率:** 替換為 `[MASK]` 標記。
2.  **10% 機率:** 替換為一個隨機的詞元。
3.  **10% 機率:** 不進行任何替換。

### 3. 資訊流動總結
輸入詞元 $\rightarrow$ 組合嵌入 (Token + Position + Segment) $\rightarrow$ LayerNorm $\rightarrow$ 經過 $L$ 層 Transformer 編碼器 $\rightarrow$ 輸出高維度上下文向量 $\rightarrow$ 經由線性轉換層 $\rightarrow$ 預測詞彙空間的概率分佈。

## 視覺化流程圖

```mermaid
graph TD
    subgraph "BERT 輸入與嵌入層"
        A[輸入詞元序列] --> B{組合嵌入};
        B --> B1["Token Type Embedding"];
        B --> B2["Position Embedding"];
        B --> B3["Segment Type Embedding"];
        B1 & B2 & B3 --> C[相加與正規化 (LayerNorm)];
    end

    subgraph "Transformer 編碼器堆疊"
        C --> D{Transformer Encoder Blocks (L層)};
        D --> E[輸出上下文向量 (H維)];
    end

    subgraph "預訓練任務"
        E --> F1{MLM 任務};
        E --> F2{NSP 任務};
        F1 --> G1["預測被遮罩的詞元"];
        F2 --> G2["判斷句子間的邏輯關係"];
    end

    D --> H[最終輸出層 (Affine Transform)];
    H --> I["詞彙空間概率分佈"];
```

---
[[BERT (language model) (Part 1)|← 上一頁]] | 第 2 / 8 | [[BERT (language model) (Part 3)|下一頁 →]]