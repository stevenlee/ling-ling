---
title: BERT (language model) (Part 1)
type: entity
date_created: '2026-04-25'
tags:
- Transformer
- 自然語言處理
- 語言模型
---

# BERT (Bidirectional Encoder Representations from Transformers)
## 摘要
BERT 是一種由 Google 研究人員於 2018 年底推出的開源語言模型。它基於 Transformer 的「僅編碼器 (Encoder-only)」架構，其核心能力是透過自監督學習（Self-supervised Learning）來學習文本的上下文相關表徵（Contextual Representations）。與先前僅能單向或雙向處理文本的模型不同，BERT 能夠同時考慮輸入序列中所有詞彙的上下文資訊，極大地提升了自然語言處理 (NLP) 任務的表現，成為後續許多模型和研究的基準點。

## 核心概念
### 1. 雙向上下文學習 (Bidirectional Contextual Learning)
BERT 的最大突破在於其「雙向性」。它不像許多早期模型只看前文來預測下一個詞，而是能同時參考一個詞彙前後的全部上下文來理解該詞的真正含義。這使得它能捕捉到詞彙在特定語境下的深層語義，這被稱為「上下文潛在表徵 (Contextual Latent Representations)」。

### 2. 預訓練任務機制
BERT 的訓練採用了兩種自監督任務來引導模型學習語義：
*   **遮罩式語言模型預測 (Masked Token Prediction, MLM)**：模型會隨機遮蔽輸入文本中的部分詞彙（Token），然後訓練模型根據周圍的上下文來預測這些被遮蔽的詞彙是什麼。
*   **下一句預測 (Next Sentence Prediction, NSP)**：模型需要判斷兩個句子是否是原文中連續的兩句話，這幫助模型理解句子間的邏輯連貫性。

### 3. 架構組成 (Encoder-Only Transformer)
BERT 的架構結構化地由以下幾個模組組成，形成一個編碼器堆疊：
*   **分詞器 (Tokenizer)**：將原始文本轉換為整數序列（Tokens）。
*   **嵌入層 (Embedding)**：將離散的 Token ID 轉換為連續的、低維度的向量（Vector）。
*   **編碼器 (Encoder)**：由多層 Transformer 區塊堆疊而成，核心機制是**自注意力機制 (Self-Attention)**，它允許模型計算序列中任意兩個詞彙之間的關聯性，且沒有因果遮罩 (Causal Masking)，實現真正的雙向信息流。
*   **任務頭 (Task Head)**：用於預訓練時的輸出層，但在實際的「下游任務 (Downstream Tasks)」中，通常會移除此層，直接使用編碼器輸出的上下文向量進行微調 (Fine-tuning)。

## 深度分析
### 1. 轉移學習的典範 (The Paradigm of Transfer Learning)
BERT 的設計完美體現了「轉移學習」的優勢。研究人員不再需要為每個 NLP 任務（如問答、情感分析）從零開始訓練模型，而是先用海量的文本資料（如 BookCorpus 和 Wikipedia）預訓練一個通用的 BERT 模型。隨後，只需取出編碼器輸出的「潛在向量」，將其輸入到一個針對特定任務設計的小型分類器（即新的任務頭），然後在少量標註資料上進行微調，即可達到極高的準確度。

### 2. 與前代模型的比較
*   **相較於 ELMo**：BERT 提升了上下文理解的深度和廣度，其訓練機制更系統化，並且在任務上的表現更為穩定和優越。
*   **相較於 GPT-2**：GPT-2 屬於「解碼器 (Decoder-only)」架構，其信息流是單向的（只能看前文）。BERT 採用「編碼器 (Encoder-only)」架構，允許信息從所有方向流入，這使其在需要理解完整上下文的任務（如分類、抽取）中表現更佳。

### 3. 實作規模與演進
BERT 最初以 BASE（1.1 億參數）和 LARGE（3.4 億參數）兩個尺寸發布。隨著研究的深入，模型尺寸不斷優化，例如推出了 BERT-TINY 等更輕量化的版本，使其能夠在資源受限的邊緣設備上運行，擴展了其實用範圍。

---

### 流程圖：BERT 的信息處理流程
mermaid
graph TD
    subgraph "BERT 模型架構"
        A["輸入文本 (Raw Text)"] --> B["分詞器 (Tokenizer)"];
        B --> C["嵌入層 (Embedding)"];
        C --> D{Transformer 編碼器 (Encoder)};
        D --> E["上下文潛在向量 (Latent Vector)"];
        E --> F{下游任務 (Downstream Task)};
    end

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style D fill:#ccf,stroke:#333,stroke-width:2px
    style E fill:#afa,stroke:#333,stroke-width:2px
    style F fill:#ff9,stroke:#333,stroke-width:2px

    %% 說明流程
    subgraph "核心機制"
        D -.->|自注意力 (Self-Attention)| D;
        D -.->|雙向信息流| E;
    end

    %% 備註：預訓練與微調的區別
    subgraph "訓練階段"
        D -- 預訓練時 --> G["任務頭 (Task Head)"];
        G --> H["預測概率分佈"];
    end
    
    %% 關聯性說明
    E -->|微調 (Fine-tuning)| F;
    
    %% 關鍵點強調
    root(("BERT 模型")) --> A;
    root --> D;
    
    classDef concept fill:#eee,stroke:#666;
    class A,B,C,D,E,F,G concept;

---
第 1 / 8 | [[BERT (language model) (Part 2)|下一頁 →]]