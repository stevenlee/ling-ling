---
title: BERT (language model) (Part 3)
type: entity
date_created: '2026-04-25'
tags:
- language-model
- natural-language-processing
- transformer
- 自然語言處理
- 語言模型
---
# BERT (language model)
## 摘要
BERT (Bidirectional Encoder Representations from Transformers) 是一個革命性的預訓練語言模型，它能夠從雙向上下文學習語義資訊。其預訓練階段包含兩種核心任務：遮罩語言模型 (MLM) 和下一個句子預測 (NSP)。預訓練後，BERT 是一個通用的基礎模型，可以透過「微調 (Fine-tuning)」技術，在較小、特定任務的資料集上，高效地適應語義分類、問答系統等下游應用。

## 核心概念
### 遮罩語言模型 (Masked Language Modeling, MLM)
MLM 是 BERT 的核心預訓練任務之一，旨在讓模型學習輸入序列中被遮蔽 (Masked) 的詞彙的上下文語義。模型會以特定的機率對輸入文本中的詞元進行干擾，以增強其雙向語境理解能力。

*   **遮罩機制：** 選擇的詞元會根據以下機率進行處理：
    *   **80% 機率：** 將詞元替換為 `[MASK]` 標記。
    *   **10% 機率：** 將詞元替換為一個從隨機分佈採樣的詞元（例如 "happy"）。
    *   **10% 機率：** 不對詞元進行任何修改（保持原狀）。
*   **輸出處理：** 經過處理的輸入文本，模型會將特定位置（如第 4 個輸出向量）的向量傳遞給解碼器層，最終輸出一個在 30,000 維詞彙空間上的機率分佈。

### 下一個句子預測 (Next Sentence Prediction, NSP)
NSP 任務旨在訓練模型判斷兩個句子之間是否存在語義上的連續關係。

*   **任務目標：** 模型需判斷兩個句子是否在原始訓練語料庫中是連續出現的，輸出結果為 `[IsNext]` 或 `[NotNext]`。
*   **輸入結構：** 為了區分兩個句子，BERT 使用了特殊標記：
    *   `[CLS]` (Classification)：放在第一個句子開頭，用於最終的分類判斷。
    *   `[SEP]` (Separator)：用來分隔兩個句子。
*   **判斷邏輯：** 訓練時，模型會交替採樣：一是兩個連續的句子，二是兩個不連續的句子，並依此判斷 `[CLS]` 標記的最終向量是否指向 `[IsNext]`。

## 深度分析
### 模型應用與微調 (Fine-tuning)
BERT 的設計哲學是作為一個「通用預訓練模型」。它在海量數據上學習到通用的語言知識後，只需在較少資源的特定任務資料集上進行微調，就能達到頂尖的性能。

*   **主要應用領域：**
    *   **文本分類 (Text Classification)：** 例如情緒分析 (Sentiment classification) 和句子分類。
    *   **問答系統 (Question Answering)：** 識別文本中答案的片段。
    *   **自然語言推理 (Natural Language Inference)：** 判斷兩個文本間的邏輯關係（如蘊含、矛盾）。
    *   **詞性標註 (Part-of-speech tagging)：** 標記詞語的語法角色。
*   **關鍵機制：** 在下游應用中，通常會將 `[CLS]` 標記對應的輸出向量送入一個線性-Softmax 層，用於產生最終的標籤輸出。

### 訓練規模與成本
BERT 的訓練依賴龐大的語料庫，這決定了其巨大的計算成本。

*   **訓練語料：** 結合了 BookCorpus (8 億詞) 和經過過濾的英文維基百科 (25 億詞)。
*   **資源消耗：** 訓練 BERT-BASE 需要 4 天，估計成本約為 500 USD；訓練 BERT-LARGE 的資源消耗則更高。

## 流程圖：BERT 預訓練與應用流程
```mermaid
graph TD
    A[原始輸入文本] --> B{預訓練任務};

    subgraph "核心預訓練任務"
        B --> C[遮罩語言模型 (MLM)];
        B --> D[下一個句子預測 (NSP)];
    end

    C --> C1[處理機制: 80% 遮罩];
    C --> C2[處理機制: 10% 隨機/不變];

    D --> D1[輸入結構: [CLS] S1 [SEP] S2 [SEP]];
    D --> D2[任務目標: 判斷 S1 與 S2 是否連續];

    C1 & C2 & D2 --> E[模型輸出: 語義向量];

    E --> F{下游任務: 微調 (Fine-tuning)};

    subgraph "微調應用範例"
        F --> G1[文本分類];
        F --> G2[問答系統];
        F --> G3[語義關係判斷];
    end
    
    G1 --> H[最終輸出: 標籤機率分佈];
```

---
[[BERT (language model) (Part 2)|← 上一頁]] | 第 3 / 8 | [[BERT (language model) (Part 4)|下一頁 →]]