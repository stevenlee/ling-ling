---
title: BERT (language model) (Part 4)
type: entity
date_created: '2026-04-25'
tags:
- language-model
- natural-language-processing
- transformer
- 自然語言處理
- 語言模型
---
# BERT (BERT)
## 摘要
BERT（Bidirectional Encoder Representations from Transformers）是一個革命性的自然語言處理（NLP）模型，它基於 Transformer 架構的編碼器（Encoder）部分。BERT 的核心優勢在於其**雙向性**，這使其能夠從輸入文本的左側和右側同時獲取上下文資訊，從而生成高度具上下文意義的詞向量（Contextualized Embeddings）。其訓練過程主要依賴「遮罩語言模型」（MLM）和「下一句預測」（NSP）等預訓練任務。

## 核心概念
### 雙向上下文理解 (Bidirectionality)
與早期的 Word2Vec 或 GloVe 等模型僅為單詞生成固定向量不同，BERT 能夠為一個詞的每一個出現實例生成不同的向量表示。它通過自注意力機制（Self-Attention）同時考慮目標詞周圍的上下文，從而深入理解詞義的變化。
*   **範例：** 對於 "running" 這個詞，BERT 會根據它在句子 "He is running a company" 和 "He is running a marathon" 中的不同上下文，產生兩個不同的向量。

### 預訓練任務 (Pre-training Tasks)
BERT 的強大性能歸功於其精心設計的預訓練目標：
1.  **遮罩語言模型 (MLM - Masked Language Modeling)：** 模型會隨機遮蔽輸入序列中的部分詞元（Tokens），然後學習預測這些被遮蔽詞元的原貌。這迫使模型必須利用雙向上下文來推斷缺失的資訊。
2.  **下一句預測 (NSP - Next Sentence Prediction)：** 模型需要判斷兩個句子之間是否是連續的（即第二個句子是否是第一個句子的真正後續）。

### 架構限制與應用
*   **編碼器專用 (Encoder-only)：** BERT 僅使用 Transformer 的編碼器部分，缺乏解碼器（Decoder）。這使得它在理解任務（如分類、序列標註）上表現極佳，但限制了其直接進行文本生成（Text Generation）的能力。
*   **提示工程 (Prompting)：** 由於結構限制，直接使用 BERT 進行文本生成（如補全句子）時，若貿然將所有目標詞元都遮罩，可能會導致「資料集偏移」（Dataset Shift），從而使模型性能下降。

## 深度分析
### BERTology 的興起
BERT 的成功激發了學術界對其內部運作機制的研究，這領域被稱為「BERTology」。研究人員開始深入探討模型輸出的背後邏輯，包括：
*   **探測分類器 (Probing Classifiers)：** 通過外部分類器分析模型內部向量表示中是否隱藏了特定的語義或語法資訊。
*   **注意力權重分析 (Attention Weight Analysis)：** 研究模型在計算注意力權重時，不同詞元之間是如何相互關聯的，從而揭示模型關注的語義路徑。

### 模型演進與優化
BERT 的成功啟發了多個變體模型，旨在克服其限制或提升效率：
*   **RoBERTa：** 這是 BERT 的工程改進版。它在保持核心架構的基礎上，透過使用更大的批次大小（mini-batch size）和優化訓練超參數，並移除了 NSP 任務，進一步提升了性能。
*   **XLM-RoBERTa：** 是一個多語言版本的 RoBERTa，展示了將 BERT 的概念擴展到跨語言模型的能力。

### 視覺化流程：BERT 的上下文理解
這張圖展示了 BERT 如何利用雙向自注意力機制來理解一個詞的上下文意義。

```mermaid
graph TD
    subgraph "輸入文本序列"
        A["[左側上下文]"] --> B["目標詞 (Target Word)"];
        B --> C["[右側上下文]"];
    end

    B -.->|自注意力機制| A;
    B -.->|自注意力機制| C;

    subgraph "BERT 處理核心 (Transformer Encoder)"
        D[計算雙向注意力權重] --> E{整合上下文資訊};
    end

    E --> F["生成上下文向量表示"];
    F --> G["輸出：高度語義化的詞嵌入"];

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style C fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#ccf,stroke:#333,stroke-width:4px
```

---
[[BERT (language model) (Part 3)|← 上一頁]] | 第 4 / 8 | [[BERT (language model) (Part 5)|下一頁 →]]