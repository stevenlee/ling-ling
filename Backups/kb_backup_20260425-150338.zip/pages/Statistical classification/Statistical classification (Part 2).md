---
title: Statistical classification (Part 2)
type: concept
date_created: '2026-04-25'
tags:
- data-analysis
- machine-learning
- statistics
- 機器學習
- 統計學
- 資料分析
---
# 統計分類 (Statistical classification)

## 摘要
統計分類是機器學習和統計學的核心任務之一，其目標是根據輸入的特徵向量（Feature Vector），將新的、未標記的觀察值（Observation）準確地分配到預先定義好的類別（Class）之一。本概念深入探討了分類的兩大主流方法學——頻率論（Frequentist）和貝葉斯（Bayesian）程序，並闡述了從數據輸入到最終類別判定的整個流程。

## 核心概念

### 1. 特徵向量與數據輸入 (Feature Vectors)
分類算法的輸入是**特徵向量** $\mathbf{X}_i$，它由描述單個實例（Instance）的眾多可測量屬性（Features）組成。
*   **特徵類型**: 特徵可以是多種形式的數據，包括：
    *   **二進制 (Binary)**：如 "開/關" (on/off)。
    *   **類別 (Categorical)**：如血型 "A", "B", "O"。
    *   **順序 (Ordinal)**：如大小 "小", "中", "大"。
    *   **整數值 (Integer-valued)**：如出現次數。
    *   **實數值 (Real-valued)**：如血壓測量值。
*   **數據預處理**: 有些算法要求對連續的實數值或整數值進行**離散化 (Discretization)**，將其劃分為有限的組別。

### 2. 分類任務類型 (Classification Tasks)
*   **二元分類 (Binary Classification)**：最基礎的任務，僅涉及將實例分為兩個類別（例如：是/否，垃圾郵件/非垃圾郵件）。
*   **多類分類 (Multiclass Classification)**：當實例需要被分配到三個或更多個類別時使用。這通常需要結合多個二元分類器來實現。

### 3. 方法論學對比 (Methodological Contrast)
*   **頻率論程序 (Frequentist Procedures)**：早期工作由 Fisher 奠定基礎，通常假設數據服從**多元常態分佈 (Multivariate normal distribution)**。判斷依據常基於計算新觀察值與各類別中心點之間的距離（如調整後的**馬哈拉諾比斯距離**）。
*   **貝葉斯程序 (Bayesian Procedures)**：與頻率論不同，貝葉斯方法能自然地納入關於各類別在總體人口中相對大小的**先驗資訊 (Prior Information)**。它提供的是**組別成員機率 (Group-membership probabilities)**，而非單純的類別標籤。

### 4. 線性分類器 (Linear Classifiers)
許多分類算法可以被表述為一個線性函數，計算一個**分數 (Score)** 來評定實例 $i$ 屬於類別 $k$ 的可能性。
$$
\operatorname {score} (\mathbf {X} _{i},k)=\boldsymbol {\beta }_k\cdot \mathbf {X} _{i}
$$
其中，$\mathbf{X}_i$ 是特徵向量，$\boldsymbol{\beta}_k$ 是與類別 $k$ 相關的權重向量，計算方式為**點積 (Dot product)**。得分最高的類別即為預測的類別。

## 深度分析

### 頻率論的演進與距離度量
早期分類工作著重於兩組問題，提出了 Fisher 的線性判別函數。當擴展到多個類別時，如果限制分類規則必須是線性的，則依賴距離度量。當允許非線性時，則可以基於調整後的馬哈拉諾比斯距離來判斷，將新觀察值歸屬於與其調整後距離最小的類別。

### 貝葉斯方法的優勢與複雜性
貝葉斯方法最大的優勢在於其**可解釋性**和**納入先驗知識**的能力。雖然計算上可能更昂貴，但在缺乏大量數據或需要納入專家知識時，它提供了更穩健的框架。在計算能力不足的年代，人們開發了近似的貝葉斯聚類規則。

### 線性預測函數的應用
線性預測函數 $\operatorname{score} (\mathbf{X}_i, k)$ 的概念極為通用。在**離散選擇理論 (Discrete choice theory)** 中，當實例代表個體，類別代表選擇時，這個分數被視為個體 $i$ 選擇類別 $k$ 所帶來的**效用 (Utility)**。這展示了線性模型如何從統計分類延伸到經濟學決策模型。

## 流程圖：統計分類的決策路徑

```mermaid
graph TD
    A[輸入數據: 原始實例] --> B{特徵提取與向量化};
    B --> C[特徵向量 X_i];
    
    subgraph "選擇分類方法"
        C --> D1{頻率論程序};
        C --> D2{貝葉斯程序};
    end
    
    D1 --> E1[計算距離/分數];
    D2 --> E2[計算組別成員機率];
    
    E1 --> F{判斷最近/最高效用};
    E2 --> F;
    
    F --> G[輸出: 預測的類別標籤];
    
    style A fill:#f9f,stroke:#333,stroke-width:2px
    style G fill:#ccf,stroke:#333,stroke-width:2px
```

---
[[Statistical classification (Part 1)|← 上一頁]] | 第 2 / 5 | [[Statistical classification (Part 3)|下一頁 →]]