---
title: Statistical classification (Part 1)
type: entity
date_created: '2026-04-25'
tags:
- data-analysis
- machine-learning
- statistics
- 機器學習
- 統計學
- 資料分析
---
# 統計分類 (Statistical Classification)
## 摘要
統計分類是利用統計方法和計算機演算法，將觀察到的資料點（Observations）分配到預先定義的類別（Classes）或組別中的過程。其核心步驟是將原始資料轉換為一系列可量化的屬性，這些屬性被稱為「特徵」（Features）。本主題涵蓋了從資料類型定義到先進的機率模型（Probabilistic Model）的應用。

## 核心概念
### 1. 基本流程與術語定義
*   **分類器 (Classifier):** 指的是實現分類演算法的具體演算法，它接收輸入資料並輸出一個預測的類別。
*   **特徵 (Features) / 預測變數 (Explanatory Variables):** 這是指從單個觀察資料中提取出來的、可量化的屬性。這些屬性決定了資料點的特徵向量。
*   **相似度/距離函數 (Similarity/Distance Function):** 許多分類器的工作原理是計算待分類的資料點與已知類別代表資料點之間的相似度或距離，以此做出判斷。

### 2. 資料屬性類型
資料的特徵可以分為幾種基本類型，這決定了可用的統計方法：
*   **類別型資料 (Categorical Data):** 屬於名目或順序，如「A」、「B」或「O型血」。
*   **順序型資料 (Ordinal Data):** 具有明確的順序關係，如「小」、「中」、「大」。
*   **整數型資料 (Integer-valued):** 離散的計數值，如電子郵件中的出現次數。
*   **實數型資料 (Real-valued):** 具有連續測量意義的數值，如血壓測量值。

### 3. 跨學科術語差異
不同學科對術語的稱呼存在差異，理解這些差異對於正確應用至關重要：
*   **統計學 (Statistics):** 傾向使用「解釋變數 (Explanatory Variables)」和「依變數 (Dependent Variable)」的概念。
*   **機器學習 (Machine Learning):** 偏好使用「實例 (Instances)」指觀察資料，「特徵 (Features)」指屬性，以及「類別 (Classes)」指預測目標。

## 深度分析
### 1. 與其他模式識別問題的關係
分類（Classification）是更廣泛的「模式識別 (Pattern Recognition)」問題的一個子集。
*   **分類 (Classification):** 輸出一個離散的類別標籤（例如：貓、狗）。
*   **迴歸分析 (Regression Analysis):** 輸出一個連續的實數值（例如：房價、溫度）。
*   **序列標記 (Sequence Labeling):** 為序列中的每個元素分配一個標籤（例如：詞性標記）。

### 2. 機率分類的優勢 (Probabilistic Classification)
機率分類是統計分類的一個重要子類別。與僅輸出「最佳」類別的非機率分類器不同，機率分類器會輸出該實例屬於每個可能類別的**機率**。
*   **信心度評估 (Confidence Value):** 由於輸出了機率，模型可以提供一個信心度值，判斷其預測的可靠性。
*   **棄權能力 (Abstain):** 當所有類別的機率都過低時，模型可以選擇「棄權」，避免做出錯誤預測。
*   **避免誤差傳播 (Error Propagation):** 機率的輸出特性使其能更順暢地整合到更複雜的機器學習任務中，有效避免了誤差的累積傳播問題。

## 邏輯流程圖
```mermaid
graph TD
    root(("統計分類過程")) --> A["原始觀察資料 (Instances)"];
    A --> B["特徵提取 (Feature Extraction)"];
    B --> C{資料屬性類型};
    C --> C1["類別型 (Categorical)"];
    C --> C2["順序型 (Ordinal)"];
    C --> C3["實數型 (Real-valued)"];
    
    B --> D["特徵向量 (Feature Vector)"];
    D --> E["分類器 (Classifier)"];
    
    E --> F{分類模型類型};
    F --> G["非機率模型 (Non-Probabilistic)"];
    G --> H["輸出: 最佳類別標籤"];
    
    F --> I["機率模型 (Probabilistic)"];
    I --> J["輸出: 每個類別的機率 P(C)"];
    J --> K["優勢: 信心度評估與棄權"];
```

---
第 1 / 5 | [[Statistical classification (Part 2)|下一頁 →]]