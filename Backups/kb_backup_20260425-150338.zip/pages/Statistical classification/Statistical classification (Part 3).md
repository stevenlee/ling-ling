---
title: Statistical classification (Part 3)
type: entity
date_created: '2026-04-25'
tags:
- data-analysis
- machine-learning
- statistics
- 機器學習
- 統計學
- 資料分析
---
# Statistical classification
## 摘要
統計分類（Statistical classification）是機器學習和統計學中的核心任務之一，旨在根據輸入的特徵數據集，將樣本準確地劃分到預先定義的類別（或群組）中。與迴歸分析（Regression analysis）預測連續數值不同，分類的輸出是離散的、類別標籤。本概念涵蓋了從簡單的線性模型到複雜的集成學習方法等廣泛的演算法工具箱。

## 核心概念
分類算法的選擇高度依賴於數據集的特性、類別的數量（二元、多元）以及數據的本質結構。主要的算法可以分為以下幾大類：

### 1. 線性分類器 (Linear Classifiers)
這類算法假設數據的邊界是直線或超平面。它們的區別點在於如何計算和解釋權重（weights）或係數（coefficients）。
*   **邏輯迴歸 (Logistic Regression)**：用於二元依賴變數的統計模型，輸出值經過 Sigmoid 函數壓縮至 (0, 1) 區間，用作機率判斷。
*   **多項式邏輯迴歸 (Multinomial Logistic Regression)**：擴展至處理兩個以上離散類別的場景。
*   **支持向量機 (Support Vector Machine, SVM)**：一組用於監督式統計學習的方法，目標是找到最大間距超平面。
*   **線性判別分析 (Linear Discriminant Analysis, LDA)**：在統計學和模式識別中常用，用於區分不同類別之間的差異。

### 2. 基礎與非參數方法
*   **感知器 (Perceptron)**：最早的類神經網絡算法之一，用於監督式學習二元分類器。
*   **K-近鄰算法 (K-nearest neighbor, KNN)**：一種非參數分類方法，其分類決策基於計算樣本點與待分類點之間的距離，並採用鄰域投票機制。

### 3. 進階與集成學習方法 (Ensemble Methods)
當單一模型無法處理複雜的非線性邊界時，會採用集成學習，結合多個弱學習器的預測結果以提高準確性。
*   **隨機森林 (Random Forest)**：基於多棵決策樹的集成方法，能有效減少過擬合。
*   **提升法 (Boosting)**：一種迭代的集成學習方法，後續的模型會專注於修正前一個模型預測錯誤的樣本。
*   **人工神經網絡 (Artificial Neural Networks, ANN)**：模仿生物神經元結構的計算模型，能夠學習複雜的層級關係。

## 深度分析
### 算法選擇與評估
選擇合適的分類算法是一個權衡過程。決定因素包括數據的可分性、類別的數量和數據的維度。算法的性能通常需要通過量化指標進行評估，其中「準確率 (Accuracy)」是最基礎的評估指標之一，但更全面的評估還需考慮混淆矩陣（Confusion Matrix）中的召回率（Recall）和精確率（Precision）。

### 應用領域
分類算法的應用範圍極廣，不僅限於傳統的機器學習任務，還深入到科學研究領域：
*   **資料挖掘 (Data Mining)**：用於從大量數據中發現隱藏的模式和類別結構。
*   **生物分類 (Biological Classification)**：在生物學中，用於識別、描述和命名生物群體。
*   **模式識別 (Pattern Recognition)**：廣泛應用於圖像識別、語音識別等領域。

## 流程圖：分類任務的執行流程
mermaid
graph TD
    A[輸入特徵數據 X] --> B{選擇分類算法};
    subgraph "算法選擇層"
        B --> C1["線性分類器 (如：SVM, 邏輯迴歸)"];
        B --> C2["集成學習 (如：隨機森林, Boosting)"];
        B --> C3["非參數方法 (如：KNN)"];
    end
    C1 --> D[訓練階段: 學習最佳權重/邊界];
    C2 --> D;
    C3 --> D;
    D --> E{模型評估};
    E --> F["輸出: 預測的離散類別標籤 Y"];
    style A fill:#f9f,stroke:#333,stroke-width:2px
    style F fill:#ccf,stroke:#333,stroke-width:2px

---
[[Statistical classification (Part 2)|← 上一頁]] | 第 3 / 5 | [[Statistical classification (Part 4)|下一頁 →]]