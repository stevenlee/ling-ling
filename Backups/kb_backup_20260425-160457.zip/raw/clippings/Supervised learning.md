---
title: "Supervised learning"
source: "https://en.wikipedia.org/wiki/Supervised_learning"
author:
  - "[[Wikipedia]]"
published: 2002-01-08
created: 2026-04-25
description:
tags:
  - "clippings"
---
![](https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Supervised_and_unsupervised_learning.png/500px-Supervised_and_unsupervised_learning.png)

In supervised learning, the training data is labeled with the expected answers, while in unsupervised learning, the model identifies patterns or structures in unlabeled data.

In [machine learning](https://en.wikipedia.org/wiki/Machine_learning "Machine learning"), **supervised learning** (**SL**) is a type of [machine learning paradigm](https://en.wikipedia.org/wiki/Machine_learning#Approaches "Machine learning") where an algorithm learns to map input data to a specific output based on example input-output pairs. This process involves training a statistical model using [labeled data](https://en.wikipedia.org/wiki/Labeled_data "Labeled data"), meaning each piece of input data is provided with the correct output. The term "supervised" refers to the role of a teacher or supervisor who provides this training data, guiding the algorithm towards correct predictions.[^1] For instance, if you want a model to identify cats in images, supervised learning would involve feeding it many images of cats (inputs) that are explicitly labeled "cat" (outputs).

The goal of supervised learning is for the trained model to accurately predict the output for new, unseen data.[^2] This requires the algorithm to effectively [generalize](https://en.wikipedia.org/wiki/Generalization_\(learning\) "Generalization (learning)") from the training examples, a quality measured by its *[generalization error](https://en.wikipedia.org/wiki/Generalization_error "Generalization error")*. Supervised learning is commonly used for tasks like [classification](https://en.wikipedia.org/wiki/Classification "Classification") (predicting a category, e.g., spam or not spam) and [regression](https://en.wikipedia.org/wiki/Regression_analysis "Regression analysis") (predicting a continuous value, e.g., house prices).

## Steps to follow

To solve a given problem of supervised learning, the following steps must be performed:

## Algorithm choice

A wide range of supervised learning algorithms are available, each with its strengths and weaknesses. There is no single learning algorithm that works best on all supervised learning problems (see the [No free lunch theorem](https://en.wikipedia.org/wiki/No_free_lunch_in_search_and_optimization "No free lunch in search and optimization")).

There are four major issues to consider in supervised learning:

### Bias–variance tradeoff

A first issue is the tradeoff between *bias* and *variance*.[^3] Imagine that we have available several different, but equally good, training data sets. A learning algorithm is biased for a particular input ${\displaystyle x}$ if, when trained on each of these data sets, it is systematically incorrect when predicting the correct output for ${\displaystyle x}$. A learning algorithm has high variance for a particular input ${\displaystyle x}$ if it predicts different output values when trained on different training sets. The prediction error of a learned classifier is related to the sum of the bias and the variance of the learning algorithm.[^4] Generally, there is a tradeoff between bias and variance. A learning algorithm with low bias must be "flexible" so that it can fit the data well. But if the learning algorithm is too flexible, it will fit each training data set differently, and hence have high variance. A key aspect of many supervised learning methods is that they are able to adjust this tradeoff between bias and variance (either automatically or by providing a bias/variance parameter that the user can adjust).

### Function complexity and amount of training data

The second issue is of the amount of training data available relative to the complexity of the "true" function (classifier or regression function). If the true function is simple, then an "inflexible" learning algorithm with high bias and low variance will be able to learn it from a small amount of data. But if the true function is highly complex (e.g., because it involves complex interactions among many different input features and behaves differently in different parts of the input space), then the function will only be able to learn with a large amount of training data paired with a "flexible" learning algorithm with low bias and high variance.

### Dimensionality of the input space

A third issue is the dimensionality of the input space. If the input feature vectors have large dimensions, learning the function can be difficult even if the true function only depends on a small number of those features. This is because the many "extra" dimensions can confuse the learning algorithm and cause it to have high variance. Hence, input data of large dimensions typically requires tuning the classifier to have low variance and high bias. In practice, if the engineer can manually remove irrelevant features from the input data, it will likely improve the accuracy of the learned function. In addition, there are many algorithms for [feature selection](https://en.wikipedia.org/wiki/Feature_selection "Feature selection") that seek to identify the relevant features and discard the irrelevant ones. This is an instance of the more general strategy of [dimensionality reduction](https://en.wikipedia.org/wiki/Dimensionality_reduction "Dimensionality reduction"), which seeks to map the input data into a lower-dimensional space prior to running the supervised learning algorithm.

### Noise in the output values

A fourth issue is the degree of noise in the desired output values (the supervisory [target variables](https://en.wikipedia.org/wiki/Target_variable "Target variable")). If the desired output values are often incorrect (because of human error or sensor errors), then the learning algorithm should not attempt to find a function that exactly matches the training examples. Attempting to fit the data too carefully leads to [overfitting](https://en.wikipedia.org/wiki/Overfitting "Overfitting"). You can overfit even when there are no measurement errors (stochastic noise) if the function you are trying to learn is too complex for your learning model. In such a situation, the part of the target function that cannot be modeled "corrupts" your training data – this phenomenon has been called [deterministic noise](https://en.wikipedia.org/wiki/Deterministic_noise "Deterministic noise"). When either type of noise is present, it is better to go with a higher bias, lower variance estimator.

In practice, there are several approaches to alleviate noise in the output values such as [early stopping](https://en.wikipedia.org/wiki/Early_stopping "Early stopping") to prevent overfitting as well as [detecting](https://en.wikipedia.org/wiki/Anomaly_detection "Anomaly detection") and removing the noisy training examples prior to training the supervised learning algorithm. There are several algorithms that identify noisy training examples and removing the suspected noisy training examples prior to training has decreased [generalization error](https://en.wikipedia.org/wiki/Generalization_error "Generalization error") with [statistical significance](https://en.wikipedia.org/wiki/Statistical_significance "Statistical significance").[^5] [^6]

### Other factors to consider

Other factors to consider when choosing and applying a learning algorithm include the following:

- Heterogeneity of the data. If the feature vectors include features of many different kinds (discrete, discrete ordered, counts, continuous values), some algorithms are easier to apply than others. Many algorithms, including [support-vector machines](https://en.wikipedia.org/wiki/Support_Vector_Machines "Support Vector Machines"), [linear regression](https://en.wikipedia.org/wiki/Linear_regression "Linear regression"), [logistic regression](https://en.wikipedia.org/wiki/Logistic_regression "Logistic regression"), [neural networks](https://en.wikipedia.org/wiki/Neural_network_\(machine_learning\) "Neural network (machine learning)"), and [nearest neighbor methods](https://en.wikipedia.org/wiki/K-nearest_neighbors_algorithm "K-nearest neighbors algorithm"), require that the input features be numerical and scaled to similar ranges (e.g., to the \[-1,1\] interval). Methods that employ a distance function, such as nearest neighbor methods and [support-vector machines with Gaussian kernels](https://en.wikipedia.org/wiki/Support_Vector_Machines "Support Vector Machines"), are particularly sensitive to this. An advantage of [decision trees](https://en.wikipedia.org/wiki/Decision_tree_learning "Decision tree learning") is that they easily handle heterogeneous data.
- Redundancy in the data. If the input features contain redundant information (e.g., highly correlated features), some learning algorithms (e.g., [linear regression](https://en.wikipedia.org/wiki/Linear_regression "Linear regression"), [logistic regression](https://en.wikipedia.org/wiki/Logistic_regression "Logistic regression"), and [distance-based methods](https://en.wikipedia.org/wiki/K-nearest_neighbors_algorithm "K-nearest neighbors algorithm")) will perform poorly because of numerical instabilities. These problems can often be solved by imposing some form of [regularization](https://en.wikipedia.org/wiki/Regularization_\(mathematics\) "Regularization (mathematics)").
- Presence of interactions and non-linearities. If each of the features makes an independent contribution to the output, then algorithms based on linear functions (e.g., [linear regression](https://en.wikipedia.org/wiki/Linear_regression "Linear regression"), [logistic regression](https://en.wikipedia.org/wiki/Logistic_regression "Logistic regression"), [support-vector machines](https://en.wikipedia.org/wiki/Support-vector_machine "Support-vector machine"), [naive Bayes](https://en.wikipedia.org/wiki/Naive_Bayes_classifier "Naive Bayes classifier")) and distance functions (e.g., nearest neighbor methods, [support-vector machines with Gaussian kernels](https://en.wikipedia.org/wiki/Support_Vector_Machines "Support Vector Machines")) generally perform well. However, if there are complex interactions among features, then algorithms such as [decision trees](https://en.wikipedia.org/wiki/Decision_tree_learning "Decision tree learning") and neural networks work better, because they are specifically designed to discover these interactions. Linear methods can also be applied, but the engineer must manually specify the interactions when using them.

When considering a new application, the engineer can compare multiple learning algorithms and experimentally determine which one works best on the problem at hand (see [cross-validation](https://en.wikipedia.org/wiki/Cross-validation_\(statistics\) "Cross-validation (statistics)")). Tuning the performance of a learning algorithm can be very time-consuming. Given fixed resources, it is often better to spend more time collecting additional training data and more informative features than it is to spend extra time tuning the learning algorithms.

### Algorithms

The most widely used learning algorithms are:

- [Support-vector machines](https://en.wikipedia.org/wiki/Support-vector_machine "Support-vector machine")
- [Linear regression](https://en.wikipedia.org/wiki/Linear_regression "Linear regression")
- [Logistic regression](https://en.wikipedia.org/wiki/Logistic_regression "Logistic regression")
- [Naive Bayes](https://en.wikipedia.org/wiki/Naive_Bayes_classifier "Naive Bayes classifier")
- [Linear discriminant analysis](https://en.wikipedia.org/wiki/Linear_discriminant_analysis "Linear discriminant analysis")
- [Decision trees](https://en.wikipedia.org/wiki/Decision_tree_learning "Decision tree learning")
- [*k* -nearest neighbors algorithm](https://en.wikipedia.org/wiki/K-nearest_neighbors_algorithm "K-nearest neighbors algorithm")
- [Neural networks](https://en.wikipedia.org/wiki/Neural_network_\(machine_learning\) "Neural network (machine learning)") (e.g., [Multilayer perceptron](https://en.wikipedia.org/wiki/Multilayer_perceptron "Multilayer perceptron"))
- [Similarity learning](https://en.wikipedia.org/wiki/Similarity_learning "Similarity learning")

## How supervised learning algorithms work

Given a set of ${\displaystyle N}$ training examples of the form ${\displaystyle \{(x_{1},y_{1}),...,(x_{N},\;y_{N})\}}$ such that ${\displaystyle x_{i}}$ is the [feature vector](https://en.wikipedia.org/wiki/Feature_vector "Feature vector") of the ${\displaystyle i}$ -th example and ${\displaystyle y_{i}}$ is its label (i.e., class), a learning algorithm seeks a function ${\displaystyle g:X\to Y}$, where ${\displaystyle X}$ is the input space and ${\displaystyle Y}$ is the output space. The function ${\displaystyle g}$ is an element of some space of possible functions ${\displaystyle G}$, usually called the *hypothesis space*. It is sometimes convenient to represent ${\displaystyle g}$ using a [scoring function](https://en.wikipedia.org/wiki/Scoring_function "Scoring function") ${\displaystyle f:X\times Y\to \mathbb {R} }$ such that ${\displaystyle g}$ is defined as returning the ${\displaystyle y}$ value that gives the highest score: ${\displaystyle g(x)={\underset {y}{\arg \max }}\;f(x,y)}$. Let ${\displaystyle F}$ denote the space of scoring functions.

Although ${\displaystyle G}$ and ${\displaystyle F}$ can be any space of functions, many learning algorithms are probabilistic models where ${\displaystyle g}$ takes the form of a [conditional probability](https://en.wikipedia.org/wiki/Conditional_probability "Conditional probability") model ${\displaystyle g(x)={\underset {y}{\arg \max }}\;P(y|x)}$, or ${\displaystyle f}$ takes the form of a [joint probability](https://en.wikipedia.org/wiki/Joint_probability "Joint probability") model ${\displaystyle f(x,y)=P(x,y)}$. For example, [naive Bayes](https://en.wikipedia.org/wiki/Naive_Bayes_classifier "Naive Bayes classifier") and [linear discriminant analysis](https://en.wikipedia.org/wiki/Linear_discriminant_analysis "Linear discriminant analysis") are joint probability models, whereas [logistic regression](https://en.wikipedia.org/wiki/Logistic_regression "Logistic regression") is a conditional probability model.

There are two basic approaches to choosing ${\displaystyle f}$ or ${\displaystyle g}$: [empirical risk minimization](https://en.wikipedia.org/wiki/Empirical_risk_minimization "Empirical risk minimization") and [structural risk minimization](https://en.wikipedia.org/wiki/Structural_risk_minimization "Structural risk minimization").[^7] Empirical risk minimization seeks the function that best fits the training data. Structural risk minimization includes a *penalty function* that controls the bias/variance tradeoff.

In both cases, it is assumed that the training set consists of a sample of [independent and identically distributed pairs](https://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables "Independent and identically-distributed random variables"), ${\displaystyle (x_{i},\;y_{i})}$. In order to measure how well a function fits the training data, a [loss function](https://en.wikipedia.org/wiki/Loss_function "Loss function") ${\displaystyle L:Y\times Y\to \mathbb {R} ^{\geq 0}}$ is defined. For training example ${\displaystyle (x_{i},\;y_{i})}$, the loss of predicting the value ${\displaystyle {\hat {y}}}$ is ${\displaystyle L(y_{i},{\hat {y}})}$.

The *risk* ${\displaystyle R(g)}$ of function ${\displaystyle g}$ is defined as the expected loss of ${\displaystyle g}$. This can be estimated from the training data as

${\displaystyle R_{emp}(g)={\frac {1}{N}}\sum _{i}L(y_{i},g(x_{i}))}$.

### Empirical risk minimization

In empirical risk minimization, the supervised learning algorithm seeks the function ${\displaystyle g}$ that minimizes ${\displaystyle R(g)}$. Hence, a supervised learning algorithm can be constructed by applying an [optimization algorithm](https://en.wikipedia.org/wiki/Optimization_\(mathematics\) "Optimization (mathematics)") to find ${\displaystyle g}$.

When ${\displaystyle g}$ is a conditional probability distribution ${\displaystyle P(y|x)}$ and the loss function is the negative log likelihood: ${\displaystyle L(y,{\hat {y}})=-\log P(y|x)}$, then empirical risk minimization is equivalent to [maximum likelihood estimation](https://en.wikipedia.org/wiki/Maximum_likelihood "Maximum likelihood").

When ${\displaystyle G}$ contains many candidate functions or the training set is not sufficiently large, empirical risk minimization leads to high variance and poor generalization. The learning algorithm is able to memorize the training examples without generalizing well (overfitting).

### Structural risk minimization

[Structural risk minimization](https://en.wikipedia.org/wiki/Structural_risk_minimization "Structural risk minimization") seeks to prevent overfitting by incorporating a [regularization penalty](https://en.wikipedia.org/wiki/Regularization_\(mathematics\) "Regularization (mathematics)") into the optimization. The regularization penalty can be viewed as implementing a form of [Occam's razor](https://en.wikipedia.org/wiki/Occam%27s_razor "Occam's razor") that prefers simpler functions over more complex ones.

A wide variety of penalties have been employed that correspond to different definitions of complexity. For example, consider the case where the function ${\displaystyle g}$ is a linear function of the form

${\displaystyle g(x)=\sum _{j=1}^{d}\beta _{j}x_{j}}$.

A popular regularization penalty is ${\displaystyle \sum _{j}\beta _{j}^{2}}$, which is the squared [Euclidean norm](https://en.wikipedia.org/wiki/Euclidean_norm "Euclidean norm") of the weights, also known as the ${\displaystyle L_{2}}$ norm. Other norms include the ${\displaystyle L_{1}}$ norm, ${\displaystyle \sum _{j}|\beta _{j}|}$, and the [${\displaystyle L_{0}}$ "norm"](https://en.wikipedia.org/wiki/L0_%22norm%22 "L0 \"norm\""), which is the number of non-zero ${\displaystyle \beta _{j}}$ s. The penalty will be denoted by ${\displaystyle C(g)}$.

The supervised learning optimization problem is to find the function ${\displaystyle g}$ that minimizes

${\displaystyle J(g)=R_{emp}(g)+\lambda C(g).}$

The parameter ${\displaystyle \lambda }$ controls the bias-variance tradeoff. When ${\displaystyle \lambda =0}$, this gives empirical risk minimization with low bias and high variance. When ${\displaystyle \lambda }$ is large, the learning algorithm will have high bias and low variance. The value of ${\displaystyle \lambda }$ can be chosen empirically via [cross-validation](https://en.wikipedia.org/wiki/Cross-validation_\(statistics\) "Cross-validation (statistics)").

The complexity penalty has a Bayesian interpretation as the negative log prior probability of ${\displaystyle g}$, ${\displaystyle -\log P(g)}$, in which case ${\displaystyle J(g)}$ is the [posterior probability](https://en.wikipedia.org/wiki/Posterior_probability "Posterior probability") of ${\displaystyle g}$.

## Generative training

The training methods described above are *discriminative training* methods, because they seek to find a function ${\displaystyle g}$ that discriminates well between the different output values (see [discriminative model](https://en.wikipedia.org/wiki/Discriminative_model "Discriminative model")). For the special case where ${\displaystyle f(x,y)=P(x,y)}$ is a [joint probability distribution](https://en.wikipedia.org/wiki/Joint_probability_distribution "Joint probability distribution") and the loss function is the negative log likelihood ${\displaystyle -\sum _{i}\log P(x_{i},y_{i}),}$ a risk minimization algorithm is said to perform *generative training*, because ${\displaystyle f}$ can be regarded as a [generative model](https://en.wikipedia.org/wiki/Generative_model "Generative model") that explains how the data were generated. Generative training algorithms are often simpler and more computationally efficient than discriminative training algorithms. In some cases, the solution can be computed in closed form as in [naive Bayes](https://en.wikipedia.org/wiki/Naive_Bayes_classifier "Naive Bayes classifier") and [linear discriminant analysis](https://en.wikipedia.org/wiki/Linear_discriminant_analysis "Linear discriminant analysis").

## Generalizations

![](https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Task-guidance.png/330px-Task-guidance.png)

Tendency for a task to employ supervised vs. unsupervised methods. Task names straddling circle boundaries is intentional. It shows that the classical division of imaginative tasks (left) employing unsupervised methods is blurred in today's learning schemes.

There are several ways in which the standard supervised learning problem can be generalized:

- [Semi-supervised learning](https://en.wikipedia.org/wiki/Semi-supervised_learning "Semi-supervised learning") or [weak supervision](https://en.wikipedia.org/wiki/Weak_supervision "Weak supervision"): the desired output values are provided only for a subset of the training data. The remaining data is unlabeled or imprecisely labeled.
- [Active learning](https://en.wikipedia.org/wiki/Active_learning_\(machine_learning\) "Active learning (machine learning)"): Instead of assuming that all of the training examples are given at the start, active learning algorithms interactively collect new examples, typically by making queries to a human user. Often, the queries are based on unlabeled data, which is a scenario that combines semi-supervised learning with active learning.
- [Structured prediction](https://en.wikipedia.org/wiki/Structured_prediction "Structured prediction"): When the desired output value is a complex object, such as a [parse tree](https://en.wikipedia.org/wiki/Parse_tree "Parse tree") or a labeled graph, then standard methods must be extended.
- [Learning to rank](https://en.wikipedia.org/wiki/Learning_to_rank "Learning to rank"): When the input is a set of objects and the desired output is a ranking of those objects, then again the standard methods must be extended.

## Approaches and algorithms

- Analytical learning
- [Artificial neural network](https://en.wikipedia.org/wiki/Artificial_neural_network "Artificial neural network")
- [Backpropagation](https://en.wikipedia.org/wiki/Backpropagation "Backpropagation")
- [Boosting (meta-algorithm)](https://en.wikipedia.org/wiki/Boosting_\(meta-algorithm\) "Boosting (meta-algorithm)")
- [Bayesian statistics](https://en.wikipedia.org/wiki/Bayesian_statistics "Bayesian statistics")
- [Case-based reasoning](https://en.wikipedia.org/wiki/Case-based_reasoning "Case-based reasoning")
- [Decision tree learning](https://en.wikipedia.org/wiki/Decision_tree_learning "Decision tree learning")
- [Inductive logic programming](https://en.wikipedia.org/wiki/Inductive_logic_programming "Inductive logic programming")
- [Gaussian process regression](https://en.wikipedia.org/wiki/Gaussian_process_regression "Gaussian process regression")
- [Genetic programming](https://en.wikipedia.org/wiki/Genetic_programming "Genetic programming")
- [Group method of data handling](https://en.wikipedia.org/wiki/Group_method_of_data_handling "Group method of data handling")
- [Kernel estimators](https://en.wikipedia.org/wiki/Variable_kernel_density_estimation#Use_for_statistical_classification "Variable kernel density estimation")
- [Learning automata](https://en.wikipedia.org/wiki/Learning_automaton "Learning automaton")
- [Learning classifier systems](https://en.wikipedia.org/wiki/Learning_classifier_system "Learning classifier system")
- [Learning vector quantization](https://en.wikipedia.org/wiki/Learning_vector_quantization "Learning vector quantization")
- [Minimum message length](https://en.wikipedia.org/wiki/Minimum_message_length "Minimum message length") ([decision trees](https://en.wikipedia.org/wiki/Decision_tree "Decision tree"), decision graphs, etc.)
- [Multilinear subspace learning](https://en.wikipedia.org/wiki/Multilinear_subspace_learning "Multilinear subspace learning")
- [Naive Bayes classifier](https://en.wikipedia.org/wiki/Naive_Bayes_classifier "Naive Bayes classifier")
- [Maximum entropy classifier](https://en.wikipedia.org/wiki/Maximum_entropy_classifier "Maximum entropy classifier")
- [Conditional random field](https://en.wikipedia.org/wiki/Conditional_random_field "Conditional random field")
- [Nearest neighbor algorithm](https://en.wikipedia.org/wiki/Nearest_neighbor_\(pattern_recognition\) "Nearest neighbor (pattern recognition)")
- [Probably approximately correct learning](https://en.wikipedia.org/wiki/Probably_approximately_correct_learning "Probably approximately correct learning") (PAC) learning
- [Ripple down rules](https://en.wikipedia.org/wiki/Ripple_down_rules "Ripple down rules"), a knowledge acquisition methodology
- Symbolic machine learning algorithms
- Subsymbolic machine learning algorithms
- [Support vector machines](https://en.wikipedia.org/wiki/Support_vector_machine "Support vector machine")
- Minimum complexity machines (MCM)
- [Random forests](https://en.wikipedia.org/wiki/Random_forest "Random forest")
- [Ensembles of classifiers](https://en.wikipedia.org/wiki/Ensembles_of_classifiers "Ensembles of classifiers")
- [Ordinal classification](https://en.wikipedia.org/wiki/Ordinal_classification "Ordinal classification")
- [Data pre-processing](https://en.wikipedia.org/wiki/Data_pre-processing "Data pre-processing")
- Handling imbalanced datasets
- [Statistical relational learning](https://en.wikipedia.org/wiki/Statistical_relational_learning "Statistical relational learning")
- [Proaftn](https://en.wikipedia.org/wiki/Proaftn "Proaftn"), a multicriteria classification algorithm

## Applications

- [Bioinformatics](https://en.wikipedia.org/wiki/Bioinformatics "Bioinformatics")
- [Cheminformatics](https://en.wikipedia.org/wiki/Cheminformatics "Cheminformatics")
	- [Quantitative structure–activity relationship](https://en.wikipedia.org/wiki/Quantitative_structure%E2%80%93activity_relationship "Quantitative structure–activity relationship")
- [Database marketing](https://en.wikipedia.org/wiki/Database_marketing "Database marketing")
- [Handwriting recognition](https://en.wikipedia.org/wiki/Handwriting_recognition "Handwriting recognition")
- [Information retrieval](https://en.wikipedia.org/wiki/Information_retrieval "Information retrieval")
	- [Learning to rank](https://en.wikipedia.org/wiki/Learning_to_rank "Learning to rank")
- [Information extraction](https://en.wikipedia.org/wiki/Information_extraction "Information extraction")
- Object recognition in [computer vision](https://en.wikipedia.org/wiki/Computer_vision "Computer vision")
- [Optical character recognition](https://en.wikipedia.org/wiki/Optical_character_recognition "Optical character recognition")
- [Spam detection](https://en.wikipedia.org/wiki/Spamming "Spamming")
- [Pattern recognition](https://en.wikipedia.org/wiki/Pattern_recognition "Pattern recognition")
- [Speech recognition](https://en.wikipedia.org/wiki/Speech_recognition "Speech recognition")
- Supervised learning is a special case of [downward causation](https://en.wikipedia.org/wiki/Downward_causation "Downward causation") in biological systems
- Landform classification using [satellite imagery](https://en.wikipedia.org/wiki/Satellite_imagery "Satellite imagery") [^8]
- Spend classification in [procurement](https://en.wikipedia.org/wiki/Procurement "Procurement") processes [^9]

## General issues

- [Computational learning theory](https://en.wikipedia.org/wiki/Computational_learning_theory "Computational learning theory")
- [Inductive bias](https://en.wikipedia.org/wiki/Inductive_bias "Inductive bias")
- [Overfitting](https://en.wikipedia.org/wiki/Overfitting "Overfitting")
- (Uncalibrated) [class membership probabilities](https://en.wikipedia.org/wiki/Class_membership_probabilities "Class membership probabilities")
- [Version spaces](https://en.wikipedia.org/wiki/Version_space "Version space")

[^1]: Mitchell, Tom M. (2013). *Machine learning*. McGraw-Hill series in Computer Science (Nachdr. ed.). New York: McGraw-Hill. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-07-042807-2](https://en.wikipedia.org/wiki/Special:BookSources/978-0-07-042807-2 "Special:BookSources/978-0-07-042807-2").

[^2]: [Mehryar Mohri](https://en.wikipedia.org/wiki/Mehryar_Mohri "Mehryar Mohri"), Afshin Rostamizadeh, Ameet Talwalkar (2012) *Foundations of Machine Learning*, The MIT Press [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [9780262018258](https://en.wikipedia.org/wiki/Special:BookSources/9780262018258 "Special:BookSources/9780262018258").

[^3]: S. Geman, E. Bienenstock, and R. Doursat (1992). [Neural networks and the bias/variance dilemma](http://delta-apache-vm.cs.tau.ac.il/~nin/Courses/NC06/VarbiasBiasGeman.pdf). Neural Computation 4, 1–58.

[^4]: G. James (2003) Variance and Bias for General Loss Functions, Machine Learning 51, 115–135. ([http://www-bcf.usc.edu/~gareth/research/bv.pdf](http://www-bcf.usc.edu/~gareth/research/bv.pdf))

[^5]: C.E. Brodely and M.A. Friedl (1999). Identifying and Eliminating Mislabeled Training Instances, Journal of Artificial Intelligence Research 11, 131–167. ([http://jair.org/media/606/live-606-1803-jair.pdf](http://jair.org/media/606/live-606-1803-jair.pdf))

[^6]: M.R. Smith and T. Martinez (2011). "Improving Classification Accuracy by Identifying and Removing Instances that Should Be Misclassified". *Proceedings of International Joint Conference on Neural Networks (IJCNN 2011)*. pp. 2690–2697. [CiteSeerX](https://en.wikipedia.org/wiki/CiteSeerX_\(identifier\) "CiteSeerX (identifier)") [10.1.1.221.1371](https://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.221.1371). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1109/IJCNN.2011.6033571](https://doi.org/10.1109%2FIJCNN.2011.6033571).

[^7]: Vapnik, V. N. [The Nature of Statistical Learning Theory](https://books.google.com/books?id=EqgACAAAQBAJ&q=%22empirical+risk+minimization%22+OR+%22structural+risk+minimization%22) (2nd Ed.), Springer Verlag, 2000.

[^8]: A. Maity (2016). "Supervised Classification of RADARSAT-2 Polarimetric Data for Different Land Features". [arXiv](https://en.wikipedia.org/wiki/ArXiv_\(identifier\) "ArXiv (identifier)"):[1608.00501](https://arxiv.org/abs/1608.00501) \[[cs.CV](https://arxiv.org/archive/cs.CV)\].

[^9]: ["Key Technologies for Agile Procurement | SIPMM Publications"](https://publication.sipmm.edu.sg/key-technologies-agile-procurement/). *publication.sipmm.edu.sg*. 2020-10-09. Retrieved 2022-06-16.