# 🎀 Knowledge Dashboard (v0.2.1)
---

## ✍️ Notes

## 🤖 Entities
- [[test_clipping (Synthesis)]]  `Placeholder` `測試` `資料結構` | 📅 2026-04-25

> [!abstract]- 📂 Statistical classification (1 items) | 📅 2026-04-25
> - [[Statistical classification]]  `clippings`

> [!abstract]- 📂 Supervised learning (1 items) | 📅 2026-04-25
> - [[Supervised learning]]  `clippings`

> [!abstract]- 📂 孫子兵法 (4 items) | 📅 2026-04-25
> - [[孫子兵法]]  `clippings`
> - [[孫子兵法 (Part 1)]] 
> - [[孫子兵法 (Part 2)]]  `copyright` `digital-collection` `ebook`
> - [[孫子兵法 (Synthesis)]]  `completed` `copyright` `digital-collection`

> [!abstract]- 📂 道德經 (4 items) | 📅 2026-04-25
> - [[道德經]]  `clippings`
> - [[道德經 (Part 1)]] 
> - [[道德經 (Part 2)]]  `copyright` `digital-collection` `ebook`
> - [[道德經 (Synthesis)]]  `completed` `copyright` `digital-collection`

