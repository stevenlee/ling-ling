---
公共領域: public-domain
數位典藏: digital-collection
版權: copyright
著作權: copyright
電子書: ebook
---
# 標籤對照定義 (Tag Map)
系統會自動從此處讀取標籤對照關係。您可以直接在 Obsidian 的「屬性 (Properties)」介面中新增或修改對照。
