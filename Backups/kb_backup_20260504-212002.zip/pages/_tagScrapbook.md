---
初始化: initialization
古代兵法: ancient-military-strategy
啟動流程: startup-process
戰略學: strategy-studies
文件維護: document-maintenance
測試: testing
系統啟動: system-startup
結構化: structured
謀略: tactics/schemes
軍事哲學: military-philosophy
---
# 標籤對照定義 (Tag Map)
系統會自動從此處讀取標籤對照關係。您可以直接在 Obsidian 的「屬性 (Properties)」介面中新增或修改對照。
