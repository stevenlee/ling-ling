# 🎀 Knowledge Dashboard
---

## ✍️ Notes

## 🤖 Entities
> [!abstract]- 📂 AI agent (19 items)
> - [[AI agent]]  `agentic` `agentic-ai` `autonomous-system`
> - [[AI agent]]  `clippings`
> - [[AI agent (Part 1)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 2)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 3)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 4)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 5)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 6)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 7)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 8)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 9)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 10)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 11)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 12)]]  `Agentic AI` `大型語言模型` `生成式AI` | 📅 2026-04-25
> - [[AI agent (Part 13)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 14)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 15)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 16)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25
> - [[AI agent (Part 17)]]  `agentic-ai` `autonomous-system` `generative-ai` | 📅 2026-04-25

> [!abstract]- 📂 Large language model (31 items)
> - [[Large language model]]  `ai` `completed` `deep-learning`
> - [[Large language model]]  `clippings`
> - [[Large language model (Part 1)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 2)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 3)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 4)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 5)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 6)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 7)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 8)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 9)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 10)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 11)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 12)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 13)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 14)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 15)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 16)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 17)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 18)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 19)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 20)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 21)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 22)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 23)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 24)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 25)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 26)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 27)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 28)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25
> - [[Large language model (Part 29)]]  `ai` `deep-learning` `llm` | 📅 2026-04-25

> [!abstract]- 📂 US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (18 items)
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs]]  `binary-evolution` `completed` `deep-learning`
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs]]  `clippings`
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 1)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 2)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 3)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 4)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 5)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 6)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 7)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 8)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 9)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 10)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 11)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 12)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 13)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 14)]]  `binary-evolution` `deep-learning` `ensemble-learning` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 15)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 16)]]  `binary-evolution` `deep-learning` `gpu-cluster` | 📅 2026-04-25


## 📦 Archive
> [!abstract]- 📂 clippings (3 items)
> - [[AI agent]]  `clippings`
> - [[Large language model]]  `clippings`
> - [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs]]  `clippings`

> [!abstract]- 📂 prompts (1 items)
> - [[@ling-repair-db]] 

