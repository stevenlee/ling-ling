---
title: AI agent (Part 1)
type: entity
date_created: '2026-04-25'
tags:
- agentic-ai
- autonomous-system
- generative-ai
- large-language-model
- 大型語言模型
- 生成式ai
- 自主系統
---
# AI Agent (人工智慧代理人)
## 摘要
AI Agent（人工智慧代理人），亦稱為「複合式 AI 系統」或「Agentic AI」，是生成式人工智慧領域的一個關鍵分支。它代表了一類能夠在複雜環境中**自主運行**的智慧系統。與傳統的內容生成工具不同，AI Agent 的核心能力側重於**決策制定**和**任務自動化**，而非單純的內容創造。它們能夠接收高層次的請求，並透過規劃、工具使用和記憶體管理，執行複雜的多步驟任務。

## 核心概念
AI Agent 的運作機制是一個包含多個組件的閉環系統，其核心概念包括：

1.  **自主性 (Autonomy)**：這是區分 AI Agent 的關鍵特徵。它意味著系統不需要用戶持續的監督或指導就能執行一系列複雜的步驟來達成目標。
2.  **大型語言模型 (LLMs) 驅動**：LLMs 負責作為「大腦」，處理自然語言輸入，理解目標結構，並生成下一步的推理步驟和行動計畫。
3.  **記憶體系統 (Memory)**：Agent 必須具備記憶能力，用來儲存與用戶或環境的先前互動，從而實現上下文的連貫性和長期學習。
4.  **工具與協調 (Tools & Orchestration)**：Agent 不僅是語言模型本身，它還必須能夠調用外部工具（如 API、資料庫、瀏覽器）和使用「協調軟體」來組織這些工具的執行順序，以完成實際的任務。

## 深度分析
AI Agent 的進階能力體現在其內部的「認知架構」設計上，這決定了其決策的複雜度和可靠性。

### 🧠 認知架構 (Cognitive Architectures)
研究人員開發了多種模式來提升 Agent 的推理能力：

*   **ReAct (Reason + Act)**：這是一種迭代的、循環式的過程。Agent 會交替進行「推理 (Reasoning)」和「行動 (Acting)」。它根據環境或外部工具的「觀察 (Observation)」結果，將這些資訊整合到下一次的推理步驟中，從而不斷精進計畫。
*   **檢索增強生成 (Retrieval-augmented generation, RAG)**：這確保 Agent 在生成答案時，不會僅依賴其訓練資料，而是能主動從外部知識庫中檢索相關、最新的資訊來輔助決策。
*   **Reflexion**：這是一種自我反思機制。Agent 會利用 LLM 為自己的行動計畫生成「回饋 (Feedback)」，並將這些回饋儲存在記憶快取中，以便在未來類似任務時避免重複錯誤。
*   **工具/代理註冊表 (Tool/Agent Registry)**：這是一個系統化的目錄，用來組織和管理 Agent 可以使用的所有軟體功能或子代理人，確保系統的模組化和可擴展性。

### 🌐 產業標準與未來趨勢
*   **標準化協定**：為了實現多個 Agent 之間的無縫溝通，業界正在發展標準協定，例如 Model Context Protocol 和 Gibberlink，這些協定有助於連接 Agent 與外部應用程式。
*   **治理機構**：為確保 Agentic AI 的透明和協作發展，已成立了如「Agentic AI Foundation (AAIF)」這樣的行業基礎設施，推動產業標準的建立。
*   **自主性對比**：在自主性層級上，AI Agent 的能力常被類比為汽車的 SAE 等級分類。目前許多應用處於 L2 到 L3 級別，代表高度專業化和受限環境下的自主操作，而 L5 則仍屬於理論層面。

### AI Agent 的操作流程圖
```mermaid
graph TD
    A["用戶輸入 (Prompt)"] --> B["LLM 核心 (規劃與理解)"];
    B --> C{是否需要外部工具?};
    C -- 是 --> D["工具/代理註冊表 (Tool Registry)"];
    D --> E["選擇工具並生成行動 (Action)"];
    E --> F["環境執行 (Execution)"];
    F --> G["觀察結果 (Observation)"];
    G --> H["LLM 迭代 (ReAct/Reflexion)"];
    H --> I{目標達成?};
    I -- 否 --> B;
    I -- 是 --> J["最終輸出 (Final Output)"];

    subgraph "核心機制"
        B
        H
    end
    subgraph "數據流動"
        A --> B
        G --> H
    end
```

---
第 1 / 17 | [[AI agent (Part 2)|下一頁 →]]