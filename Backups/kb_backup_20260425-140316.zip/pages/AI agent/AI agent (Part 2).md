---
title: AI agent (Part 2)
type: concept
date_created: '2026-04-25'
tags:
- agentic-ai
- autonomous-system
- generative-ai
- large-language-model
- 大型語言模型
- 生成式ai
- 自主系統
---
# AI Agent 架構與運作模式 (AI Agent Architecture and Patterns)
## 摘要
本筆記概述了當前 AI Agent 的參考架構、複雜任務的協調模式，以及其從純文本處理擴展至多模態（如視覺、行動）的發展趨勢。AI Agent 的運作是一個分層、系統化的過程，需要從基礎模型到生態系統層面進行協同建構。

## 核心概念
### 1. AI Agent 參考架構 (Ken Huang's 7-Layer Model)
AI Agent 的建構是一個由基礎到頂層的七層結構，每一層都建立在下方層的功能之上。

*   **第 1 層：基礎模型 (Foundation models)**：提供驅動 Agent 能力的核心 AI 引擎（如 LLMs）。
*   **第 2 層：資料操作 (Data operations)**：管理複雜的數據基礎設施，包含向量資料庫 (Vector database)、資料載入器和檢索增強生成 (RAG)。
*   **第 3 層：Agent 框架 (Agent frameworks)**：提供簡化開發和管理 Agent 的複雜軟體工具。
*   **第 4 層：部署與基礎設施 (Deployment and infrastructure)**：提供運行 Agent 所需穩健的技術基礎。
*   **第 5 層：評估與可觀測性 (Evaluation and observability)**：專注於評估 Agent 的安全性和性能。
*   **第 6 層：安全與合規性 (Security and compliance)**：整合所有層次的保護框架，確保 Agent 安全、合規運行。
*   **第 7 層：Agent 生態系統 (Agent ecosystem)**：代表 Agent 與現實世界應用和用戶的介面層。

### 2. 協調模式 (Orchestration Patterns)
執行複雜任務時，Agent 需要與其他 Agent 或專業工具協同工作，這形成了不同的工作流模式：

*   **提示鏈接 (Prompt chaining)**：一個步驟的輸出作為下一個步驟的輸入，形成連續的流程。
*   **路由 (Routing)**：根據輸入內容的分類，將任務導向特定的下游任務或工具。
*   **平行化 (Parallelization)**：同時執行多個獨立任務，提高效率。
*   **序列處理 (Sequential processing)**：任務按照預定義的線性順序依次執行。
*   **規劃者-批評者 (Planner-critic)**：一個 Agent 提出提案，另一個 Agent 進行評估並提供回饋，從而進行迭代優化。

## 深度分析
### 1. 多模態擴展 (Multimodal Expansion)
Agent 的基礎已從單純的語言模型 (LLMs) 擴展到多模態基礎模型 (Multimodal foundation models)。這使得 Agent 不僅能處理文本，還能分析：
*   **視覺與語言模型 (VLMs)**：處理圖像輸入。
*   **影片內容分析 (Video content analysis)**：用於影片搜尋和摘要。
*   **機器人與軟體介面 (Robotics & UI)**：能夠與現實世界或軟體介面進行互動和操作。

### 2. 應用場景與市場成熟度
目前 AI Agent 的應用場景正在快速發展，但市場仍處於實驗和探索階段。主要的應用類型包括：
*   **業務任務 Agent**：在企業軟體內部執行操作。
*   **對話型 Agent**：作為客戶支援的聊天機器人。
*   **研究 Agent**：用於查詢和分析資訊。
*   **分析 Agent**：用於數據分析並生成報告。
*   **開發/編碼 Agent**：輔助軟體開發流程。
*   **網頁瀏覽 Agent**：具備自主瀏覽和操作網站的能力。

---
## 視覺化：AI Agent 的七層參考架構

```mermaid
graph TD
    subgraph "AI Agent 參考架構 (Ken Huang)"
        A["第 1 層: 基礎模型 (Foundation models)"] --> B["第 2 層: 資料操作 (Data operations)"];
        B --> C["第 3 層: Agent 框架 (Agent frameworks)"];
        C --> D["第 4 層: 部署與基礎設施 (Deployment and infrastructure)"];
        D --> E["第 5 層: 評估與可觀測性 (Evaluation and observability)"];
        E --> F["第 6 層: 安全與合規性 (Security and compliance)"];
        F --> G(("第 7 層: Agent 生態系統 (Agent ecosystem)"));
    end

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style G fill:#ccf,stroke:#333,stroke-width:4px
```

---
[[AI agent (Part 1)|← 上一頁]] | 第 2 / 17 | [[AI agent (Part 3)|下一頁 →]]