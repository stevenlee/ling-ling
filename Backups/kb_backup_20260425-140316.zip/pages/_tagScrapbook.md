---
gpu叢集: gpu-cluster
倍增啟發式: binary-evolution
大型語言模型: large-language-model
深度學習: deep-learning
生成式ai: generative-ai
系統排程: system-scheduling
自主系統: autonomous-system
自然語言處理: natural-language-processing
---
# 標籤對照定義 (Tag Map)
系統會自動從此處讀取標籤對照關係。您可以直接在 Obsidian 的「屬性 (Properties)」介面中新增或修改對照。
