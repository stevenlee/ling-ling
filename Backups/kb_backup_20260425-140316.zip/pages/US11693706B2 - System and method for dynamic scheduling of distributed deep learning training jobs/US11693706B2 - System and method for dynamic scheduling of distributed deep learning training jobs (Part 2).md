---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 2)
type: entity
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# 分散式深度學習工作動態排程系統與方法 (Dynamic Scheduling for Distributed Deep Learning)
## 摘要
本文件概述了用於大規模深度學習訓練工作的動態資源排程技術進展。傳統的參數伺服器（Parameter Server）架構正逐漸被環狀（Ring）架構取代，尤其是在資料平行化方面。核心技術進步集中於優化通訊協定，特別是利用 NCCL 和 OpenMPI 實現高效的 Allreduce 操作，並引入了比傳統環狀算法更低延遲的倍增-折半（Doubling-Halving）和二進位區塊（Binary Blocks）算法來解決非凸、非線性、NP-難的排程優化問題。

## 核心概念
### 1. 資源排程模型比較
*   **Optimus 系統 (參數伺服器模型)**：一個為 MXNet 設計的動態排程器，它使用線上擬合（Online Fitting）來預測訓練收斂的 epoch 數。它通過非負最小二乘法（NNLS）學習每個 epoch 的速度，並將排程問題建模為一個非線性非凸的 NP-難整數規劃問題，並使用貪婪啟發式（Greedy Heuristic）進行求解。
*   **環狀架構 (Ring Architecture)**：一種用於資料平行化的架構，在算法層面上，它正逐漸超越傳統的參數伺服器架構，成為處理大型訓練集的首選。
*   **動態排程的優化目標**：本專利強調將動態排程適應到環狀架構，旨在解決排程問題，並提出了一種新的高效倍增啟發式（Doubling Heuristic）。

### 2. 分散式通訊與 Allreduce 算法
Allreduce 是深度學習訓練中關鍵的協同通訊操作，用於高效地在多個 GPU 之間交換損失和梯度向量。
*   **NCCL 與 OpenMPI**：NVIDIA 的 NCCL 庫提供了 GPU 層級的高效算法，如 `allreduce`，與 OpenMPI 結合用於大規模訓練。
*   **環狀算法 (Ring Algorithm)**：將梯度張量分割成 $g$ 個區段，需要 $g-1$ 個步驟，每次在每個 GPU 上複製一個區段。其延遲與 GPU 數量 $g$ 成線性關係。
*   **倍增-折半算法 (Doubling-Halving Algorithm)**：
    *   **原理**：該算法的步驟數為 $\log(g)$，效率極高，特別適用於 $g$ 是 2 的冪次時。
    *   **流程**：第一步，奇數節點複製前半部分，偶數節點複製後半部分；隨後以 $\log(g)$ 步驟反向組合，每次複製的距離和大小都會加倍。
*   **二進位區塊算法 (Binary Blocks Algorithm)**：
    *   **適應性**：當 GPU 數量 $g$ 不是 2 的冪次時，此算法通過將 $g$ 表示為 2 的冪次之和來工作。
    *   **性能考量**：當 $g$ 的冪次分量之間差異較小時效率最高。

## 深度分析
本技術趨勢顯示，隨著深度學習架構的複雜化和訓練數據集的擴大，計算時間和數據並行化需求增長。排程的重點已從單純的資源分配轉向**算法層面的通訊優化**。

環狀架構的成功在很大程度上歸功於其優化了 Allreduce 的通訊開銷。相較於線性延遲的環狀算法，倍增-折半算法（$\log(g)$ 步驟）極大地降低了系統的整體延遲，使其能夠在更廣泛的硬件配置（特別是處理 $g$ 非 2 的冪次時）下提供更穩定的高性能。

此外，排程機制本身也進步了，除了動態排程，還考慮了**任務的停止與重啟**。在某些工作負載模式下，適時地停止和重啟環狀架構的任務，反而能加速整體完成時間，證明了動態排程的複雜性和必要性。

## 視覺化流程圖：Allreduce 算法比較
```mermaid
graph TD
    subgraph "Allreduce 通訊操作"
        A["輸入: 梯度張量 (大小 n)"] --> B{"GPU 數量 g"};
        B --> C["環狀算法 (Ring)"];
        B --> D["倍增-折半算法 (Doubling-Halving)"];
        B --> E["二進位區塊算法 (Binary Blocks)"];
    end

    C --> C_detail["步驟: g-1 步"];
    C_detail --> C_latency["延遲: ∝ g (線性)"];
    C_latency --> C_use["適用: 極大數據集"];

    D --> D_detail["步驟: log(g) 步"];
    D_detail --> D_latency["延遲: 低 (對 2 的冪次)"];
    D_latency --> D_use["適用: g 為 2 的冪次"];

    E --> E_detail["步驟: 依據 g 的冪次和組合"];
    E_detail --> E_latency["延遲: 依據差異大小"];
    E_latency --> E_use["適用: g 為任意整數"];

    subgraph "排程優化趨勢"
        F["傳統 PS (Optimus)"] --> G{限制: 無環狀架構};
        H["動態排程 (本專利)"] --> I["優化: 適用環狀架構"];
        I --> J["核心: 新高效倍增啟發式"];
    end
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 1)|← 上一頁]] | 第 2 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 3)|下一頁 →]]