---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 6)
type: patent_methodology
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# US11693706B2: 分散式深度學習訓練工作動態排程系統與方法
## 摘要
本專利描述了一種用於深度神經網路訓練工作（Deep Learning Training Jobs）的動態排程系統與方法。其核心在於優化在有限的計算資源（PUs）上分配給多個訓練任務（J jobs）的處理單元數量。該方法摒棄了固定分配或輪詢分配的傳統模式，改採用基於**啟發式（Heuristic）的迭代倍增（Iterative Doubling）**機制，確保計算資源得到最高效的利用。

## 核心概念
### 1. 訓練工作與資源定義
*   **訓練工作 (J Jobs):** 每個工作都需要訓練一組權重（Weights），通常採用隨機梯度下降法（SGD）進行訓練。
*   **處理單元 (PUs):** 構成計算叢集的基本單元，可包括圖形處理單元（GPU）、張量處理單元（TPU）或中央處理單元（CPU）。
*   **排程目標:** 根據每個工作訓練速度函數 $f$ 和訓練資料集數量（Epochs），決定如何將 $C$ 個 PUs 分配給 $J$ 個工作，以達到收斂狀態的最快時間。

### 2. 動態排程機制：迭代倍增
本方法的核心創新是排程分配的規則：
*   **PU 數量限制:** 分配給任何單一工作的 PU 數量 $g_j$ 必須是 2 的冪次方（Power of Two），即 $2^{z_j}$。
*   **優化策略:** 系統不固定分配 PU，而是透過一個**啟發式（Heuristic）**來評估哪些工作最適合獲得 PU 數量的倍增。
*   **流程:** 系統會迭代地測試將 PU 數量加倍（例如從 $2^z$ 增加到 $2^{z+1}$）對整體訓練時間的提升，並選擇提升最大的工作進行資源擴充。

### 3. 關鍵通信操作：Allreduce 與環狀結構
*   **Allreduce:** 在每個訓練批次結束後，分散在不同 PU 上估計的權重數據結構 $W$ 必須被收集並同步。這個聚合過程稱為「Allreduce」。
*   **環狀消息傳遞 (Ring-based Message Passing):** 專門為執行 Allreduce 操作設計的環狀結構，被證明是極為有效的通信機制，能高效地將所有 PU 的權重估計值彙總。

## 深度分析
### 資源分配的優勢比較
本系統的動態排程優勢體現在其優化了資源分配的邊界條件：
1.  **優於固定分配:** 傳統固定分配無法應對不同工作在不同階段對計算資源需求的變化。
2.  **優於輪詢分配 (Round Robin):** 輪詢分配會平均分配資源，但無法像本方法一樣，精準地將資源集中到當前最需要加速的任務上。
3.  **倍增的優勢:** 限制 PU 數量為 2 的冪次方，使得啟發式可以更有效地探索資源分配組合空間，找到非線性增益最大的配置。

### 系統邏輯流程
整個系統的邏輯流圍繞著「評估 $\rightarrow$ 決定倍增 $\rightarrow$ 執行 $\rightarrow$ 評估」的閉環迭代過程進行。當系統判斷增加 PU 數量 $2 \times g_j$ 後，會計算該增幅對時間提升的歸一化效益，從而決定下一輪迭代的目標。

```mermaid
graph TD
    subgraph "訓練工作排程流程"
        A[開始: 接收 J 個訓練工作] --> B{計算初始 PU 分配 g_j};
        B --> C[執行 SGD 訓練迭代];
        C --> D[PU 分別估計權重 W];
        D --> E{執行 Allreduce 聚合權重};
        E --> F[計算訓練速度函數 f];
        F --> G{啟發式評估: 哪個工作倍增效益最高?};
        G -- 效益顯著提升 --> H[動態資源優化: 將 PU 數量 g_j 提升至 2*g_j];
        H --> C;
        G -- 效益不顯著/達到極限 --> I[結束: 達到收斂狀態];
    end
    style A fill:#f9f,stroke:#333,stroke-width:2px
    style I fill:#ccf,stroke:#333,stroke-width:2px
    subgraph "核心機制"
        D -- 數據流 --> E["環狀結構 Allreduce"];
        G -->|判斷依據| F;
    end
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 5)|← 上一頁]] | 第 6 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 7)|下一頁 →]]