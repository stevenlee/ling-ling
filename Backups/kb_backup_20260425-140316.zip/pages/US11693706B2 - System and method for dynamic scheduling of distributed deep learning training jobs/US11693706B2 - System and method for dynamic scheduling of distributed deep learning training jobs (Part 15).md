---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 15)
type: patent_method
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# US11693706B2 - 分散式深度學習訓練任務的動態排程系統與方法
## 摘要
本文件描述了一種優化分散式深度學習訓練任務（如使用隨機梯度下降 SGD）的動態排程方法。該方法的核心在於採用巢狀（Nested）的迭代結構，透過估計「時間提升（Time Improvement）」和「訓練速度函數」，精確地識別和臨時分配足夠數量的處理單元（PUs）給予各個任務（Jobs），從而確保資源分配與訓練進度達到最佳匹配，並在達到特定條件時重啟訓練。

## 核心概念
### 1. 巢狀迭代排程結構 (Nested Iteration Structure)
排程過程採用兩層迭代結構：
*   **外層迭代 (Outer Iteration):** 負責整體訓練進度管理，在每一輪外層迭代開始時，系統會估算每個任務剩餘所需的訓練週期（remaining epochs）和訓練速度函數。
*   **內層迭代 (Inner Iteration):** 負責資源的精細化分配。在每一輪內層迭代中，系統會使用「倍增啟發式 (Doubling Heuristic)」來尋找能帶來「最大時間提升」的最佳 PU 數量增量。

### 2. 時間提升估算 (Time Improvement Estimation)
系統使用一個數學公式來量化增加 PU 數量對訓練時間的改善程度：
$$\text{Time Improvement} = \frac{1}{g_j} \left( Q_j f(g_j) - Q_j f(2 \cdot g_j) \right)$$
其中：
*   $g_j$：初始分配給第 $j$ 個任務的 PU 數量。
*   $2 \cdot g_j$：倍增後的 PU 數量。
*   $Q_j$：估計完成第 $j$ 個任務所需的總訓練週期（epochs）。
*   $f(g_j)$：第 $j$ 個任務的訓練速度函數（Training Speed Function）。

### 3. 動態資源重啟 (Dynamic Resource Re-starting)
在完成內層迭代後，系統會將臨時分配的 PU 集合分配到叢集（Cluster）上，然後：
1.  啟動或重啟所有任務，每個任務都執行至少一個時間間隔的 SGD 演算法。
2.  對於達到第二停止條件的任務，輸出權重；對於未達標的任務，則在預定時間間隔後暫停 SGD 演算法，準備進入下一次外層迭代。

## 深度分析
本方法最大的創新點在於其**自適應的資源分配機制**。傳統的排程可能採用固定比例或簡單的線性分配，但本方法通過內層迭代的「倍增啟發式」來模擬資源增加帶來的邊際效益。

**資源分配流程細節：**
1.  **初始化：** 在外層迭代開始時，系統首先為每個任務預先分配一個 PU。
2.  **內層優化：** 內層迭代會不斷執行「識別 $\rightarrow$ 臨時分配」的步驟。它會測試將 PU 數量增加為 $2 \times g_j$ 時，時間提升是否最大。
3.  **收斂與確認：** 當達到停止條件（例如，無法再為任何任務臨時分配更多 PU）時，內層迭代結束。
4.  **執行與循環：** 最終的 PU 組合被確認，並在叢集上啟動訓練。整個過程形成一個持續優化、不斷重啟的循環，直到所有任務達到其終止條件。

## 視覺化流程圖

```mermaid
graph TD
    A[開始: 外層迭代 Outer Iteration] --> B{估算任務參數};
    B --> C[估算剩餘 Epochs Qj];
    B --> D[估算訓練速度函數 f(g_j)];
    D --> E[初始化: 臨時分配 PU];
    E --> F{進入內層迭代 Inner Iteration};
    
    subgraph "內層迭代: 尋找最大時間提升"
        F --> G[步驟一: 識別最大時間提升];
        G --> H{使用倍增啟發式 2*g_j};
        H --> I[步驟二: 臨時分配額外 PU];
        I --> J{是否達到停止條件?};
        J -- 否 --> G;
        J -- 是 --> K[內層迭代結束];
    end
    
    K --> L[分配 PU 至叢集 Cluster];
    L --> M[啟動/重啟 SGD 訓練];
    M --> N{任務是否達標?};
    N -- 是 --> O[輸出權重 Weights];
    N -- 否 --> P[等待預定間隔 Time Interval];
    P --> Q{是否達到外層停止條件?};
    Q -- 否 --> A;
    Q -- 是 --> R[結束];

    style A fill:#ccf,stroke:#333,stroke-width:2px
    style R fill:#fcc,stroke:#333,stroke-width:2px
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 14)|← 上一頁]] | 第 15 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 16)|下一頁 →]]