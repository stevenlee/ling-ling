---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 1)
type: patent_method
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# US11693706B2 - 分散式深度學習訓練任務的動態排程系統與方法

## 摘要
本專利描述了一種用於深度神經網路（DNN）權重訓練的排程演算法。該演算法的核心是**倍增啟發式 (doubling heuristic)**，它能根據預估的訓練集數量和權重收斂速度，動態地為處理單元（PU）分配任務。其主要目標是解決在多個DNN權重資料結構需要高效訓練時，如何最佳化處理單元（PU）的分配問題，特別適用於大型GPU叢集資源的有效利用。

## 核心概念

### 1. 動態排程 (Dynamic Scheduling)
傳統的叢集排程器在支援分散式深度學習訓練方面尚不完善。本方法提出動態排程機制，能夠根據即時的因素，如任務優先級、資源爭用狀況、資源可用性及整體需求，動態地更新分配給特定訓練任務的資源配置。

### 2. 倍增啟發式 (Doubling Heuristic)
這是一種用於預測和分配資源的關鍵機制。它利用兩個主要輸入來決定下一個任務的分配：
*   **預估訓練集數量：** 估計完成特定權重訓練所需的訓練資料集總數。
*   **訓練速度函數 (Training Speed Function)：** 衡量權重收斂的速度，用於判斷訓練進度的變化趨勢。

### 3. 巢狀迴圈訓練模型 (Nested Loop Training Model)
為提高訓練效率，本專利採用了巢狀迴圈結構來管理訓練過程：
*   **內層迭代 (Inner Iterations)：** 負責實際的任務執行。在此階段，處理單元（PU）被排程，任務被啟動或重啟。
*   **外層迭代 (Outer Iterations)：** 負責訓練流程的控制與優化。在此階段，當前任務會被暫停，系統會更新模型參數，然後重新進入內層迭代，從而實現迭代優化。

## 深度分析

### 資源優化與架構
本系統旨在解決大型GPU叢集資源利用率低下的問題。雖然許多研究已使用環狀訊息傳遞架構（如環狀 All-reduce）來執行單一任務，但這些方法並未解決**任務排程**的複雜問題。

### 訊息傳遞與排程流程
在訓練過程中，訊息傳遞（如 `ring-based message passing architecture`）是基礎，但排程層面必須管理多個權重資料結構的訓練。

1.  **任務分配：** 排程器根據倍增啟發式判斷當前最需要資源的任務。
2.  **執行層級：** 內層迴圈負責高頻率的資源調度（啟動/重啟PU和Job）。
3.  **控制層級：** 外層迴圈負責低頻率但關鍵的流程控制（參數更新和迭代週期管理）。

### 流程圖示：動態排程的巢狀結構
```mermaid
graph TD
    root(("啟動 DNN 訓練任務")) --> A["外層迭代開始 (Outer Loop)"];
    A --> B["檢查訓練狀態與參數"];
    B --> C["進入內層迭代 (Inner Loop)"];
    C --> D["排程處理單元 (PU)"];
    D --> E["啟動或重啟任務 (Job Launch/Restart)"];
    E --> F{內層迭代是否完成?};
    F -- 否 --> D;
    F -- 是 --> G["停止當前任務 (Stop Jobs)"];
    G --> H["更新模型參數 (Update Parameters)"];
    H --> I{外層迭代是否結束?};
    I -- 否 --> A;
    I -- 是 --> J(("訓練流程結束"));
```

---
**Mermaid 圖表解釋：**
此圖展示了任務訓練的控制流程。外層迴圈負責整體流程的控制（參數更新），而內層迴圈則負責資源的即時調度（PU排程和任務啟動）。

```mermaid
graph TD
    root(("啟動 DNN 訓練任務")) --> A["外層迭代開始 (Outer Loop)"];
    A --> B["檢查訓練狀態與參數"];
    B --> C["進入內層迭代 (Inner Loop)"];
    C --> D["排程處理單元 (PU)"];
    D --> E["啟動或重啟任務 (Job Launch/Restart)"];
    E --> F{內層迭代是否完成?};
    F -- 否 --> D;
    F -- 是 --> G["停止當前任務 (Stop Jobs)"];
    G --> H["更新模型參數 (Update Parameters)"];
    H --> I{外層迭代是否結束?};
    I -- 否 --> A;
    I -- 是 --> J(("訓練流程結束"));
```

---
第 1 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 2)|下一頁 →]]