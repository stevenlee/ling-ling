---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 5)
type: patent_method
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# US11693706B2：分散式深度學習訓練任務的動態排程系統與方法
## 摘要
本專利描述了一種用於優化分散式深度學習訓練任務資源分配的系統與方法。核心思想是採用**動態資源優化**的策略，通過計算「時間提升量」（Time Improvement）來迭代地、貪婪地將更多的處理單元（PUs）分配給對系統整體性能提升最大的任務，特別強調了在部分任務中採用**環狀訊息傳遞協議**的架構優勢。

## 核心概念
### 1. 時間提升量計算 (Time Improvement)
時間提升量是衡量增加處理單元（PUs）對任務完成時間影響的關鍵指標。其數學形式為：
$$\text{Time Improvement} = f(g_j) - f(2 \cdot g_j)$$
其中：
*   $g_j$：分配給第 $j$ 個任務的初始處理單元數量。
*   $f(g_j)$：任務在 $g_j$ 個 PUs 上的訓練速度函數。
*   $f(2 \cdot g_j)$：任務在 $2 \cdot g_j$ 個 PUs 上的預估訓練速度函數。
*   **優化目標**：系統旨在找到最大的 $\text{Time Improvement}$，以決定在哪個任務上增加資源能帶來最大的時間節省。

### 2. 動態迭代分配機制 (Dynamic Iterative Allocation)
該系統採用一個迭代過程來分配總共 $C$ 個 PUs 給 $J$ 個任務：
1.  **初始化**：首先將 1 個 PU 分配給每個任務。
2.  **識別最佳提升**：在每一次迭代中，系統使用「倍增啟發式」（doubling heuristic）計算所有任務的 $\text{Time Improvement}$，並識別出產生最大提升量的特定任務。
3.  **增加資源**：將額外的 PU 數量分配給該最佳任務，且增加的數量會**倍增**該任務當前已分配的 PU 數量。
4.  **停止條件**：當倍增啟發式無法再為任何任務識別出可行的進一步資源分配時，則停止迭代。

## 深度分析
### 1. 環狀架構排程 (Ring Architecture Scheduling)
在某些具體實施例中，第一個任務（$g_1$ PUs）的 PU 配置被特別優化，要求它們使用**環狀訊息傳遞協議**（message passing protocol in a ring fashion）。這意味著訓練過程中的每個「週期」（epoch）數據流必須在 PU 之間以環形結構傳遞，這是一種針對特定分散式計算拓撲結構的優化。

### 2. 系統與硬體實現
*   **通用設備 (Device)**：描述了在通用處理器和記憶體上實現上述動態分配邏輯，通過軟體指令執行來實施初始化、迭代識別和資源分配的步驟。
*   **ASIC 晶片 (ASIC)**：描述了將此排程邏輯硬體化，專門設計用於高效執行上述動態、迭代的資源分配流程，極大地提升了排程效率。

## 流程圖示：動態資源優化排程流程
```mermaid
graph TD
    subgraph "排程系統核心流程"
        A(("開始: 初始化 PU 分配")) --> B["初始狀態: 每個任務分配 1 PU"];
        B --> C{是否達到停止條件?};
        C -- 否 --> D["第一步: 識別最大時間提升量"];
        D --> E["使用倍增啟發式計算 Time Improvement"];
        E --> F{找到最佳任務 J_best?};
        F -- 是 --> G["第二步: 增加資源"];
        G --> H["將 PU 數量倍增分配給 J_best"];
        H --> C;
        F -- 否 --> I(("結束: 資源分配完成"));
    end

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style I fill:#f9f,stroke:#333,stroke-width:2px
    style C fill:#ccf,stroke:#333
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 4)|← 上一頁]] | 第 5 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 6)|下一頁 →]]