---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 8)
type: entity
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# System and method for dynamic scheduling of distributed deep learning training jobs
## 摘要
本專利描述了一種用於分散式深度學習訓練工作負載的動態調度系統和方法。該系統能夠實時監控資源狀態，根據訓練進度（如模型權重 $\mathbf{W}_j$ 的收斂情況）動態調整資源分配。核心流程包括迭代運行調度演算法、執行 SGD 更新，並在系統狀態改變（如新增工作負載或工作負載完成）時，重新評估並優化資源分配策略，以最大化訓練效率。

## 核心概念
### 1. 迭代調度與資源更新
系統採用迭代方式運行調度演算法。初始階段，系統會為每個工作負載（Job $j$）分配初步的處理單元（PU）。在預定時間後，會暫停計算，然後重新運行調度演算法，進而調整每個工作負載的資源分配 $\mathbf{g}_j$。
*   **動態調整機制：** 系統能夠在集群停止或有新工作負載進入工作池時，實時調整調度。
*   **工作負載移除：** 當任一工作負載 $k$ 的權重 $\mathbf{W}_k$ 達到收斂狀態時，它將從工作池中移除，觸發調度演算法重新運行，重新分配資源。

### 2. 隨機梯度下降 (SGD) 更新
模型權重 $\mathbf{w}$ 的更新遵循 SGD 原理。對於給定的層和工作負載，權重更新公式為：
$$\mathbf{w}_{t+1} = \mathbf{w}_t - \mu \sum_t \nabla \text{loss}(\mathbf{w}, \mathbf{w}_t)$$
其中 $\mu$ 是步長（step size），$\nabla$ 是梯度（gradient），$\text{loss}$ 是損失函數。

### 3. 性能預測模型 (Two-Step Modeling)
為精確估算工作負載的運行時間，系統採用兩步驟模型：
1.  **收斂週期預測 (Q)：** 通過線上擬合（Online Fitting）估計達到收斂所需的預期訓練週期數 $Q$。
2.  **每週期時間預測 ($\mathbf{f}(\mathbf{g})$)：** 為給定的資源配置 $\mathbf{g}$ 建立訓練速度函數 $\mathbf{f}(\mathbf{g})$，該函數用於估計每週期所需的時間。

## 深度分析
### 1. 資源到速度模型 (Resource-to-Speed Model)
本系統提供了一個綜合性的資源模型 $\mathbf{f}(\mathbf{g})$，用於計算不同架構下的訓練速度。該模型綜合了以下四個核心時間組成部分：
*   **前向傳播時間 (Forward Propagation Time):** 訓練集大小 $\times$ 處理單例時間 ($m \times T_{\text{forward}}$)。
*   **反向傳播時間 (Backward Propagation Time):** 訓練集大小 $\times$ 處理單例時間 ($m \times T_{\text{back}}$)。
*   **Allreduce 通訊開銷：** 根據不同的環狀架構（Ring, Doubling-Halving, Binary Blocks）計算的通訊時間。
*   **總體模型 $\mathbf{f}(\mathbf{g})$：** 該模型結合了所有係數 $\theta_0, \theta_1, \theta_2, \theta_3$ 來描述資源 $\mathbf{g}$ 與速度之間的關係。

### 2. 通訊架構模型細節
系統為三種主流的環狀架構提供了具體的運行時間公式：
*   **環狀架構 ($\mathbf{T}_{\text{ring}}$):** 考慮了訊息延遲 ($\alpha$)、傳輸時間 ($\beta$) 和計算成本 ($\gamma$)。
*   **倍增-折半架構 ($\mathbf{T}_{\text{dh}}$):** 採用 $\log(w)$ 因子來計算通訊開銷。
*   **二進位區塊架構 ($\mathbf{T}_{\text{bb}}$):** 採用 $\lfloor \log(w) \rfloor$ 因子來計算通訊開銷。

### 3. 局部迭代與倍增啟發式 (Local Iteration & Doubling Heuristic)
當新工作負載 $m$ 到達時，系統會進入一個「局部迭代」流程。在第一次進入調度邏輯點後，如果資源允許，新工作負載 $m$ 會立即被分配第二個 PU ($\mathbf{g}_m = 2$)。在第二次進入調度點時，系統會使用「倍增啟發式」來判斷哪些工作負載若將 PU 數量加倍，能帶來最大的時間提升（Time Improvement）。

```mermaid
graph TD
    root(("動態調度系統 (Dynamic Scheduler)")) --> A["初始化/監測資源狀態"];
    A --> B{檢查事件觸發};
    B -- "新工作負載到達 (Job Arrival)" --> C["進入局部迭代 (Local Iteration)"];
    B -- "工作負載完成 (Job k Converged)" --> D["移除 Job k 並重置資源分配"];
    B -- "預定時間到 (Time Elapsed)" --> E["執行一次調度循環 (Scheduling Cycle)"];

    C --> C1["初始分配 PU (g_m = 1)"];
    C1 --> C2["檢查資源是否足夠"];
    C2 -- "是" --> C3["分配第二個 PU (g_m = 2)"];
    C3 --> C4["執行倍增啟發式 (Doubling Heuristic)"];
    C4 --> E;

    E --> F["運行 SGD 更新 (w_t+1)"];
    F --> G["計算性能指標 (Q & f(g))"];
    G --> H["優化資源分配 (Adjust g_j)"];
    H --> I{是否達到穩定/收斂?};
    I -- "否" --> E;
    I -- "是" --> J["等待下一次調度週期"];

    style root fill:#f9f,stroke:#333,stroke-width:2px
    style A fill:#ccf,stroke:#333
    style B fill:#ffc,stroke:#333
    style C fill:#ddf,stroke:#333
    style D fill:#ddf,stroke:#333
    style E fill:#ddf,stroke:#333
    style F fill:#cff,stroke:#333
    style G fill:#cff,stroke:#333
    style H fill:#cff,stroke:#333
    style I fill:#ffc,stroke:#333
    style J fill:#ccc,stroke:#333
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 7)|← 上一頁]] | 第 8 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 9)|下一頁 →]]