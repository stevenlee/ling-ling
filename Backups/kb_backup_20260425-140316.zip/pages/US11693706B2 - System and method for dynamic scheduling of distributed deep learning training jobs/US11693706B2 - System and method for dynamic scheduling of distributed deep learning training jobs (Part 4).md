---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 4)
type: patent_method
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# US11693706B2：分散式深度學習訓練工作動態排程系統與方法
## 摘要
本文件描述了一種用於優化分散式深度學習訓練工作負載的系統和方法。核心概念是建立一個迭代式、自適應的排程機制，能夠根據訓練進度、資源需求和性能指標（如時間提升）動態地重新分配和調整計算資源（Processing Units, PUs），以最大化訓練效率並縮短收斂時間。該方法涵蓋了從基礎的資源替換到複雜的巢狀迭代優化流程。

## 核心概念
### 1. 分散式計算資源 (PUs)
本方法支持多樣化的計算單元作為工作負載的執行基礎，包括：
*   **圖形處理單元 (GPUs)**：常見的加速器，具備特定的時脈速度、核心數和記憶體頻寬。
*   **張量處理單元 (TPUs)**：專為矩陣運算優化的硬體，通常使用高頻寬記憶體 (HBM)，並包含矩陣處理單元 (MXU)。
*   **中央處理單元 (CPUs)**：作為基礎的處理單元。
*   **資源集合定義**：系統支持的 PU 數量通常是 $2$ 的冪次方 $\{1, 2^1, 2^2, ...\}$。

### 2. 動態資源優化循環 (Dynamic Re-allocation Cycle)
基礎的優化流程是一個週期性的迭代過程：
1.  **初始執行**：在集群上啟動 $J$ 個工作，每個工作執行隨機梯度下降 (SGD) 演算法一段時間。
2.  **暫停與評估**：超過預定時間間隔後，暫停 SGD 演算法。
3.  **二次初始化與識別**：基於累積的數據，進行二次初始化，並迭代地識別和預分配新的 PU 資源分配。
4.  **重新啟動**：使用新的 PU 分配重新啟動 SGD 演算法。

### 3. 進階排程機制：巢狀迭代優化 (Nested Iteration Optimization)
這是本方法最複雜的優化層級，它在「外層迭代」和「內層迭代」之間交替進行，以精確地優化資源分配：
*   **外層迭代 (Outer Iteration)**：估計每個工作剩餘的訓練周期數和訓練速度函數。
*   **內層迭代 (Inner Iteration)**：在外層迭代內部執行，目標是尋找最大的「時間提升」(Time Improvement)。
    *   **關鍵步驟**：使用**倍增啟發式 (Doubling Heuristic)** 識別最佳資源增量。
    *   **資源分配**：將額外的 PU 數量預分配給特定工作，且該數量會**倍增**（Double）先前預分配的數量。
    *   **終止條件**：當倍增啟發式無法再為任何工作識別出進一步的臨時分配時，內層迭代終止。
*   **資源固化與重啟**：內層迭代結束後，所有預分配的 PU 被正式分配給集群，然後重新啟動或啟動 SGD 演算法。

## 深度分析
### 環狀架構排程 (Ring-based Scheduling)
本方法提供了一種用於**聯合訓練 (Joint Scheduling)** 的機制，特別適用於需要同時訓練多個權重集（$W_1$ 和 $W_2$）的場景。
*   **核心原理**：聯合排程基於**倍增啟發式**和**環狀訊息傳遞演算法 (Ring-based Message Passing Algorithm)**。
*   **應用場景**：第一個分類（使用 $W_1$ 處理第一類數據）和第二個分類（使用 $W_2$ 處理第二類數據）可以同時在多個 PU 上進行，這確保了不同模態或不同階段的訓練可以高效地在共享的計算資源上交錯進行。

### 動態資源優化與倍增啟發式
動態資源優化是本專利的重點，其核心是**「預測性增強」**。
*   **倍增啟發式 (Doubling Heuristic)**：這是一種資源分配的決策規則。它假設如果某個工作在當前資源配置下，增加 $N$ 個 PU 可以帶來最大的時間提升，那麼增加 $2N$ 個 PU 更有可能帶來更顯著的提升，從而指導內層迭代尋找最佳的資源增量。
*   **優化目標**：通過不斷地在內層迭代中進行「預分配 $\rightarrow$ 測試 $\rightarrow$ 確定」的循環，系統能夠極大地精確化地匹配工作負載的計算需求與集群的實際資源能力，從而實現真正的動態、自適應的資源優化。

## 視覺化流程圖：巢狀迭代優化流程
```mermaid
graph TD
    subgraph "外層迭代 (Outer Iteration)"
        A["開始外層迭代"] --> B["估計剩餘 Epochs 與訓練速度"];
        B --> C["預分配初始 PU 給每個工作"];
        C --> D["進入內層迭代 (Inner Iteration)"];
    end

    subgraph "內層迭代 (Inner Iteration) - 資源識別與增強"
        D --> E{步驟 i: 識別最大時間提升?};
        E -- 是 --> F["使用倍增啟發式識別增量"];
        F --> G["步驟 ii: 預分配額外 PU (數量倍增)"];
        G --> H{步驟 iii: 達到停止條件?};
        H -- 否 --> E;
        H -- 是 --> I["內層迭代結束"];
    end

    I --> J["外層：正式分配 PU (基於內層結果)"];
    J --> K["啟動/重啟 SGD 演算法 (至少一段時間)"];
    K --> L["等待預定間隔後，暫停 SGD"];
    L --> M["輸出權重或進入下一次外層迭代"];
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 3)|← 上一頁]] | 第 4 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 5)|下一頁 →]]