---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 3)
type: patent_method
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# US11693706B2 - 深度學習工作負載的動態排程系統與方法
## 摘要
本專利描述了一種用於分散式深度學習訓練工作負載的動態排程方法。核心思想是通過迭代優化，動態調整分配給每個訓練任務的處理單元（PUs）數量，以最大化整體訓練效率。該方法特別強調了採用「環狀架構」（Ring Architectures）而非傳統的參數伺服器（Parameter Servers）來優化資料平行工作負載的資源利用率。

## 核心概念
### 1. 動態資源優化與排程機制
本方法旨在解決深度學習訓練任務（Jobs）與處理單元（PUs）之間資源分配不均的問題。排程過程是一個迭代優化循環，其目標是找出能帶來最大「時間改善」（Time Improvement）的資源分配組合。

*   **初始化階段**: 首先，為每個訓練任務暫時分配一個處理單元（PU）。
*   **迭代優化**: 在每次迭代中，系統會執行兩步驟的優化流程：
    1.  **識別最佳提升**: 根據「倍增啟發式」（doubling heuristic），識別出能帶來最大時間改善的特定任務。
    2.  **暫時分配增量資源**: 將額外的處理單元數量分配給該最佳任務，且增加的數量會是該任務目前已分配數量的倍數。
*   **停止條件**: 當「倍增啟發式」無法為任何任務識別出進一步的暫時分配時，則停止迭代優化。

### 2. 環狀架構（Ring Architectures）
相較於傳統的參數伺服器架構，環狀架構更適合資料平行（Data Parallel）的工作負載。在環狀架構中，訓練過程的梯度更新和訊息傳遞（如使用 Allreduce 或 Ring-based message passing）是環形結構化的，這被證明能提高整體資源利用率。

## 深度分析
### 1. 時間改善公式 (Time Improvement)
排程優化的核心指標是「時間改善」。其數學表達式如下：

$$
\text{Time Improvement} = \frac{1}{g_j} \left( Q_j f(g_j) - Q_j f(2 \cdot g_j) \right)
$$

其中：
*   $g_j$: 分配給第 $j$ 個任務的處理單元數量。
*   $f(g_j)$: 第 $j$ 個任務的訓練速度函數（Training Speed Function）。
*   $Q_j$: 完成第 $j$ 個任務所需的預估 Epoch 數。

此公式用於量化將資源從當前分配 ($g_j$) 增加到兩倍 ($2 \cdot g_j$) 對任務完成時間的潛在改善程度。

### 2. 訓練算法的實現
在實際執行階段，任務通常會採用以下算法進行權重更新：
*   **隨機梯度下降 (SGD)**: 用於更新神經網路權重 $W_1$。
*   **環狀訊息傳遞 (Ring-based Message Passing)**: 在環狀架構中，用於部分更新權重 $W_1$。
*   **Allreduce 算法**: 一種標準的同步算法，用於在所有處理單元間同步和彙總梯度信息。

## 流程圖：動態資源優化排程循環

```mermaid
graph TD
    A[開始: 初始化 PU 分配] --> B{迭代優化循環};
    B -- 進入迭代 --> C[步驟 i: 識別最大時間改善];
    C --> D{倍增啟發式判斷};
    D -- 找到最佳任務 --> E[步驟 ii: 暫時分配增量 PU];
    E --> F{是否達到停止條件?};
    F -- 否 --> B;
    F -- 是 --> G[優化完成: 確定最終資源分配];
    G --> H[執行訓練: SGD/Allreduce];
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 2)|← 上一頁]] | 第 3 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 4)|下一頁 →]]