---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 13)
type: patent_concept
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# System and method for dynamic scheduling of distributed deep learning training jobs
## 摘要
本文件描述了一種用於分散式深度學習訓練工作負載的動態排程系統和方法。核心目標是優化處理單元（PUs，如GPU、TPU、CPU）的分配，以最小化整體訓練任務的完成時間。該方法採用迭代式的優化過程，利用「倍增啟發式」（doubling heuristic）來識別能帶來最大時間改善的資源分配組合，從而實現資源的動態重分配和最佳化調度。

## 核心概念
### 1. 動態排程機制 (Dynamic Scheduling Mechanism)
本系統的核心在於其迭代式的資源分配過程。排程過程首先對每個任務預先進行臨時分配，隨後在迭代中不斷識別和臨時分配資源，以確定最佳的 PU 到任務的分配方案。

*   **倍增啟發式 (Doubling Heuristic):** 這是排程算法的關鍵步驟。在每次迭代的初步步驟中，系統會根據此啟發式來計算「最大的時間改善」（greatest Time Improvement）。該啟發式假設通過增加 PU 的數量（倍增）可以帶來性能增益，從而指導排程器尋找最佳的資源擴充點。
*   **PU 類型與分配:** 任務可以分配到多種處理單元（PUs），包括 GPU、TPU 或 CPU。系統能夠處理從 1 到 8 個 PU 的不同配置。

### 2. 排程策略類型 (Scheduling Strategy Types)
為應對不同工作負載和資源可用性，本系統定義了多種排程策略：

*   **預計算策略 (Precompute):** 假設系統已根據預先計算的排程時間來生成了最小模擬數據集，此策略在可行時通常表現最佳。
*   **探索性策略 (Exploratory):** 該策略設計用於平衡「探索」與「最佳化」的權衡。它會給予新任務一段時間（例如前十分鐘）使用一定數量的 GPU 進行測試運行，以評估其最佳的資源需求。
*   **固定策略 (Fixed):** 這是最直接的策略，任務會固定請求特定數量的 PU（如 1 個、2 個、4 個或 8 個 GPU）。

### 3. 工作負載與競爭環境 (Workload and Contention)
排程的性能高度依賴於工作負載的特性和資源的競爭程度：

*   **競爭程度 (Contention):** 模擬了不同程度的資源競爭：
    *   **極端競爭 (Extreme):** 模擬了大量任務同時湧入的場景。
    *   **中度競爭 (Moderate):** 模擬了較為穩定的工作負載。
    *   **無競爭 (None):** 模擬了資源充足、無衝突的理想場景。
*   **任務到達模擬:** 任務的到達時間模擬使用指數分佈（Exponential arrival times），這在理論上等同於泊松過程（Poisson process）。

## 深度分析
### 1. 性能優化與重啟機制
系統的設計強調了資源的持續利用和優化。當訓練任務暫停後再恢復時（例如在不同 Epoch 數量的檢查點），系統能夠通過調整學習率和重新分配資源來顯著減少總運行時間。研究表明，排程器通過動態重縮放（rescaling）來利用新釋放的資源，能顯著提升整體工作負載的運行時效能。

### 2. 策略比較與最佳實踐
實驗數據比較了不同策略在不同競爭環境下的表現：

*   **預計算優勢:** 當預計算可行時，該算法始終表現出優於或持平於其他策略的性能。
*   **探索性限制:** 探索性算法雖然旨在優化，但在極端競爭環境下，其「探索-最佳化」的權衡（explore-optimize tradeoff）可能表現不佳。
*   **環形架構優勢:** 專門針對環形架構（ring architectures）的排程算法，特別是結合了「通訊感知」（communication aware）的排程，已被證明能顯著提高集群的整體利用率。

### 3. 流程總結
總體而言，該方法提供了一個從初步分配到迭代優化的完整框架，其核心優勢在於其適應性：能夠根據即時的資源可用性、任務的特性和系統的競爭壓力，動態地調整 PU 的分配，從而實現超越靜態排程的性能提升。

```mermaid
graph TD
    A[開始: 接收多個任務J] --> B{初始化: 臨時分配 PU 給每個任務};
    B --> C[迭代優化過程];
    C --> D{第一步: 識別最大時間改善};
    D --> E[應用倍增啟發式 (Doubling Heuristic)];
    E --> F{確定最佳 PU 組合};
    F --> G[臨時分配 PU 資源];
    G --> H{是否達到收斂或資源限制?};
    H -- 否 --> C;
    H -- 是 --> I[輸出最佳排程方案];
    I --> J[結束: 最小化任務完成時間];

    subgraph "排程環境參數"
        K1["競爭程度: 極端/中度/無"]
        K2["任務到達: 指數分佈"]
        K3["PU 類型: GPU/TPU/CPU"]
    end

    subgraph "主要策略選擇"
        S1["預計算策略 (Precompute)"]
        S2["探索性策略 (Exploratory)"]
        S3["固定策略 (Fixed)"]
    end
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 12)|← 上一頁]] | 第 13 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 14)|下一頁 →]]