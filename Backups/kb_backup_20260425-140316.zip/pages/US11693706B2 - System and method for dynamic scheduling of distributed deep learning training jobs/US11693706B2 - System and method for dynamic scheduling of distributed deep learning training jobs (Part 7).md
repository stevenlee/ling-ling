---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 7)
type: entity
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# 動態深度學習訓練任務排程系統 (Dynamic Deep Learning Training Job Scheduling)
## 摘要
本文件描述了一種用於分散式深度學習訓練任務的動態資源分配和排程方法。該方法採用一種貪婪的（Greedy）啟發式（Heuristic）策略，旨在識別出能從資源增加中獲得「每個處理單元（PU）時間改善最大」的任務。排程過程是迭代的，通過逐步增加被分配給任務的 PU 數量（通常是倍增），直到無法再增加任何任務的 PU 數量而不超過總可用資源池為止。

## 核心概念
### 1. 啟發式優化目標 (Heuristic Optimization Goal)
排程的核心目標是最大化「每個 PU 的時間改善量」（Time Improvement per PU）。這模擬了將時間視為昂貴商品，目標是找到 PU 的分配組合，使得單位資源帶來的成本（時間）降低最大。

### 2. 迭代倍增機制 (Iterative Doubling Mechanism)
*   **初始狀態：** 每個任務 $j$ 最初被分配 1 個 PU ($g_{j,old} = 1$)。
*   **增量計算：** 算法評估將任務 $j$ 的 PU 數量從 $g_{j,old}$ 增加到 $g_{j,new} = 2 \times g_{j,old}$ 所帶來的潛在效益。
*   **狀態更新：** 如果增加 PU 數量後，總分配的 PU 數未超過總容量 $C$，則更新任務 $j$ 的暫時分配 PU 數 $g_{j,new}$，並將剩餘 PU 池（PU pool）減去本次分配的資源。

### 3. 時間改善量計算 (Time Improvement Calculation)
時間改善量是衡量資源分配效益的關鍵指標。
*   **訓練時間公式：** 任務 $j$ 完成訓練所需時間 $T$ 與訓練速度函數 $f$ 成反比：$T = Q_j / f(g_j)$。
*   **時間改善量（平均）：** 該方法計算的「每個 PU 的時間改善量」為：
    $$\text{Time Improvement per PU} = \frac{1}{g_{j,old}} \times (T_{j,old} - T_{j,new})$$
    其中，$T_{j,old}$ 是舊配置下的完成時間，$T_{j,new}$ 是新配置（PU 翻倍）下的完成時間。

## 深度分析
### 1. 資源分配的邊界條件 (Resource Constraints)
*   **剩餘資源處理：** 算法考慮到一個特殊情況：即使總分配的 PU 數小於總容量 $C$，且沒有任何任務可以翻倍分配而不超過剩餘資源 $N_{\text{remaining}}$，則這 $N_{\text{remaining}}$ 的 PU 不會被分配給任何任務。
*   **與 Round-Robin 的區別：** 這種動態排程與傳統的輪詢（Round-Robin）排程不同，後者在完成暫時分配後，剩餘資源 $N_{\text{remaining}}$ 必然為零。

### 2. 深度神經網路與權重結構 (DNN and Weight Structure)
*   每個任務對應一個深度神經網路（DNN），其權重 $W_j$ 結構化為一系列二維矩陣 $w_{j,i}$，其中 $i$ 代表層次。
*   這部分描述了任務本身的數據結構，是計算訓練速度函數 $f_j$ 的基礎輸入。

### 3. 算法流程總結
算法是一個循環過程：
1.  輸入：所有任務的訓練速度函數 $f_j$ 和總 PU 容量 $C$。
2.  初始化：所有任務分配 1 PU。
3.  迭代：計算所有任務翻倍分配後的 $\text{Time Improvement per PU}$。
4.  選擇：選擇能帶來最大時間改善量的任務，並更新其 PU 狀態。
5.  檢查：若剩餘 PU 不足夠支持任何任務的翻倍，則停止迭代。

```mermaid
graph TD
    root(("開始: 接收任務與總容量 C")) --> A["初始化: 所有任務分配 1 PU"];
    A --> B{計算所有任務的 PU 翻倍效益};
    B --> C["計算 Time Improvement per PU"];
    C --> D{效益是否為最大?};
    D -- 是 --> E["選擇最佳任務並更新 PU 狀態"];
    E --> F["更新剩餘 PU 池 (C)"];
    F --> G{剩餘 PU 是否足夠支持下一次翻倍?};
    G -- 是 --> B;
    G -- 否 --> H["排程完成: 輸出最終分配的 PU 資源"];
    D -- 否 --> H;
```

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 6)|← 上一頁]] | 第 7 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 8)|下一頁 →]]