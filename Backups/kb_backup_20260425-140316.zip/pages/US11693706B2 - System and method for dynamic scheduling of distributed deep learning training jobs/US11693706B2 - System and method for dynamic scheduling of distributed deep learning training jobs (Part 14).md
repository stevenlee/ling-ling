---
title: US11693706B2 - System and method for dynamic scheduling of distributed deep
  learning training jobs (Part 14)
type: patent_method
date_created: '2026-04-25'
tags:
- binary-evolution
- deep-learning
- ensemble-learning
- gpu-cluster
- gpu叢集
- system-scheduling
- 倍增啟發式
- 深度學習
- 系統排程
---
# US11693706B2 - 動態調度分散式深度學習訓練任務系統與方法
## 摘要
本專利描述了一種動態調度分散式深度學習訓練任務的方法。其核心在於在訓練迭代過程中，根據計算資源的可用性，迭代性地為特定任務動態分配額外的處理單元（PUs）。分配的增量數量遵循倍增（通常是加倍）的規則，直到達到無法再分配任何 PU 的停止條件。此外，該方法還提供了一個複雜的公式來計算「時間提升」（Time Improvement），用以優化資源分配的決策。

## 核心概念
### 迭代式資源分配與停止條件
系統採用迭代方式為任務分配資源。在每次迭代中，會為特定任務分配額外的 PU 數量，該額外數量是先前分配 PU 數量的倍數（例如加倍）。
*   **分配機制**: 迭代性地增加 PU 數量。
*   **停止條件**: 當無法再向任何一個任務分配任何 PU 時，即達到預設的停止條件，則停止調度過程。

### 時間提升計算公式 (Time Improvement)
時間提升是衡量資源分配效益的關鍵指標，它基於以下三個要素計算：
1.  **$Q_j$**: 完成第 $j$ 個任務所需的預估 Epoch 數（一個 Epoch 等於一組訓練資料）。
2.  **$f(g_j)$**: 第 $j$ 個任務的訓練速度函數（Training Speed Function）。
3.  **$g_j$**: 分配給第 $j$ 個任務的 PU 數量。

公式形式為：
$$\text{Time Improvement} = \frac{1}{g_j} \left( Q_j f(g_j) - Q_j f(2 \cdot g_j) \right)$$
此公式用於比較在不同 PU 數量下，完成任務所需時間的差異，從而指導最佳的資源分配決策。

## 深度分析
### 深度學習優化與通訊協議
該調度系統的優化過程與深度學習模型的訓練機制緊密結合：
*   **優化算法**: 系統可配置為使用隨機梯度下降（SGD）算法來更新神經網路權重。
*   **訊息傳遞**: 資源調度可以利用特定的通訊協議來更新權重：
    *   **環形訊息傳遞 (Ring-based Message Passing)**: 適用於在環形結構中傳遞訊息。
    *   **Allreduce 算法**: 一種在分散式系統中同步和聚合所有計算節點數據的標準算法。
*   **硬件支持**: 該系統具備高度的硬件適配性，可支持使用多個圖形處理單元（GPUs）、張量處理單元（TPUs）或中央處理單元（CPUs）作為 PU 組成。

### 流程控制與執行階段
系統的執行流程包含至少兩個階段：
1.  **初步運行 (First Time)**: 在集群上運行 $J$ 個任務，每個任務執行 SGD 算法至少一個訓練間隔。
2.  **停止與輸出**: 在超過預定時間間隔後，停止 SGD 算法，並輸出已達到第二個停止條件的任務權重。

## 視覺化流程圖
```mermaid
graph TD
    A[開始: 初始 PU 分配] --> B{檢查停止條件};
    B -- 否 --> C[計算時間提升: Time Improvement];
    C --> D[根據公式調整 PU 數量 (倍增)];
    D --> E[重新分配 PU 給所有任務];
    E --> F{是否達到最大迭代次數?};
    F -- 否 --> B;
    F -- 是 --> G[執行 SGD 訓練 (至少一個間隔)];
    G --> H[等待預定時間間隔];
    H --> I[輸出權重 (達到第二停止條件)];
    I --> J[結束];
```

## pending_concepts
['未涵蓋的後續概念']

---
[[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 13)|← 上一頁]] | 第 14 / 16 | [[US11693706B2 - System and method for dynamic scheduling of distributed deep learning training jobs (Part 15)|下一頁 →]]