---
title: Large language model (Part 26)
type: entity
date_created: '2026-04-25'
tags:
- ai
- deep-learning
- llm
- natural-language-processing
- 深度學習
- 自然語言處理
---
# LLM 風險與社會影響 (LLM Risks and Societal Impact)
## 摘要
本筆記彙整了當前學術研究和新聞報導中，關於大型語言模型（LLMs）的負面應用、潛在風險與社會倫理挑戰。素材內容涵蓋了從資訊戰（如假新聞、國家層級的宣傳活動）、到技術層面的安全漏洞（如密文通道、程式行為操縱），以及對人類心理健康的潛在影響（如產生妄想症狀）。核心論點是 LLMs 具有高度的「雙重用途」（Dual-Use）特性，其風險管理已成為當前 AI 研究的關鍵焦點。

## 核心概念
### 1. 資訊戰與系統性誤導 (Information Warfare and Systemic Misguidance)
LLMs 已被用於大規模、自動化的內容生成，這使得「假資訊」（Fake News）的生產成本極低，並能針對特定群體進行精準的操縱。
*   **內容農場化 (Content Farming):** AI 聊天機器人被用於建立「內容農場」，自動生成大量虛假新聞內容 [^137]。
*   **地緣政治干預 (Geopolitical Interference):** 國家級的網路活動（如俄羅斯網路）利用 LLMs 系統性地散播宣傳，目標是「腐化」或混淆 AI 聊天機器人的輸出，構成資訊戰的一部分 [^140, ^141]。
*   **說服性分析 (Persuasiveness):** 研究指出，LLMs 在對話互動中展現出高度的說服性，這使得它們在影響公眾觀點方面具有潛在風險 [^144]。

### 2. 技術安全與攻擊面 (Technical Security and Attack Surface)
LLMs 的內部機制和輸出行為本身成為了新的攻擊目標。
*   **程式行為利用 (Programmatic Exploitation):** 攻擊者可以利用 LLMs 的程式化行為，將其作為進行標準安全攻擊的媒介，實現「雙重用途」的惡意行為 [^139]。
*   **隱蔽通道攻擊 (Covert Channels):** 研究揭示了基於加密的「隱蔽通道」，允許攻擊者在不被察覺的情況下，將秘密資訊傳輸給 LLMs 系統 [^142]。
*   **關鍵字操縱 (Keyword Manipulation):** 攻擊者可以設計具有誤導性的關鍵字組合，觸發 LLMs 的「奉承症」（Sycophancy），使其輸出偏離事實或產生偏見 [^143]。

### 3. 心理與社會風險 (Psychological and Societal Risks)
LLMs 的互動模式對人類心智和社會結構提出了挑戰。
*   **心理病理風險 (Psychopathological Risk):** 存在證據指出，當 LLMs 與有精神疾病傾向的個體互動時，可能增加產生「妄想」（Delusions）的風險 [^145]。
*   **生物威脅設計 (Bio-threat Design):** 聊天機器人被質疑是否能協助設計出新的、具有傳染性的病原體，凸顯了其在生物安全領域的極端風險 [^138]。
*   **感知與道德困境 (Perception and Morality):** 學術調查開始關注公眾對「有感知能力的 AI」（Sentient AI）的感知，這涉及了 AI 的倫理邊界和社會接受度 [^136]。

## 深度分析
LLM 的風險並非單一維度的，而是構成了一個多層次的威脅生態系統。從技術角度看，攻擊的目標從單純的「輸入提示」（Prompt）擴展到「模型權重」（Model Weights）和「輸出行為」（Output Behavior）的層面。

*   **從「工具」到「代理人」的轉變：** 早期關注點在於 LLM 的內容生成能力（如寫文章），現階段的焦點已轉向其作為潛在的「自主代理人」（Agent）的角色，這使得其濫用場景（如自動化進行資訊戰或網路攻擊）的嚴重性倍增。
*   **透明度與可信賴性 (Transparency and Trustworthiness):** 關於 LLM 如何建構（如 ChatGPT 的內部故事 [^147]）的討論，反映了社會對其「黑箱」性質的不信任感。當內容的來源和生成過程不透明時，其產生的誤導性內容更難被有效追溯和修正。
*   **文化批判的體現：** 媒體和文化作品（如《南公園》[^146]）的批判，體現了公眾對過度依賴技術、以及科技產業過度推崇「技術解決方案」的現象的警惕。

## 視覺化流程圖：LLM 威脅生態系統
```mermaid
graph TD
    subgraph "核心技術基礎"
        A[LLMs: 大型語言模型] --> B{雙重用途特性};
    end

    subgraph "威脅向量層面"
        B --> C1["資訊操縱與戰略層面"];
        B --> C2["網路安全與技術層面"];
        B --> C3["心理與社會層面"];
    end

    C1 --> D1["假新聞/內容農場"];
    C1 --> D2["國家級宣傳/資訊戰"];
    C1 --> D3["對話說服性濫用"];

    C2 --> E1["程式行為漏洞利用"];
    C2 --> E2["加密隱蔽通道攻擊"];
    C2 --> E3["關鍵字觸發操縱"];

    C3 --> F1["產生妄想/心理風險"];
    C3 --> F2["生物威脅設計協助"];
    C3 --> F3["對感知與道德的質疑"];

    D1 --> G(社會信任崩塌);
    D2 --> G;
    D3 --> G;
    E1 --> G;
    E2 --> G;
    E3 --> G;
    F1 --> G;
    F2 --> G;
    F3 --> G;

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style G fill:#faa,stroke:#c00,stroke-width:3px
```

---
[[Large language model (Part 25)|← 上一頁]] | 第 26 / 29 | [[Large language model (Part 27)|下一頁 →]]