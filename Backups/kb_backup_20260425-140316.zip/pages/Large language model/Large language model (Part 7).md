---
title: Large language model (Part 7)
type: concept
date_created: '2026-04-25'
tags:
- ai
- deep-learning
- llm
- natural-language-processing
- 深度學習
- 自然語言處理
---
# 大型語言模型擴展法則與突現能力 (LLM Scaling and Emergence)
## 摘要
本節探討大型語言模型 (LLM) 的性能如何依賴於其訓練資源的擴展，即模型參數規模 ($N$)、預訓練資料量 ($D$) 以及總計算成本 ($C$)。核心概念是「擴展法則」(Scaling Laws)，它提供了一個數學模型來預測模型性能。當模型規模達到特定閾值時，會出現「突現能力」(Emergent Abilities)，這些能力是模型複雜組件交互作用的結果，而非明確編程的結果。

## 核心概念

### 擴展法則 (Scaling Laws)
擴展法則是根據經驗統計學建立的定律，用於預測 LLM 的性能。它指出模型預訓練後的表現主要取決於以下三個關鍵因素：
1. **計算成本 ($C$)**: 預訓練所需的總計算量（以 FLOPs 計）。
2. **模型規模 ($N$)**: 模型的參數數量（即層中的神經元數量、權重和偏差）。
3. **資料集規模 ($D$)**: 預訓練資料庫的代幣 (token) 數量。

**Chinchilla 擴展法則** 提出了一個具體的數學關係，用於描述在單個週期 (one epoch) 訓練下，模型成本 ($C$) 與參數 ($N$)、資料量 ($D$) 之間的關係：
$$
{\displaystyle {\begin{cases}C=C_{0}ND\\[6pt]L={\frac {A}{N^{\alpha }}}+{\frac {B}{D^{\beta }}}+L_{0}\end{cases}}}
$$
其中，$L$ 代表平均負對數似然損失 (average negative log-likelihood loss)，這是衡量模型性能的關鍵指標。

### 突現能力 (Emergent Abilities)
突現能力是指當模型規模（$N$）達到某個臨界點（在圖表上稱為 "break"）時，模型突然獲得的能力。這些能力並非預先設計或明確編程的，而是源於模型內部組件複雜互動的結果。

**具體範例包括：**
*   **上下文學習 (In-context learning)**：僅透過範例演示，模型就能執行任務，例如算術運算、國際音標字母 (IPA) 解碼等。
*   **思維鏈提示 (Chain-of-thought prompting)**：要求模型逐步推理，在較大參數的模型上顯著提升性能。

## 深度分析

### 性能曲線的數學模型
研究顯示，模型性能 ($y$) 與參數數量 ($x$) 的關係，可以根據衡量指標的不同呈現出不同的數學曲線，這為理解「突現」提供了理論基礎：
*   若 $y = \text{平均 } \Pr(\text{正確代幣})$，則 $(\log x, y)$ 呈現**指數曲線**。
*   若 $y = \text{平均 } \log(\Pr(\text{正確代幣}))$，則 $(\log x, y)$ 呈現**直線**。
*   若 $y = \text{平均 } \Pr(\text{最可能代幣是正確的})$，則 $(\log x, y)$ 呈現**階梯函數** (step-function)，此類變化最符合「突現」的視覺描述。

### 擴展法則的意義
擴展法則的發現極大地改變了 AI 模型的開發範式。它表明，只要系統性地增加計算資源和數據量，模型性能的提升是可預測和可量化的，為未來 LLM 的設計和資源分配提供了科學依據。

## 視覺化模型流程

```mermaid
graph TD
    subgraph "LLM 性能決定因素"
        A["計算成本 (C)"] -->|決定| F(模型性能 L)
        B["模型參數規模 (N)"] -->|影響| F
        C["預訓練資料量 (D)"] -->|影響| F
    end

    subgraph "擴展法則模型 (Chinchilla)"
        B -- "N 決定成本" --> C_Calc["C = C₀ND"]
        C -- "D 決定成本" --> C_Calc
        A --> C_Calc
    end

    subgraph "性能預測"
        C_Calc --> D_Calc["L = f(N, D)"]
        D_Calc --> E["平均負對數似然損失 (L)"]
    end

    E --> F
    F[模型性能 L]

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#ccf,stroke:#333,stroke-width:2px
    style C fill:#cfc,stroke:#333,stroke-width:2px
    style F fill:#ff9,stroke:#333,stroke-width:4px
```

---
[[Large language model (Part 6)|← 上一頁]] | 第 7 / 29 | [[Large language model (Part 8)|下一頁 →]]