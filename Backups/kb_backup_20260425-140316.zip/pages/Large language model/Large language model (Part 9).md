---
title: Large language model (Part 9)
type: concept_overview
date_created: '2026-04-25'
tags:
- ai
- deep-learning
- llm
- natural-language-processing
- 深度學習
- 自然語言處理
---
# 大型語言模型評估與理論基礎 (LLM Evaluation and Theory)
## 摘要
本筆記概述了大型語言模型 (LLM) 在理論建構與實務評估上的兩個主要面向。在理論層面，模型發展從模擬人類認知過程（如認知語言學、神經理論）開始，發展出如機率上下文無窮文法 (PCFG) 等框架來生成語法正確的語言。在評估層面，核心指標是困惑度 (Perplexity)，它量化了模型預測數據集的優劣程度，並輔以各種基準測試 (Benchmarks) 來評估常識推理、偏見和事實查核等具體能力。

## 核心概念
### 語言模型與認知模擬
LLM 的「智能」展現包含兩個層面：一是如何建構計算系統來模擬思維和語言（認知層面）；二是系統生成人類可接受語言的能力（語法層面）。
*   **神經理論語言學 (NTL)**：由 George Lakoff 提出，主張語言作為認知任務的計算基礎，描繪了人類大腦的特定神經結構如何塑造思維和語言的本質。
*   **機率上下文無窮文法 (PCFG)**：Vyvyan Evans 描繪了該文法在自然語言處理 (NLP) 中扮演的角色，用於模型化認知模式並生成語法上可接受的人類語言。

### 困惑度 (Perplexity)
困惑度是衡量任何語言模型性能的標準指標。它衡量了模型預測數據集內容的難易程度：模型給予數據集越高機率，困惑度越低。
*   **數學定義**：困惑度是平均負對數機率的指數。
*   **計算方式**：
    *   **自迴歸 (Autoregressive)**：上下文是位於目標 Token $i$ **之前**的文本片段。
    *   **遮罩式 (Masked)**：上下文是圍繞目標 Token $i$ 的**周圍**文本片段。
*   **關聯性**：困惑度與信息論中的**熵 (Entropy)** 概念緊密相關，這在 Claude Shannon 的理論中得到了確立。

## 深度分析
### 評估的局限性與進階測試
由於模型容易對訓練數據過度擬合 (Overfit)，評估必須在獨立的**測試集 (Test set)** 上進行。
1.  **信息壓縮能力**：LLM 卓越的預測能力使其具備無損壓縮 (Lossless compression) 的能力，例如 DeepMind 的 Chinchilla 模型展示了對 ImageNet 的高壓縮率。
2.  **基準測試 (Benchmarks)**：用於評估模型在特定任務上的能力，包括：
    *   **常識推理 (Commonsense reasoning)**：評估基礎的日常知識應用。
    *   **偏見檢測**：使用如 CrowS-Pairs、Stereo Set 等基準集評估模型潛在的社會偏見。
    *   **事實查核 (Fact-checking)**：比較模型（如 GPT-4）與獨立人工查核機構（如 PolitiFact）的準確性，顯示了模型在該領域仍有提升空間。

## 視覺化流程圖
```mermaid
graph TD
    A[認知語言學理論] --> B{語言模型建構};
    B --> C1["神經理論語言學 (NTL)"];
    B --> C2["機率上下文無窮文法 (PCFG)"];
    C1 --> D[模型思維模擬];
    C2 --> D;
    D --> E{語言生成能力};
    E --> F[評估階段];
    F --> G1["困惑度 (Perplexity)"];
    F --> G2["常識推理/偏見基準 (Benchmarks)"];
    G1 --> H{量化性能};
    G2 --> H;
    H --> I[模型優化與迭代];
```

---
[[Large language model (Part 8)|← 上一頁]] | 第 9 / 29 | [[Large language model (Part 10)|下一頁 →]]