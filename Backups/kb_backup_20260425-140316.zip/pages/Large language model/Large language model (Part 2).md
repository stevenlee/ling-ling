---
title: Large language model (Part 2)
type: entity
date_created: '2026-04-25'
tags:
- ai
- deep-learning
- llm
- natural-language-processing
- 深度學習
- 自然語言處理
---
# Large Language Model (LLM)

## 摘要
大型語言模型（LLM）的發展，核心支柱是 2017 年由 Google 提出的 **Transformer 架構**。該架構極大地依賴了「注意力機制」（Attention Mechanism），取代了傳統的序列處理方式。LLM 的發展歷程呈現出從最初的序列到序列（Seq2seq）模型，發展出專注於編碼器（如 BERT）和解碼器（如 GPT）的單向架構，最終發展為具備多模態（Multimodal）能力和開放權重（Open-weight）的複雜系統。

## 核心概念
### 1. Transformer 架構
Transformer 架構是 LLM 的基礎。它摒棄了傳統的遞歸網路（RNN）結構，完全依賴注意力機制來捕捉序列中不同詞彙之間的關聯性。
*   **關鍵突破：** 2017 年發表於 NeurIPS 的論文《Attention Is All You Need》奠定了基礎。
*   **結構：** 原始 Transformer 包含編碼器（Encoder）和解碼器（Decoder）兩個主要部分。

### 2. 注意力機制 (Attention Mechanism)
這是 Transformer 的核心創新。它允許模型在處理序列的某個元素時，能夠權衡輸入序列中所有其他元素的重要性，從而計算出更精確的上下文依賴關係。

### 3. 資料預處理流程 (Tokenization & Embedding)
由於機器學習算法只能處理數字，文本輸入必須經過兩階段轉換：
*   **分詞 (Tokenization)：** 將連續的文本切分成最小的語義單元（Tokens）。常見的算法包括 **Byte-pair encoding (BPE)** 和 **WordPiece**。
*   **嵌入 (Embedding)：** 為每個 Token 分配一個獨特的整數索引，並將此索引映射到一個高維度的向量空間（Word Embedding），使其能被模型計算。
*   **特殊 Token：** 模型會使用特殊標記來指示語義功能，例如 `[MASK]`（用於遮蔽任務，如 BERT）和 `[UNK]`（未知詞彙）。

## 深度分析
### 1. 模型架構的演進趨勢
LLM 的發展路徑清晰地體現了架構的專精化和簡化趨勢：
*   **BERT (Encoder-only)：** 早期模型，擅長理解輸入文本的上下文（例如，填充 `[MASK]` 任務）。
*   **GPT 系列 (Decoder-only)：** 專注於生成任務，透過預測序列的下一個詞（自迴歸生成），並隨著 Prompt Engineering 的進步，成為主流。
*   **多模態學習 (Multimodal Learning)：** 現代 LLM 不再僅限於文本，而是能處理和生成圖像、音訊、3D 網格等多種數據類型。
*   **開放權重模型 (Open-weight Models)：** 隨著 LLaMA、Mistral AI 等模型的興起，權重可供下載和修改的開放模型，極大地推動了學術界和商業界的創新，降低了進入門檻。

### 2. 關鍵技術點
*   **Prompting (提示工程)：** 透過設計輸入的提示詞（Prompt），引導模型執行特定任務，已成為與模型本身能力同等重要的技術。
*   **推理鏈 (Chain-of-Thought, CoT)：** 較新的模型（如 OpenAI o1）能夠生成長篇的思考過程（Thought Chain），再輸出最終答案，顯著提升了複雜推理能力。

## 視覺化流程圖：LLM 架構演進與資料處理
```mermaid
graph TD
    A[原始文本輸入] --> B{資料預處理};
    B --> C[分詞 (Tokenization)];
    C --> D[生成 Token 序列];
    D --> E[嵌入 (Embedding)];
    E --> F{Transformer 核心架構};

    subgraph "模型架構演進"
        F --> G1[Encoder-only (BERT)];
        F --> G2[Decoder-only (GPT)];
        F --> G3[Encoder + Decoder (原始 Transformer)];
    end

    G2 --> H1[Prompting / 文本生成];
    G1 --> H2[上下文理解 / 填空];
    G3 --> H3[Seq2seq 任務];

    H1 --> I{多模態擴展};
    H2 --> I;
    H3 --> I;

    I --> J[輸出結果];

    style A fill:#f9f,stroke:#333,stroke-width:2px
    style F fill:#ccf,stroke:#333,stroke-width:2px
    style J fill:#9f9,stroke:#333,stroke-width:2px
```

---
[[Large language model (Part 1)|← 上一頁]] | 第 2 / 29 | [[Large language model (Part 3)|下一頁 →]]