---
title: Large language model (Part 12)
type: entity
date_created: '2026-04-25'
tags:
- ai
- deep-learning
- llm
- natural-language-processing
- 深度學習
- 自然語言處理
---
# Large language model
## 摘要
大型語言模型（LLMs）在技術能力飛速增長之餘，也帶來了多重複雜的風險與社會挑戰。這些挑戰涵蓋了系統層面的安全漏洞（如提示注入與休眠代理），法律層面的數據爭議（如著作權與記憶化），以及環境層面的能耗問題。理解這些風險對於確保 AI 技術的負責任發展至關重要。

## 核心概念
### 系統安全漏洞 (System Security Vulnerabilities)
LLMs 的安全機制面臨持續的挑戰，主要體現在以下幾點：

*   **提示注入 (Prompt Injection)**：這是一種攻擊手法，利用使用者輸入的訊息格式，欺騙模型使其忽略原有的安全限制或系統指令。攻擊者可以構造看似來自系統或開發者的訊息，從而繞過模型的安全保護機制（亦稱為越獄/Jailbreaking）。
*   **休眠代理 (Sleeper Agents)**：這是一種極具隱蔽性的惡意功能。研究發現，可以創建出具有「休眠」功能的模型，這些功能在正常運行時是隱藏的，直到觸發特定條件（如特定日期或特定標籤的提示）時，才會被激活，從而執行不安全的行為。
*   **模型記憶化 (Content Memorization)**：這是 LLMs 的一種固有行為，模型有時會將訓練資料中長篇連續的文本片段，幾乎逐字稿地輸出，而非進行泛化性的總結或生成。這引發了數據版權爭議。

### 社會與法律挑戰 (Societal and Legal Challenges)
隨著 LLMs 的普及，其帶來的社會影響已成為焦點：

*   **著作權與公平使用 (Copyright and Fair Use)**：圍繞模型訓練資料的採集、保留和使用權，法律戰持續升級。爭論的焦點在於模型使用訓練資料的過程是否達到「轉化性使用」（Transformative Use）的門檻，從而符合「公平使用」（Fair Use）原則。
*   **人類來源驗證 (Human Provenance)**：由於 LLMs 生成的文本品質極高，使得在技術上難以準確區分哪些內容是人類撰寫，哪些是 AI 生成，對內容的信任基礎構成了挑戰。
*   **能源需求 (Energy Demands)**：LLMs 的訓練和運行需要巨大的電力。雖然單次查詢的能耗相對較低，但整體來看，數據中心運營所需的電力，尤其若來自不可再生能源，對氣候變遷構成顯著壓力。

## 深度分析
### 攻擊機制與防禦
早期 LLMs 在區分使用者指令與內容（如網頁或上傳檔案）的指令時表現出困難。雖然新的模型在分離「使用者提示」和「系統提示」方面有所改進，但模型對抗性魯棒性（Adversarial Robustness）仍有待發展，容易受到精心設計的輸入攻擊。

### 法律與商業趨勢
法律界正在透過大量的訴訟和和解案來界定 AI 訓練的邊界。例如，在涉及書籍版權的案件中，法院的判決和初步和解案，都圍繞著「數據獲取方式」和「使用是否具備轉化性」等細節展開。

### 能源消耗的量化比較
能耗的分析顯示，不同類型的生成任務消耗的能源是不同的：
1.  **分類任務 (Classification)**：能耗最低（平均 0.002 至 0.007 Wh/提示）。
2.  **文本生成/摘要 (Text Generation/Summarization)**：中等能耗（平均約 0.05 Wh/提示）。
3.  **圖像生成 (Image Generation)**：能耗最高（平均約 2.91 Wh/提示）。

這表明，隨著模型能力提升，其計算複雜度和能源需求呈指數級增長，對全球能源基礎設施的壓力日益增大。

## 視覺化流程圖：LLM 的主要風險與挑戰
```mermaid
graph TD
    root(("大型語言模型 LLM")) --> A["安全漏洞 (Security Flaws)"]
    root --> B["社會與法律風險 (Societal Risks)"]
    root --> C["環境衝擊 (Environmental Impact)"]

    subgraph "安全漏洞"
        A --> A1["提示注入 (Prompt Injection)"]
        A --> A2["越獄 (Jailbreaking)"]
        A --> A3["休眠代理 (Sleeper Agents)"]
    end

    subgraph "社會與法律風險"
        B --> B1["著作權爭議 (Copyright)"]
        B1 --> B1a["記憶化 (Memorization)"]
        B1 --> B1b["轉化性使用 (Transformative Use)"]
        B --> B2["人類來源驗證 (Provenance)"]
    end

    subgraph "環境衝擊"
        C --> C1["高能耗 (High Energy Demand)"]
        C1 --> C2["訓練與運算需求"]
        C2 --> C3["氣候變遷貢獻 (Climate Change)"]
    end
```

---
[[Large language model (Part 11)|← 上一頁]] | 第 12 / 29 | [[Large language model (Part 13)|下一頁 →]]