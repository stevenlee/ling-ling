---
title: Large language model (Part 4)
type: entity
date_created: '2026-04-25'
tags:
- ai
- deep-learning
- llm
- natural-language-processing
- 深度學習
- 自然語言處理
---
# Large Language Model (LLM)
## 摘要
大型語言模型（LLMs）是當前人工智慧領域的核心技術，其架構主要基於 **Transformer** 結構。LLMs 能夠通過精密的 **注意力機制 (Attention mechanism)** 來同時處理序列中所有元素之間的關聯性，無論它們相距多遠。本筆記深入探討了 LLMs 的核心架構、多種訓練範式（如自回歸、遮罩式）、效能優化技術（如量化、MoE），以及進階的應用層面——提示工程 (Prompt Engineering)。

## 核心概念

### 1. Transformer 架構與注意力機制 (Attention Mechanism)
LLMs 的基礎是 Transformer 架構。其關鍵在於注意力機制，它允許模型計算序列中每個 Token 對其他所有 Token 的「相關性權重」（Soft Weights）。

*   **多頭注意力 (Multi-Head Attention):** 模型不會只用一個視角來計算關聯性。它會使用多個「注意力頭」，每個頭都從不同的角度關注輸入序列的不同方面，從而更全面地理解上下文關係。
*   **上下文視窗 (Context Window):** 這是模型一次能處理的 Token 總數限制。注意力機制必須在該視窗內計算所有 Token 之間的相互關聯性。

### 2. 模型訓練範式 (Model Training Paradigms)
LLMs 的訓練方式決定了它們擅長處理的任務類型：

*   **自回歸模型 (Autoregressive Models):**
    *   **原理:** 預測序列的下一個元素。模型根據已觀察到的前文，預測最有可能接續的詞彙。
    *   **範例:** GPT 系列模型。適用於文本生成、寫作等序列預測任務。
*   **遮罩式模型 (Masked Models):**
    *   **原理:** 預測序列中被「遮罩」或移除的缺失部分。模型需要考慮上下文的雙向資訊。
    *   **範例:** BERT 模型。適用於文本理解、填空預測等任務。
*   **專家混合模型 (Mixture of Experts, MoE):**
    *   **原理:** 這是一種架構層面的優化。模型不使用一個單一的龐大網路，而是由多個專業化的子網路（Experts）組成。一個「門控機制 (Gating Mechanism)」會根據輸入，將任務路由給最適合處理的幾個專家，從而顯著降低推理成本。

### 3. 模型優化與效率提升
隨著模型參數規模的擴大（常超過 1000 億），優化技術變得至關重要：

*   **量化 (Quantization):**
    *   **目的:** 降低模型參數的位元精度（例如從 32 位浮點數 `float32` 降至 16 位 `float16`），以減少模型佔用的記憶體空間。
    *   **類型:**
        *   *靜態量化 (Static Quantization):* 事先確定量化參數。
        *   *動態量化 (Dynamic Quantization):* 在推理時動態應用量化。
*   **低秩適應 (Low-Rank Adaptation, LoRA):** 一種高效的微調 (Fine-tuning) 技術，允許在不修改原始龐大模型權重的情況下，適應特定任務。

## 深度分析

### 提示工程 (Prompt Engineering)
這是目前最重要、最易用、最能擴展 LLM 能力的方法之一，它不依賴於模型本身的重新訓練，而是依賴於優化輸入的「提示詞 (Prompt)」。

*   **少樣本提示 (Few-Shot Prompting):** 透過在輸入的提示中提供幾個「輸入-期望輸出」的範例，讓 LLM 能夠理解任務的格式和邏輯，從而適應任何新任務，無需進行昂貴的微調。
*   **自我指導 (Self-Instructing):** 進階的提示技術。模型本身可以根據用戶輸入，生成一個「指令 (Instruction)」，然後將這個指令與用戶輸入一起作為新的輸入，引導模型「自我啟動 (Bootstrap)」並推導出更準確的答案。

### 參數規模與計算成本
模型參數的規模直接決定了其能力上限，但同時也帶來巨大的計算和儲存成本。MoE 架構和量化技術的出現，正是為了在「維持高能力」與「降低計算成本」之間取得平衡。

## 視覺化流程圖

### Transformer 核心流程與注意力機制
```mermaid
graph TD
    A["輸入 Token 序列"] --> B{Transformer Encoder/Decoder};
    B --> C["計算關聯性"];
    C --> D{注意力機制 (Attention)};
    D --> E[計算 Soft Weights];
    E --> F["加權求和輸出"];
    F --> G["輸出 Token 序列"];

    subgraph "注意力機制細節"
        D --> D1["多頭計算"];
        D1 --> D2["計算每個頭的權重"];
        D2 --> D3["綜合權重矩陣"];
    end
```

### LLM 訓練範式比較
```mermaid
graph TD
    subgraph "訓練範式比較"
        A[自回歸模型 (Autoregressive)] --> A1["預測下一個 Token"];
        B[遮罩式模型 (Masked)] --> B1["填補缺失的 Token"];
        C[專家混合模型 (MoE)] --> C1["路由到最相關的專家"];
    end
    style A fill:#f9f,stroke:#333,stroke-width:2px
    style B fill:#ccf,stroke:#333,stroke-width:2px
    style C fill:#cfc,stroke:#333,stroke-width:2px
```

---
[[Large language model (Part 3)|← 上一頁]] | 第 4 / 29 | [[Large language model (Part 5)|下一頁 →]]