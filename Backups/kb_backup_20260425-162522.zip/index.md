# 🎀 Knowledge Dashboard (v0.2.1)
---

## ✍️ Notes

## 🤖 Entities
> [!abstract]- 📂 孫子兵法 (4 items) | 📅 2026-04-25
> - [[孫子兵法]]  `clippings`
> - [[孫子兵法 (Part 1)]]  `classical-military-strategy` `military-philosophy` `strategic-thinking`
> - [[孫子兵法 (Part 2)]]  `classical-military-strategy` `military-philosophy` `strategic-thinking`
> - [[孫子兵法 (Synthesis)]]  `classical-military-strategy` `completed` `military-philosophy`

> [!abstract]- 📂 道德經 (3 items) | 📅 2026-04-25
> - [[道德經 (Part 1)]]  `laozi` `non-action` `philosophy`
> - [[道德經 (Part 2)]]  `laozi` `non-action` `philosophy`
> - [[道德經 (Synthesis)]]  `completed` `laozi` `non-action`

